import { createClient } from '@base44/sdk';
import { appParams } from '@/lib/app-params';
import { isTenantScoped, scopeQuery, withTenant } from '@/lib/tenant';

const { appId, token, functionsVersion, appBaseUrl } = appParams;

const client = createClient({
  appId,
  token,
  functionsVersion,
  serverUrl: '',
  appBaseUrl
});

// A record's tenant is immutable from the client: company_id is only ever
// applied by withTenant() on create, and never accepted from a caller on
// update. Combined with RLS on every entity, a request cannot reach another
// company's rows even if a caller forges one.
function scrubTenant(entityName, data) {
  if (!isTenantScoped(entityName) || !data || typeof data !== 'object') return data;
  const { company_id, ...rest } = data;
  return rest;
}

const NETWORK_RETRY_DELAY_MS = 700;

// Read-only calls may safely be repeated.
const READ_METHODS = new Set(['list', 'filter', 'get', 'count', 'distinct', 'aggregate']);
const READ_ONLY_FUNCTIONS = new Set(['loadDashboardData']);

// A connection that drops mid-request arrives with no status at all. Reads are
// repeated once after a short pause so a momentary blip doesn't take the page
// down; writes are never retried, so a payment or intake can't be recorded twice.
function isNetworkError(error) {
  if (!error || error.status) return false;
  return /network error|failed to fetch|timeout|ERR_NETWORK/i.test(String(error.message || ''));
}

function withNetworkRetry(fn) {
  return async (...args) => {
    try {
      return await fn(...args);
    } catch (error) {
      if (!isNetworkError(error)) throw error;
      await new Promise((resolve) => setTimeout(resolve, NETWORK_RETRY_DELAY_MS));
      return fn(...args);
    }
  };
}

function retryReads(entity) {
  return new Proxy(entity, {
    get(target, method) {
      const fn = target[method];
      if (typeof fn !== 'function') return fn;
      return READ_METHODS.has(method) ? withNetworkRetry(fn.bind(target)) : fn.bind(target);
    },
  });
}

function tenantEntity(entityName, entity) {
  return new Proxy(entity, {
    get(target, method) {
      const fn = target[method];
      if (typeof fn !== 'function') return fn;

      switch (method) {
        case 'create':
          return (data, ...rest) => fn.call(target, withTenant(entityName, data), ...rest);
        case 'bulkCreate':
          return (rows, ...rest) =>
            fn.call(target, (rows || []).map((row) => withTenant(entityName, row)), ...rest);
        case 'update':
          return (id, data, ...rest) => fn.call(target, id, scrubTenant(entityName, data), ...rest);
        case 'filter':
        case 'count':
        case 'deleteMany':
          return (query = {}, ...rest) => fn.call(target, scopeQuery(entityName, query), ...rest);
        case 'updateMany':
          return (query = {}, update, ...rest) =>
            fn.call(target, scopeQuery(entityName, query), update, ...rest);
        case 'aggregate':
          return (args = {}, ...rest) =>
            fn.call(target, { ...args, query: scopeQuery(entityName, args?.query) }, ...rest);
        default:
          return READ_METHODS.has(method) ? withNetworkRetry(fn.bind(target)) : fn.bind(target);
      }
    },
  });
}

const entities = new Proxy(client.entities, {
  get(target, prop) {
    const value = target[prop];
    if (typeof prop !== 'string' || !value || typeof value !== 'object') return value;
    if (!isTenantScoped(prop)) return retryReads(value);
    return tenantEntity(prop, value);
  },
});

// The tenant-scoped client every page already imports. `entities` is the only
// wrapped surface; auth, functions and integrations pass through untouched.
function retryReadFunctions(functions) {
  return new Proxy(functions, {
    get(target, method) {
      const fn = target[method];
      if (typeof fn !== 'function') return fn;
      if (method !== 'invoke') return fn.bind(target);
      return (name, payload, ...rest) =>
        READ_ONLY_FUNCTIONS.has(name)
          ? withNetworkRetry(() => fn.call(target, name, payload, ...rest))()
          : fn.call(target, name, payload, ...rest);
    },
  });
}

export const base44 = new Proxy(client, {
  get(target, prop) {
    if (prop === 'entities') return entities;
    if (prop === 'functions') return retryReadFunctions(target.functions);
    const value = target[prop];
    return typeof value === 'function' ? value.bind(target) : value;
  },
});