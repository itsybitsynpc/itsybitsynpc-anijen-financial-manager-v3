import { useEffect, useMemo, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, Plus, Pencil, BookOpen } from "lucide-react";
import Layout from "@/components/Layout";
import SalesPersonFormDialog from "@/components/salespersons/SalesPersonFormDialog";
import SalesPersonLedgerDialog from "@/components/salespersons/SalesPersonLedgerDialog";
import { usePassphraseGuard } from "@/hooks/useGuard";
import { formatGHS } from "@/lib/format";
import { computeSalesPersonBalance, salespersonOutstanding } from "@/lib/finance";
import { withScrollRetention } from "@/lib/scroll";

export default function SalesPersons() {
  const [list, setList] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [formOpen, setFormOpen] = useState(false);
  const [editTarget, setEditTarget] = useState(null);
  const [ledgerTarget, setLedgerTarget] = useState(null);
  const { requirePassphrase, modal } = usePassphraseGuard();

  const load = withScrollRetention(async () => {
    setLoading(true);
    try {
      const [sps, txs] = await Promise.all([
        base44.entities.SalesPerson.list("name", 200),
        base44.entities.SalesPersonTransaction.list("-created_date", 1000),
      ]);
      setList(sps);
      setTransactions(txs);
    } finally {
      setLoading(false);
    }
  });

  useEffect(() => { load(); }, []);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return list;
    return list.filter((s) => s.name?.toLowerCase().includes(q));
  }, [list, search]);

  const handleSave = async (data) => {
    if (editTarget) {
      await base44.entities.SalesPerson.update(editTarget.id, data);
    } else {
      await base44.entities.SalesPerson.create(data);
    }
    load();
  };

  const handleDelete = (s) => {
    requirePassphrase(`delete sales person profile: ${s.name}`, async () => {
      const myTx = transactions.filter((t) => t.salesperson_id === s.id);
      if (myTx.length) {
        await base44.entities.SalesPersonTransaction.deleteMany({ salesperson_id: s.id });
      }
      await base44.entities.SalesPerson.delete(s.id);
      load();
    });
  };

  return (
    <Layout>
      <div className="flex flex-col gap-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div>
            <h1 className="font-heading text-2xl font-semibold">Sales Persons</h1>
            <p className="text-sm text-muted-foreground">{list.length} reps · product issues & settlements in GHS</p>
          </div>
          <Button onClick={() => { setEditTarget(null); setFormOpen(true); }}>
            <Plus className="h-4 w-4 mr-1" /> Add Sales Person
          </Button>
        </div>

        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search sales persons by name…" value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9 max-w-md" />
        </div>

        <div className="rounded-xl border bg-card shadow-sm">
          <div className="sticky-header rounded-t-xl grid grid-cols-12 gap-2 px-4 py-2.5 text-xs font-semibold text-muted-foreground">
            <div className="col-span-4">Sales Person</div>
            <div className="col-span-2 text-right">Previous Balance</div>
            <div className="col-span-2 text-right">Outstanding</div>
            <div className="col-span-2 text-right">Total Debt</div>
            <div className="col-span-2 text-right">Actions</div>
          </div>
          {loading ? (
            <div className="px-4 py-10 text-center text-sm text-muted-foreground">Loading…</div>
          ) : filtered.length === 0 ? (
            <div className="px-4 py-10 text-center text-sm text-muted-foreground">No sales persons found.</div>
          ) : (
            filtered.map((s) => {
              const out = salespersonOutstanding(s, transactions);
              const bal = computeSalesPersonBalance(s, transactions);
              return (
                <div key={s.id} className="grid grid-cols-12 gap-2 border-b px-4 py-3 text-sm last:border-0 items-center hover:bg-muted/30">
                  <div className="col-span-4 font-medium">{s.name}</div>
                  <div className="col-span-2 text-right text-muted-foreground">{formatGHS(s.previous_balance || 0)}</div>
                  <div className={`col-span-2 text-right font-semibold ${out > 0 ? "text-amber-600" : "text-emerald-600"}`}>{formatGHS(out)}</div>
                  <div className="col-span-2 text-right font-semibold rounded px-1 py-0.5 bg-slate-100 text-slate-900">{formatGHS(bal)}</div>
                  <div className="col-span-2 flex justify-end gap-1">
                    <Button variant="outline" size="sm" onClick={() => setLedgerTarget(s)} title="Ledger"><BookOpen className="h-3.5 w-3.5" /></Button>
                    <Button variant="outline" size="sm" onClick={() => { setEditTarget(s); setFormOpen(true); }} title="Edit"><Pencil className="h-3.5 w-3.5" /></Button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      <SalesPersonFormDialog open={formOpen} onClose={() => setFormOpen(false)} onSave={handleSave} salesperson={editTarget} />
      <SalesPersonLedgerDialog salesperson={ledgerTarget} open={!!ledgerTarget} onClose={() => setLedgerTarget(null)} transactions={transactions} onRefresh={load} />
      {modal}
    </Layout>
  );
}