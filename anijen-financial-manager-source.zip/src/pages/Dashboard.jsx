import { useEffect, useMemo, useRef, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Wallet, TrendingUp, TrendingDown, Users, Briefcase, Package, ShoppingCart, Truck, Trash2, CalendarDays, X, Download, Pencil } from "lucide-react";
import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useProducts } from "@/hooks/useProducts";
import { usePassphraseGuard } from "@/hooks/useGuard";
import { formatGHS, formatDate } from "@/lib/format";
import {
  computeCustomerBalance,
  computeSalesPersonBalance,
  inventoryCostValue,
  inventoryGrossValue,
  computeProfitBreakdown,
  transactionLines,
  transactionItemsLabel,
  inDayWindow,
  lowStockProducts,
  availableStock,
} from "@/lib/finance";
import { withScrollRetention } from "@/lib/scroll";
import { buildMonthlySeries } from "@/lib/trends";
import { downloadCSV } from "@/lib/csv";
import ActivityCharts from "@/components/dashboard/ActivityCharts";
import LowStockCard from "@/components/dashboard/LowStockCard";
import ExpenseCategoryBreakdown from "@/components/dashboard/ExpenseCategoryBreakdown";
import LowStockBanner from "@/components/dashboard/LowStockBanner";
import ProfitBreakdown from "@/components/shared/ProfitBreakdown";
import DashboardWeeklyAnalytics from "@/components/dashboard/DashboardWeeklyAnalytics";
import { useDashboardRealtime } from "@/hooks/useDashboardRealtime";
import useActiveCompany from "@/hooks/useActiveCompany";
import NetIncomeEditDialog from "@/components/dashboard/NetIncomeEditDialog";
import CustomerBalancesEditDialog from "@/components/dashboard/CustomerBalancesEditDialog";
import { totalCapital as computeTotalOtherCapital } from "@/lib/capital";
import { totalOutstanding } from "@/lib/suppliers";
import { reverseTransactionBalance } from "@/lib/paymentService";
import DebtSuppliersCard from "@/components/dashboard/DebtSuppliersCard";
import { toast } from "@/components/ui/use-toast";

function localDayStr(d) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}
const todayStr = () => localDayStr(new Date());
const yesterdayStr = () => { const d = new Date(); d.setDate(d.getDate() - 1); return localDayStr(d); };
const dayLabel = (s) => new Date(s + "T00:00:00").toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });

export default function Dashboard() {
  const { data: products = [] } = useProducts();
  const { activeId, activeName } = useActiveCompany();
  const [customers, setCustomers] = useState([]);
  const [salesPersons, setSalesPersons] = useState([]);
  const [custTx, setCustTx] = useState([]);
  const [spTx, setSpTx] = useState([]);
  const [incomeLogs, setIncomeLogs] = useState([]);
  const [factoryPayments, setFactoryPayments] = useState([]);
  const [expenses, setExpenses] = useState([]);
  const [vehicleExpenses, setVehicleExpenses] = useState([]);
  const [corrections, setCorrections] = useState([]);
  const [capitalAccounts, setCapitalAccounts] = useState([]);
  const [capitalTransactions, setCapitalTransactions] = useState([]);
  const [suppliers, setSuppliers] = useState([]);
  const [supplierTransactions, setSupplierTransactions] = useState([]);
  const [editOpen, setEditOpen] = useState(false);
  const [balancesEditOpen, setBalancesEditOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [mode, setMode] = useState("all-time"); // "all-time" | "custom"
  const [customDate, setCustomDate] = useState(todayStr());
  const { requirePassphrase, modal } = usePassphraseGuard();

  const load = withScrollRetention(async () => {
    setLoading(true);
    try {
      // One backend call fetches all dashboard entities server-side, avoiding
      // the client rate limit that 12 list calls exceeded.
      const { data } = await base44.functions.invoke("loadDashboardData", {});
      setCustomers(data.customers || []);
      setSalesPersons(data.salesPersons || []);
      setCustTx(data.customerTransactions || []);
      setSpTx(data.salesPersonTransactions || []);
      setIncomeLogs(data.incomeLogs || []);
      setFactoryPayments(data.factoryPayments || []);
      setExpenses(data.expenses || []);
      setVehicleExpenses(data.vehicleExpenses || []);
      setCorrections(data.corrections || []);
      setCapitalAccounts(data.capitalAccounts || []);
      setCapitalTransactions(data.capitalTransactions || []);
      setSuppliers(data.suppliers || []);
      setSupplierTransactions(data.supplierTransactions || []);
    } catch (e) {
      toast({
        title: "Couldn't load dashboard data",
        description: e?.message || "A transient error occurred. Please refresh.",
        variant: "destructive",
        duration: 6000,
      });
    } finally {
      setLoading(false);
    }
  });

  // Refetch whenever the active workspace changes so one company's figures can
  // never remain on screen after switching to another.
  useEffect(() => { load(); }, [activeId]);

  // Global real-time subscription: any create/update/delete on any core
  // entity (sales, issues, expenses, vehicle expenses, inventory, capital,
  // supplier debt, customers, salespersons) debounces a full dashboard
  // refetch so every metric below recomputes instantly — no manual reload.
  const { isLive, lastUpdated } = useDashboardRealtime({ onRefresh: load });

  // Fire a one-time notification whenever a product drops to or below its
  // configured low-stock threshold (notifies only for newly-low items).
  const lowNotifiedRef = useRef(new Set());
  useEffect(() => {
    const low = lowStockProducts(products);
    if (low.length === 0) return;
    const newlyLow = low.filter((p) => !lowNotifiedRef.current.has(p.id));
    if (newlyLow.length === 0) return;
    newlyLow.forEach((p) => lowNotifiedRef.current.add(p.id));
    toast({
      title: "⚠️ Low Stock Alert",
      description: `${newlyLow.map((p) => `${p.name} (${availableStock(p)} cartons available)`).join(", ")} at or below threshold.`,
      duration: 8000,
    });
  }, [products]);

  // Lifetime capital snapshot (point-in-time, never date-filtered).
  const customerBalances = useMemo(
    () => customers.reduce((s, c) => s + Math.max(0, computeCustomerBalance(c, custTx)), 0),
    [customers, custTx]
  );
  const salesPersonBalances = useMemo(
    () => salesPersons.reduce((s, sp) => s + Math.max(0, computeSalesPersonBalance(sp, spTx)), 0),
    [salesPersons, spTx]
  );
  const invValue = inventoryCostValue(products);
  // Est. Gross Revenue = current stock valued at selling price. Used in the
  // Total Company Capital aggregation instead of inventory cost value, so any
  // change to product stock or Sell/Unit price flows into capital in real time.
  const estGrossRevenue = inventoryGrossValue(products);
  const profit = useMemo(
    () => computeProfitBreakdown({ products, expenses, factoryPayments, vehicleExpenses, includeFactory: false }),
    [products, expenses, factoryPayments, vehicleExpenses]
  );
  const totalOtherCapital = useMemo(
    () => computeTotalOtherCapital(capitalAccounts, capitalTransactions),
    [capitalAccounts, capitalTransactions]
  );
  const totalFactoryPaymentsLifetime = useMemo(
    () => factoryPayments.reduce((s, p) => s + Number(p.amount || 0), 0),
    [factoryPayments]
  );
  // New supplier debt reduces Total Company Capital (liability ↑ = net worth ↓).
  // Repayments reduce the Bank/MoMo/Cash balance and the outstanding debt by the
  // same amount, so they net to zero on capital — the debt is only ever deducted
  // once, when it is created.
  const totalOutstandingSupplierDebt = useMemo(
    () => totalOutstanding(suppliers, supplierTransactions),
    [suppliers, supplierTransactions]
  );
  const correction = corrections[0];
  const netProfit = correction ? Number(correction.amount) : profit.netProfit;
  // Profit is informational only — it must NOT feed into Total Company Capital
  // or any other balance. Net Profit is shown separately as an analytics metric.
  const totalCapital = customerBalances + salesPersonBalances + estGrossRevenue + totalOtherCapital - totalFactoryPaymentsLifetime - totalOutstandingSupplierDebt;

  // Active 24h window (null = all-time / lifetime).
  const activeDate = mode === "custom" ? customDate : null;
  const inWindow = (dateStr) => inDayWindow(dateStr, activeDate);
  const periodLabel = activeDate ? dayLabel(activeDate) : "All-Time";

  const filteredIncome = useMemo(
    () => incomeLogs.filter((l) => inWindow(l.date || l.created_date)),
    [incomeLogs, activeDate]
  );
  const filteredFactoryPayments = useMemo(
    () => factoryPayments.filter((p) => inWindow(p.date || p.created_date)),
    [factoryPayments, activeDate]
  );
  const filteredExpenses = useMemo(
    () => expenses.filter((e) => inWindow(e.date || e.created_date)),
    [expenses, activeDate]
  );
  const filteredVehicleExpenses = useMemo(
    () => vehicleExpenses.filter((e) => inWindow(e.date || e.created_date)),
    [vehicleExpenses, activeDate]
  );
  const filteredSales = useMemo(
    () => custTx.filter((t) => t.type === "sale" && inWindow(t.date || t.created_date)),
    [custTx, activeDate]
  );
  const filteredIssues = useMemo(
    () => spTx.filter((t) => t.type === "issue" && inWindow(t.date || t.created_date)),
    [spTx, activeDate]
  );

  const totalIncome = filteredIncome.reduce((s, l) => s + Number(l.amount || 0), 0);
  const totalFactoryCosts = filteredFactoryPayments.reduce((s, p) => s + Number(p.amount || 0), 0);
  const totalExpenses = filteredExpenses.reduce((s, e) => s + Number(e.amount || 0), 0);
  const totalVehicleExpenses = filteredVehicleExpenses.reduce((s, e) => s + Number(e.amount || 0), 0);
  const totalCosts = totalFactoryCosts + totalExpenses + totalVehicleExpenses;
  const netIncome = totalIncome - totalCosts;

  const sumCartons = (list) => list.reduce(
    (s, t) => s + transactionLines(t).reduce((a, l) => a + Number(l.quantity_cartons || 0), 0),
    0
  );
  const totalCartonsSold = sumCartons(filteredSales);
  const totalStockIssued = sumCartons(filteredIssues);

  const resetFilter = () => { setMode("all-time"); setCustomDate(todayStr()); };
  const pickDay = (d) => { setCustomDate(d); setMode("custom"); };

  const handleDeleteIncome = (l) => {
    requirePassphrase(`delete income entry for ${l.reference_name || "manual income"}`, async () => {
      // Swallow "not found" so a record already removed (realtime update or a
      // double-click) does not abort the rest of the linked-transaction cleanup.
      const safeDelete = async (entity, id) => {
        if (!id) return;
        try {
          await base44.entities[entity].delete(id);
        } catch (err) {
          if (!/not found|404/i.test(err?.message || String(err))) throw err;
        }
      };
      await safeDelete("IncomeLog", l.id);
      if (l.source === "customer" && l.reference_id) {
        const match = custTx
          .filter((t) => t.customer_id === l.reference_id && t.type === "payment" && Number(t.amount) === Number(l.amount))
          .sort((a, b) => Math.abs(new Date(a.created_date) - new Date(l.created_date)) - Math.abs(new Date(b.created_date) - new Date(l.created_date)))[0];
        if (match) {
          try { await reverseTransactionBalance("CUSTOMER", match.customer_id, match); } catch {}
          await safeDelete("CustomerTransaction", match.id);
        }
      } else if (l.source === "salesperson" && l.reference_id) {
        const match = spTx
          .filter((t) => t.salesperson_id === l.reference_id && t.type === "settlement" && Number(t.amount) === Number(l.amount))
          .sort((a, b) => Math.abs(new Date(a.created_date) - new Date(l.created_date)) - Math.abs(new Date(b.created_date) - new Date(l.created_date)))[0];
        if (match) {
          try { await reverseTransactionBalance("SALESPERSON", match.salesperson_id, match); } catch {}
          await safeDelete("SalesPersonTransaction", match.id);
        }
      }
      load();
    });
  };

  const handleExportMonthlyFlow = () => {
    const rows = buildMonthlySeries({ custTx, incomeLogs, factoryPayments, expenses, vehicleExpenses });
    downloadCSV(
      `anijen-monthly-income-expense-flow-${new Date().toISOString().slice(0, 10)}`,
      [
        { label: "Month", value: (r) => r.label },
        { label: "Income (GHS)", value: (r) => r.income.toFixed(2) },
        { label: "Revenue (GHS)", value: (r) => r.revenue.toFixed(2) },
        { label: "Expenses (GHS)", value: (r) => r.expenses.toFixed(2) },
        { label: "Net Flow (GHS)", value: (r) => r.profit.toFixed(2) },
        { label: "Expense Ratio (%)", value: (r) => r.expenseRatio.toFixed(1) },
      ],
      [...rows].reverse()
    );
    toast({ title: "Exported to spreadsheet", description: "Monthly income & expense flow saved as a CSV file." });
  };

  return (
    <Layout>
      <div className="flex flex-col gap-6">
        <div className="flex items-end justify-between gap-3 flex-wrap">
          <div>
            <h1 className="font-heading text-2xl font-semibold flex items-center gap-2">
              Dashboard
              <span className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-medium ${isLive ? "bg-emerald-100 text-emerald-700" : "bg-muted text-muted-foreground"}`}>
                <span className={`h-1.5 w-1.5 rounded-full ${isLive ? "bg-emerald-500 animate-pulse" : "bg-muted-foreground"}`} />
                {isLive ? "Live" : "Connecting…"}
              </span>
            </h1>
            <p className="text-sm text-muted-foreground">{activeName || "Workspace"} · live financial overview (GHS) · updated {lastUpdated.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit", second: "2-digit" })}</p>
          </div>
          <Button variant="outline" onClick={handleExportMonthlyFlow} className="gap-2">
            <Download className="h-4 w-4" />
            Export Monthly Flow to Spreadsheet
          </Button>
        </div>

        <LowStockBanner products={products} />

        {/* Date toolbar */}
        <div className="rounded-xl border bg-card shadow-sm p-3 flex flex-wrap items-center gap-3">
          <div className="flex gap-1 rounded-lg bg-muted/50 p-1">
            <button
              onClick={() => setMode("all-time")}
              className={`rounded-md px-3 py-1.5 text-xs font-medium transition-colors ${mode === "all-time" ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"}`}
            >
              All-Time View
            </button>
            <button
              onClick={() => setMode("custom")}
              className={`rounded-md px-3 py-1.5 text-xs font-medium transition-colors ${mode === "custom" ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"}`}
            >
              Custom Date View
            </button>
          </div>

          <div className="flex items-center gap-2">
            <CalendarDays className="h-4 w-4 text-muted-foreground" />
            <Input
              type="date"
              value={customDate}
              onChange={(e) => { setCustomDate(e.target.value); setMode("custom"); }}
              disabled={mode !== "custom"}
              className="w-44"
            />
          </div>

          <div className="flex gap-1">
            <Button variant="outline" size="sm" onClick={() => pickDay(todayStr())}>Today</Button>
            <Button variant="outline" size="sm" onClick={() => pickDay(yesterdayStr())}>Yesterday</Button>
            <Button variant="outline" size="sm" onClick={resetFilter}>Clear / Reset</Button>
          </div>

          {mode === "custom" && (
            <span className="inline-flex items-center gap-1.5 rounded-full bg-amber-50 text-amber-900 px-3 py-1 text-xs font-medium">
              <CalendarDays className="h-3.5 w-3.5" />
              Showing Company Activity for: {dayLabel(customDate)}
              <button onClick={resetFilter} className="ml-0.5 hover:text-amber-700" title="Clear filter">
                <X className="h-3.5 w-3.5" />
              </button>
            </span>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          <CapitalCard label="Total Company Capital" value={formatGHS(totalCapital)} icon={Wallet} tone="primary" hint="incl. Est. Gross Revenue & other capital · less factory payments & supplier debt" />
          <CapitalCard label="Customer Balances" value={formatGHS(customerBalances)} icon={Users} tone="amber" onEdit={() => setBalancesEditOpen(true)} />
          <CapitalCard label="Sales Person Balances" value={formatGHS(salesPersonBalances)} icon={Briefcase} tone="amber" />
          <CapitalCard label="Inventory Value (Cost)" value={formatGHS(invValue)} icon={Package} tone="sky" />
          <CapitalCard label="Net Profit (All-Time)" value={formatGHS(netProfit)} icon={TrendingUp} tone={netProfit >= 0 ? "emerald" : "rose"} hint="Informational only — does not affect capital or any balance" corrected={!!correction} onEdit={() => setEditOpen(true)} />
          <CapitalCard label="Net Income" value={formatGHS(netIncome)} icon={TrendingUp} tone={netIncome >= 0 ? "emerald" : "rose"} />
          <CapitalCard label="Total Expenses (Period)" value={formatGHS(totalExpenses)} icon={TrendingDown} tone="rose" />
        </div>

        <LowStockCard products={products} />

        {/* Period metrics (24h window when custom) */}
        <div className="rounded-xl border bg-card shadow-sm">
          <div className="px-4 py-3 border-b flex items-center justify-between">
            <h2 className="font-heading font-semibold">Activity Metrics</h2>
            <span className="text-xs text-muted-foreground">{periodLabel}</span>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 divide-y sm:divide-y-0 sm:divide-x">
            <MetricTile label="Total Income" value={formatGHS(totalIncome)} tone="emerald" />
            <MetricTile label="Total Operating Costs" value={formatGHS(totalCosts)} tone="rose" />
            <MetricTile label="Vehicle Expenses" value={formatGHS(totalVehicleExpenses)} tone="amber" icon={Truck} />
            <MetricTile label="Net Income / Profit" value={formatGHS(netIncome)} tone={netIncome >= 0 ? "emerald" : "rose"} />
            <MetricTile label="Cartons Sold" value={totalCartonsSold.toLocaleString()} tone="sky" icon={ShoppingCart} />
            <MetricTile label="Stock Issued / Transported" value={totalStockIssued.toLocaleString()} tone="sky" icon={Truck} />
            <MetricTile label="Sales Transactions" value={filteredSales.length.toLocaleString()} tone="primary" />
          </div>
        </div>

        <ActivityCharts
          incomeLogs={incomeLogs}
          factoryPayments={factoryPayments}
          expenses={expenses}
          custTx={custTx}
          vehicleExpenses={vehicleExpenses}
          mode={mode}
          customDate={customDate}
        />

        <ExpenseCategoryBreakdown expenses={filteredExpenses} periodLabel={periodLabel} />

        <DashboardWeeklyAnalytics
          customerTransactions={custTx}
          salesPersonTransactions={spTx}
          expenses={expenses}
          vehicleExpenses={vehicleExpenses}
          onRefresh={load}
          isLive={isLive}
          lastUpdated={lastUpdated}
        />

        <ProfitBreakdown breakdown={profit} />

        <DebtSuppliersCard suppliers={suppliers} transactions={supplierTransactions} />

        {/* Activity feeds */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <FeedCard title="Recent Income" periodLabel={periodLabel} empty="No income in this period.">
            {filteredIncome.map((l) => (
              <div key={l.id} className="flex items-center justify-between px-4 py-2.5 text-sm">
                <div>
                  <p className="font-medium">{l.reference_name || "—"}</p>
                  <p className="text-xs text-muted-foreground">
                    {l.source === "customer" ? "Customer payment" : l.source === "salesperson" ? "Sales person settlement" : "Additional income"}
                    {l.payment_method ? ` · ${l.payment_method}` : ""}
                  </p>
                  <p className="text-[11px] text-muted-foreground">{formatDate(l.date || l.created_date)}</p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="font-medium text-emerald-600">{formatGHS(l.amount || 0)}</span>
                  <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive no-print" onClick={() => handleDeleteIncome(l)} title="Delete">
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </div>
            ))}
          </FeedCard>

          <FeedCard title="Factory Payments" periodLabel={periodLabel} empty="No factory payments in this period.">
            {filteredFactoryPayments.map((p) => (
              <div key={p.id} className="flex items-center justify-between px-4 py-2.5 text-sm">
                <div>
                  <p className="font-medium">{p.description || "Factory payment"}</p>
                  <p className="text-xs text-muted-foreground">{formatDate(p.date || p.created_date)}{p.payment_method ? ` · ${p.payment_method}` : ""}</p>
                </div>
                <span className="font-medium text-rose-600">{formatGHS(p.amount || 0)}</span>
              </div>
            ))}
          </FeedCard>

          <FeedCard title="Business Expenses" periodLabel={periodLabel} empty="No expenses in this period.">
            {filteredExpenses.map((e) => (
              <div key={e.id} className="flex items-center justify-between px-4 py-2.5 text-sm">
                <div>
                  <p className="font-medium">{e.item}</p>
                  <p className="text-xs text-muted-foreground">{e.category}{e.payment_method ? ` · ${e.payment_method}` : ""}</p>
                  <p className="text-[11px] text-muted-foreground">{formatDate(e.date || e.created_date)}</p>
                </div>
                <span className="font-medium text-rose-600">{formatGHS(e.amount || 0)}</span>
              </div>
            ))}
          </FeedCard>

          <FeedCard title="Recent Vehicle Expenses" periodLabel={periodLabel} empty="No vehicle expenses in this period.">
            {filteredVehicleExpenses.map((e) => (
              <div key={e.id} className="flex items-center justify-between px-4 py-2.5 text-sm">
                <div>
                  <p className="font-medium">{e.vehicle_name || "Vehicle"} · {e.expense_type}</p>
                  <p className="text-xs text-muted-foreground">{e.payment_method || "—"}{e.mileage ? ` · ${Number(e.mileage).toLocaleString()} km` : ""}</p>
                  <p className="text-[11px] text-muted-foreground">{formatDate(e.date || e.created_date)}</p>
                </div>
                <span className="font-medium text-rose-600">{formatGHS(e.amount || 0)}</span>
              </div>
            ))}
          </FeedCard>

          <FeedCard title="Recent Sales Transactions" periodLabel={periodLabel} empty="No sales in this period.">
            {filteredSales.map((t) => (
              <div key={t.id} className="flex items-center justify-between px-4 py-2.5 text-sm">
                <div>
                  <p className="font-medium">{t.customer_name || "—"}</p>
                  <p className="text-xs text-muted-foreground">{transactionItemsLabel(t)}</p>
                  <p className="text-[11px] text-muted-foreground">{formatDate(t.date || t.created_date)}</p>
                </div>
                <span className="font-medium text-emerald-600">{formatGHS(t.amount || 0)}</span>
              </div>
            ))}
          </FeedCard>
        </div>

        {loading && <div className="text-center text-sm text-muted-foreground">Loading live data…</div>}
      </div>
      <NetIncomeEditDialog
        open={editOpen}
        onClose={() => setEditOpen(false)}
        currentValue={netProfit}
        autoValue={profit.netProfit}
        correctionId={correction?.id}
        onSaved={load}
      />
      <CustomerBalancesEditDialog
        open={balancesEditOpen}
        onClose={() => setBalancesEditOpen(false)}
        customers={customers}
        transactions={custTx}
        onSaved={load}
      />
      {modal}
    </Layout>
  );
}

function FeedCard({ title, periodLabel, empty, children }) {
  const items = Array.isArray(children) ? children : [children];
  return (
    <div className="rounded-xl border bg-card shadow-sm overflow-hidden">
      <h2 className="font-heading font-semibold px-4 py-3 border-b flex items-center justify-between">
        <span>{title}</span>
        <span className="text-xs font-normal text-muted-foreground">{periodLabel}</span>
      </h2>
      <div className="divide-y max-h-80 overflow-auto">
        {items.length === 0 && <div className="px-4 py-6 text-center text-sm text-muted-foreground">{empty}</div>}
        {items}
      </div>
    </div>
  );
}

function MetricTile({ label, value, tone, icon: Icon }) {
  const toneClass = tone === "emerald" ? "text-emerald-600"
    : tone === "rose" ? "text-rose-600"
    : tone === "amber" ? "text-amber-600"
    : tone === "sky" ? "text-sky-600"
    : "text-foreground";
  return (
    <div className="p-4">
      <p className="text-xs font-medium text-muted-foreground flex items-center gap-1">
        {label}
        {Icon && <Icon className="h-3.5 w-3.5" />}
      </p>
      <p className={`mt-1 font-heading text-xl font-semibold ${toneClass}`}>{value}</p>
    </div>
  );
}

function CapitalCard({ label, value, icon: Icon, tone, hint, onEdit, corrected }) {
  const toneMap = {
    primary: "bg-primary/10 text-primary",
    amber: "bg-amber-100 text-amber-600",
    emerald: "bg-emerald-100 text-emerald-600",
    rose: "bg-rose-100 text-rose-600",
    sky: "bg-sky-100 text-sky-600",
  };
  return (
    <div className="rounded-xl border bg-card shadow-sm p-4">
      <div className="flex items-center justify-between">
        <p className="text-xs font-medium text-muted-foreground flex items-center gap-1.5">
          {label}
          {corrected && <span className="rounded bg-amber-100 text-amber-700 px-1.5 py-0.5 text-[10px] font-medium">corrected</span>}
        </p>
        <div className="flex items-center gap-1">
          {onEdit && (
            <button onClick={onEdit} className="text-muted-foreground hover:text-foreground" title="Edit / correct">
              <Pencil className="h-3.5 w-3.5" />
            </button>
          )}
          <span className={`flex h-8 w-8 items-center justify-center rounded-lg ${toneMap[tone] || "bg-muted text-muted-foreground"}`}>
            <Icon className="h-4 w-4" />
          </span>
        </div>
      </div>
      <p className="mt-2 font-heading text-2xl font-semibold">{value}</p>
      {hint && <p className="text-[11px] text-muted-foreground mt-0.5">{hint}</p>}
    </div>
  );
}