import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/lib/AuthContext";
import useActiveCompany from "@/hooks/useActiveCompany";
import Layout from "@/components/Layout";
import DeleteCompanyDialog from "@/components/workspace/DeleteCompanyDialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Building2, ShieldAlert, Trash2, Users } from "lucide-react";

/**
 * Workspace settings — the only place a company can be destroyed, and only
 * behind the admin passphrase.
 */
export default function WorkspaceSettings() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { active, activeId, activeName, memberships } = useActiveCompany();
  const [confirmOpen, setConfirmOpen] = useState(false);

  const isAdmin = active?.role === "admin" && (user?.admin_company_ids || []).includes(activeId);

  return (
    <Layout>
      <div className="flex max-w-2xl flex-col gap-6">
        <button
          onClick={() => navigate("/")}
          className="flex w-fit items-center gap-1 text-sm text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="h-4 w-4" /> Back to dashboard
        </button>

        <div>
          <h1 className="flex items-center gap-2 font-heading text-2xl font-semibold">
            <Building2 className="h-6 w-6 text-primary" /> Workspace Settings
          </h1>
          <p className="text-sm text-muted-foreground">
            Manage the company you are currently signed into.
          </p>
        </div>

        <div className="rounded-xl border bg-card p-5 shadow-sm">
          <h2 className="font-heading font-semibold">{activeName || "Workspace"}</h2>
          <div className="mt-3 flex flex-wrap items-center gap-2 text-sm text-muted-foreground">
            <Badge variant="secondary" className="capitalize">
              {active?.role || "member"}
            </Badge>
            <span className="flex items-center gap-1">
              <Users className="h-3.5 w-3.5" />
              {memberships.length} workspace{memberships.length === 1 ? "" : "s"} available to you
            </span>
          </div>
          <p className="mt-3 text-sm text-muted-foreground">
            Every customer, ledger, transaction and stock record you can see is scoped to this workspace.
            Data from other workspaces is never readable from here.
          </p>
        </div>

        <div className="rounded-xl border border-destructive/30 bg-destructive/5 p-5">
          <h2 className="flex items-center gap-2 font-heading font-semibold text-destructive">
            <ShieldAlert className="h-4 w-4" /> Danger zone
          </h2>
          <p className="mt-2 text-sm text-muted-foreground">
            Deleting this workspace permanently removes the company, its members, and every financial record
            stored under it. Other workspaces you belong to are untouched.
          </p>
          <Button
            variant="destructive"
            className="mt-4"
            disabled={!isAdmin}
            onClick={() => setConfirmOpen(true)}
          >
            <Trash2 className="mr-2 h-4 w-4" /> Delete Company / Workspace
          </Button>
          {!isAdmin && (
            <p className="mt-2 text-xs text-muted-foreground">
              Only a workspace admin can delete this workspace.
            </p>
          )}
        </div>
      </div>

      <DeleteCompanyDialog
        open={confirmOpen}
        onClose={() => setConfirmOpen(false)}
        companyId={activeId}
        companyName={activeName}
      />
    </Layout>
  );
}