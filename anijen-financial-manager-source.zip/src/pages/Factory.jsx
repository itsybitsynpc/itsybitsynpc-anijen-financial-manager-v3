import { useEffect, useMemo, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Plus, PackagePlus, Banknote, Pencil, Trash2, Calculator, Download } from "lucide-react";
import { downloadCSV } from "@/lib/csv";
import Layout from "@/components/Layout";
import { useProducts, useInvalidateProducts } from "@/hooks/useProducts";
import { usePassphraseGuard } from "@/hooks/useGuard";
import { adjustStock } from "@/lib/stock";
import { formatGHS, formatDate } from "@/lib/format";
import { inventoryCostValue, inventoryGrossValue, computeProfitBreakdown, damagedQty } from "@/lib/finance";
import { withScrollRetention } from "@/lib/scroll";
import StockIntakeDialog from "@/components/factory/StockIntakeDialog";
// factory section
import FactoryPaymentDialog from "@/components/factory/FactoryPaymentDialog";
import ProductPricingDialog from "@/components/factory/ProductPricingDialog";
import PayableEstimatorDialog from "@/components/factory/PayableEstimatorDialog";
import EditStockCell from "@/components/factory/EditStockCell";
import EditDamagedCell from "@/components/factory/EditDamagedCell";
import LowStockAlerts from "@/components/factory/LowStockAlerts";
import ProfitBreakdown from "@/components/shared/ProfitBreakdown";
import DamageExpensesCard from "@/components/factory/DamageExpensesCard";

export default function Factory() {
  const { data: products = [], isLoading } = useProducts();
  const invalidate = useInvalidateProducts();
  const [intakes, setIntakes] = useState([]);
  const [payments, setPayments] = useState([]);
  const [expenses, setExpenses] = useState([]);
  const [vehicleExpenses, setVehicleExpenses] = useState([]);
  const [intakeOpen, setIntakeOpen] = useState(false);
  const [payOpen, setPayOpen] = useState(false);
  const [editProduct, setEditProduct] = useState(null);
  const [estimatorOpen, setEstimatorOpen] = useState(false);
  const { requirePassphrase, modal } = usePassphraseGuard();

  const load = withScrollRetention(async () => {
    const ints = await base44.entities.FactoryIntake.list("-created_date", 200);
    const pays = await base44.entities.FactoryPayment.list("-created_date", 200);
    const ex = await base44.entities.Expense.list("-created_date", 500);
    const ve = await base44.entities.VehicleExpense.list("-date", 5000);
    setIntakes(ints);
    setPayments(pays);
    setExpenses(ex);
    setVehicleExpenses(ve);
  });

  useEffect(() => { load(); }, []);

  const totalStock = products.reduce((s, p) => s + Number(p.factory_stock_cartons || 0), 0);
  const damagedTotal = products.reduce((s, p) => s + damagedQty(p), 0);
  const costValue = inventoryCostValue(products);
  const grossValue = inventoryGrossValue(products);
  const totalPayments = payments.reduce((s, p) => s + Number(p.amount || 0), 0);

  const profit = useMemo(
    () => computeProfitBreakdown({ products, expenses, factoryPayments: payments, vehicleExpenses }),
    [products, expenses, payments, vehicleExpenses]
  );

  const handleExport = () => {
    const rows = [
      ...intakes.map((it) => ({
        date: formatDate(it.date || it.created_date),
        type: "Stock Intake",
        product: it.product_name || "",
        cartons: it.cartons,
        damaged: Number(it.damaged_cartons || 0),
        cost_per_carton: it.cost_per_carton,
        amount: Number(it.total_cost || 0).toFixed(2),
        method: "",
        description: it.description || "",
      })),
      ...payments.map((p) => ({
        date: formatDate(p.date || p.created_date),
        type: "Factory Payment",
        product: "",
        cartons: "",
        damaged: "",
        cost_per_carton: "",
        amount: Number(p.amount || 0).toFixed(2),
        method: p.payment_method || "",
        description: p.description || "",
      })),
    ].sort((a, b) => (b.date > a.date ? 1 : a.date > b.date ? -1 : 0));
    downloadCSV("factory-transactions", [
      { label: "Date", value: (r) => r.date },
      { label: "Type", value: (r) => r.type },
      { label: "Product", value: (r) => r.product },
      { label: "Cartons", value: (r) => r.cartons },
      { label: "Damaged Cartons", value: (r) => r.damaged },
      { label: "Cost / Carton (GHS)", value: (r) => r.cost_per_carton },
      { label: "Amount (GHS)", value: (r) => r.amount },
      { label: "Payment Method", value: (r) => r.method },
      { label: "Description", value: (r) => r.description },
    ], rows);
  };

  const deleteIntake = (it) => {
    requirePassphrase(`delete factory intake for ${it.product_name}`, async () => {
      await base44.entities.FactoryIntake.delete(it.id);
      await adjustStock(
        it.product_id,
        -(Number(it.cartons || 0) - Number(it.damaged_cartons || 0)),
        -Number(it.damaged_cartons || 0),
      );
      await invalidate();
      load();
    });
  };

  const deletePayment = (p) => {
    requirePassphrase("delete factory payment", async () => {
      await base44.entities.FactoryPayment.delete(p.id);
      load();
    });
  };

  return (
    <Layout>
      <div className="flex flex-col gap-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div>
            <h1 className="font-heading text-2xl font-semibold">Factory & Inventory</h1>
            <p className="text-sm text-muted-foreground">Stock intake, payments and product pricing in GHS</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={handleExport} disabled={intakes.length === 0 && payments.length === 0}><Download className="h-4 w-4 mr-1" /> Export CSV</Button>
            <Button variant="outline" onClick={() => setEstimatorOpen(true)}><Calculator className="h-4 w-4 mr-1" /> Estimate Payable</Button>
            <Button variant="outline" onClick={() => setPayOpen(true)}><Banknote className="h-4 w-4 mr-1" /> Factory Payment</Button>
            <Button onClick={() => setIntakeOpen(true)}><PackagePlus className="h-4 w-4 mr-1" /> Stock Intake</Button>
          </div>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          <MetricCard label="Total Stock (Net Cartons)" value={totalStock.toLocaleString()} hint={`${damagedTotal.toLocaleString()} damaged · ${products.length} products`} />
          <MetricCard label="Inventory Cost Value" value={formatGHS(costValue)} hint="stock × cost price" tone="amber" />
          <MetricCard label="Est. Gross Revenue" value={formatGHS(grossValue)} hint="stock × sell price" tone="emerald" />
          <MetricCard label="Factory Payments" value={formatGHS(totalPayments)} hint="deducted from capital" tone="rose" />
        </div>

        <LowStockAlerts products={products} />

        <ProfitBreakdown breakdown={profit} />

        <div className="rounded-xl border bg-card shadow-sm">
          <div className="flex items-center justify-between px-4 py-3 border-b">
            <h2 className="font-heading font-semibold">Products & Stock</h2>
          </div>
          <div className="sticky-header grid grid-cols-12 gap-2 px-4 py-2.5 text-xs font-semibold text-muted-foreground">
            <div className="col-span-3">Product</div>
            <div className="col-span-2 text-right">Total Stock (Net)</div>
            <div className="col-span-2 text-right">Damaged</div>
            <div className="col-span-2 text-right">Cost / Unit</div>
            <div className="col-span-2 text-right">Sell / Unit</div>
            <div className="col-span-1 text-right">Edit</div>
          </div>
          {isLoading ? (
            <div className="px-4 py-10 text-center text-sm text-muted-foreground">Loading…</div>
          ) : (
            products.map((p) => (
              <div key={p.id} className="grid grid-cols-12 gap-2 border-b px-4 py-3 text-sm last:border-0 items-center hover:bg-muted/30">
                <div className="col-span-3 font-medium truncate">{p.name}</div>
                <EditStockCell product={p} onSaved={invalidate} />
                <EditDamagedCell product={p} onSaved={invalidate} />
                <div className="col-span-2 text-right text-muted-foreground">{formatGHS(p.default_cost_price || 0).replace("GHS ", "")}</div>
                <div className="col-span-2 text-right text-muted-foreground">{formatGHS(p.default_selling_price || 0).replace("GHS ", "")}</div>
                <div className="col-span-1 flex justify-end">
                  <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setEditProduct(p)} title="Edit product"><Pencil className="h-3.5 w-3.5" /></Button>
                </div>
              </div>
            ))
          )}
        </div>

        <DamageExpensesCard products={products} />

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <div className="rounded-xl border bg-card shadow-sm overflow-hidden">
            <h2 className="font-heading font-semibold px-4 py-3 border-b">Recent Stock Intake</h2>
            <div className="divide-y">
              {intakes.length === 0 && <div className="px-4 py-6 text-center text-sm text-muted-foreground">No intake recorded.</div>}
              {intakes.map((it) => (
                <div key={it.id} className="flex items-center justify-between px-4 py-2.5 text-sm">
                  <div>
                    <p className="font-medium">
                      {it.product_name} · {Number(it.cartons || 0) - Number(it.damaged_cartons || 0)} ct
                      {Number(it.damaged_cartons || 0) > 0 && (
                        <span className="text-rose-600">
                          {" "}· {it.cartons} received − {it.damaged_cartons} damaged
                        </span>
                      )}
                    </p>
                    <p className="text-xs text-muted-foreground">{formatDate(it.date || it.created_date)} · {it.description || "—"}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-right font-medium">{formatGHS(it.total_cost || 0)}</span>
                    <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={() => deleteIntake(it)}><Trash2 className="h-3.5 w-3.5" /></Button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="rounded-xl border bg-card shadow-sm overflow-hidden">
            <h2 className="font-heading font-semibold px-4 py-3 border-b">Factory Payments / Costs</h2>
            <div className="divide-y">
              {payments.length === 0 && <div className="px-4 py-6 text-center text-sm text-muted-foreground">No payments recorded.</div>}
              {payments.map((p) => (
                <div key={p.id} className="flex items-center justify-between px-4 py-2.5 text-sm">
                  <div>
                    <p className="font-medium">{p.description || "Factory payment"}</p>
                    <p className="text-xs text-muted-foreground">{formatDate(p.date || p.created_date)}{p.payment_method ? ` · ${p.payment_method}` : ""}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-right font-medium text-rose-600">{formatGHS(p.amount || 0)}</span>
                    <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={() => deletePayment(p)}><Trash2 className="h-3.5 w-3.5" /></Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <StockIntakeDialog open={intakeOpen} onClose={() => setIntakeOpen(false)} onRefresh={load} />
      <FactoryPaymentDialog open={payOpen} onClose={() => setPayOpen(false)} onRefresh={load} />
      <ProductPricingDialog open={!!editProduct} onClose={() => setEditProduct(null)} product={editProduct} />
      <PayableEstimatorDialog open={estimatorOpen} onClose={() => setEstimatorOpen(false)} onRefresh={load} />
      {modal}
    </Layout>
  );
}

function MetricCard({ label, value, hint, tone }) {
  const toneClass = tone === "amber" ? "text-amber-600" : tone === "emerald" ? "text-emerald-600" : tone === "rose" ? "text-rose-600" : "text-foreground";
  return (
    <div className="rounded-xl border bg-card shadow-sm p-4">
      <p className="text-xs font-medium text-muted-foreground">{label}</p>
      <p className={`mt-1 font-heading text-xl font-semibold ${toneClass}`}>{value}</p>
      {hint && <p className="text-[11px] text-muted-foreground mt-0.5">{hint}</p>}
    </div>
  );
}