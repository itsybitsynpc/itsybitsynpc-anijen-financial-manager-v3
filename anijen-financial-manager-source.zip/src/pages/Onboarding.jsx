import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { setActiveCompanyId } from "@/lib/tenant";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import AuthLayout from "@/components/AuthLayout";
import { Building2, Loader2, Lock } from "lucide-react";

/**
 * Mandatory company onboarding. A new account has no workspace, so this is the
 * first screen after verification — the app name is never hardcoded, the
 * workspace is named by its owner.
 */
export default function Onboarding() {
  const [name, setName] = useState("");
  const [workspaceKey, setWorkspaceKey] = useState("");
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setSaving(true);
    try {
      const { data } = await base44.functions.invoke("provisionCompany", {
        name: name.trim(),
        ...(workspaceKey.trim() ? { workspace_key: workspaceKey.trim() } : {}),
      });
      setActiveCompanyId(data.active_company_id);
      window.location.href = "/";
    } catch (err) {
      setError(err?.response?.data?.error || err?.message || "Could not create your workspace");
      setSaving(false);
    }
  };

  return (
    <AuthLayout
      icon={Building2}
      title="What is the name of your company?"
      subtitle="This creates your private workspace. Your records are never visible to any other company."
    >
      {error && (
        <div className="mb-4 p-3 rounded-lg bg-destructive/10 text-destructive text-sm">{error}</div>
      )}
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="company">Company Name</Label>
          <Input
            id="company"
            autoFocus
            required
            minLength={2}
            maxLength={80}
            placeholder="e.g. Acme Trading Ltd"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="h-12"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="workspace-key">Workspace Key (optional)</Label>
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" aria-hidden="true" />
            <Input
              id="workspace-key"
              type="password"
              autoComplete="new-password"
              placeholder="Only this workspace needs it"
              value={workspaceKey}
              onChange={(e) => setWorkspaceKey(e.target.value)}
              className="pl-10 h-12"
            />
          </div>
          <p className="text-xs text-muted-foreground">
            When set, switching into this workspace asks for the key first. Only a SHA-256 hash is stored.
          </p>
        </div>
        <Button type="submit" className="w-full h-12 font-medium" disabled={saving || name.trim().length < 2}>
          {saving ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Creating workspace...
            </>
          ) : (
            "Create Workspace"
          )}
        </Button>
      </form>
    </AuthLayout>
  );
}