import { useEffect, useMemo, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
} from "@/components/ui/select";
import { Search, Plus, Pencil, BookOpen } from "lucide-react";
import Layout from "@/components/Layout";
import CustomerFormDialog from "@/components/customers/CustomerFormDialog";
import CustomerLedgerDialog from "@/components/customers/CustomerLedgerDialog";
import { usePassphraseGuard } from "@/hooks/useGuard";
import { withScrollRetention } from "@/lib/scroll";
import { formatGHS } from "@/lib/format";
import { computeCustomerBalance, customerOutstanding, computeCustomerProfit } from "@/lib/finance";

export default function Customers() {
  const [customers, setCustomers] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [threshold, setThreshold] = useState("any");
  const [customMin, setCustomMin] = useState("");
  const [customMax, setCustomMax] = useState("");
  const [sortMode, setSortMode] = useState("default");
  const [formOpen, setFormOpen] = useState(false);
  const [editTarget, setEditTarget] = useState(null);
  const [ledgerTarget, setLedgerTarget] = useState(null);
  const { requirePassphrase, modal } = usePassphraseGuard();

  const load = withScrollRetention(async () => {
    setLoading(true);
    try {
      const [custs, txs] = await Promise.all([
        base44.entities.Customer.list("name", 500),
        base44.entities.CustomerTransaction.list("-created_date", 1000),
      ]);
      setCustomers(custs);
      setTransactions(txs);
    } finally {
      setLoading(false);
    }
  });

  useEffect(() => { load(); }, []);

  const enriched = useMemo(
    () => customers.map((c) => ({
      ...c,
      _out: customerOutstanding(c, transactions),
      _bal: computeCustomerBalance(c, transactions),
      _profit: computeCustomerProfit(c, transactions),
      _hasTx: transactions.some((t) => t?.customer_id === c.id),
    })),
    [customers, transactions]
  );

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    let arr = enriched;
    if (q) arr = arr.filter((c) => c.name?.toLowerCase().includes(q));

    if (statusFilter === "outstanding") arr = arr.filter((c) => c._bal > 0);
    else if (statusFilter === "zero") arr = arr.filter((c) => c._bal <= 0);

    if (threshold === "lt") arr = arr.filter((c) => c._bal < 10000);
    else if (threshold === "gte") arr = arr.filter((c) => c._bal >= 10000);
    else if (threshold === "custom") {
      const mn = customMin === "" ? -Infinity : Number(customMin);
      const mx = customMax === "" ? Infinity : Number(customMax);
      arr = arr.filter((c) => c._bal >= mn && c._bal <= mx);
    }

    if (sortMode === "desc") arr = [...arr].sort((a, b) => b._bal - a._bal);
    else if (sortMode === "asc") arr = [...arr].sort((a, b) => a._bal - b._bal);

    return arr;
  }, [enriched, search, statusFilter, threshold, customMin, customMax, sortMode]);

  const handleSaveCustomer = async (data) => {
    if (editTarget) {
      await base44.entities.Customer.update(editTarget.id, data);
    } else {
      await base44.entities.Customer.create(data);
    }
    load();
  };

  const handleDeleteCustomer = (c) => {
    requirePassphrase(`delete customer profile: ${c.name}`, async () => {
      const myTx = transactions.filter((t) => t.customer_id === c.id);
      if (myTx.length) {
        await base44.entities.CustomerTransaction.deleteMany({ customer_id: c.id });
      }
      await base44.entities.Customer.delete(c.id);
      load();
    });
  };

  return (
    <Layout>
      <div className="flex flex-col gap-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div>
            <h1 className="font-heading text-2xl font-semibold">Customers</h1>
            <p className="text-sm text-muted-foreground">{customers.length} registered · tracking balances in GHS</p>
          </div>
          <Button onClick={() => { setEditTarget(null); setFormOpen(true); }}>
            <Plus className="h-4 w-4 mr-1" /> Add Customer
          </Button>
        </div>

        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search customers by name…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9 max-w-md"
          />
        </div>

        <div className="flex flex-wrap items-end gap-2">
          <div className="flex flex-col gap-1">
            <span className="text-[11px] font-medium text-muted-foreground">Status</span>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[190px]"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Customers</SelectItem>
                <SelectItem value="outstanding">With Outstanding Balance</SelectItem>
                <SelectItem value="zero">No Outstanding (Zero/Credit)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex flex-col gap-1">
            <span className="text-[11px] font-medium text-muted-foreground">Balance Threshold</span>
            <Select value={threshold} onValueChange={setThreshold}>
              <SelectTrigger className="w-[200px]"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="any">Any Balance</SelectItem>
                <SelectItem value="lt">{"Balance < GHS 10,000"}</SelectItem>
                <SelectItem value="gte">{"Balance ≥ GHS 10,000"}</SelectItem>
                <SelectItem value="custom">Custom Range…</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {threshold === "custom" && (
            <div className="flex flex-col gap-1">
              <span className="text-[11px] font-medium text-muted-foreground">Custom Range (GHS)</span>
              <div className="flex items-center gap-1">
                <Input type="number" placeholder="Min" value={customMin} onChange={(e) => setCustomMin(e.target.value)} className="w-24" />
                <span className="text-muted-foreground">–</span>
                <Input type="number" placeholder="Max" value={customMax} onChange={(e) => setCustomMax(e.target.value)} className="w-24" />
              </div>
            </div>
          )}

          <div className="flex flex-col gap-1">
            <span className="text-[11px] font-medium text-muted-foreground">Sort by Balance</span>
            <Select value={sortMode} onValueChange={setSortMode}>
              <SelectTrigger className="w-[190px]"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="default">Default (A → Z)</SelectItem>
                <SelectItem value="desc">High to Low</SelectItem>
                <SelectItem value="asc">Low to High</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="rounded-xl border bg-card shadow-sm">
          <div className="sticky-header rounded-t-xl grid grid-cols-12 gap-2 px-4 py-2.5 text-xs font-semibold text-muted-foreground">
            <div className="col-span-3">Customer</div>
            <div className="col-span-2 text-right">Previous Balance</div>
            <div className="col-span-2 text-right">Outstanding</div>
            <div className="col-span-2 text-right">Total Debt</div>
            <div className="col-span-1 text-right">Profit</div>
            <div className="col-span-2 text-right">Actions</div>
          </div>
          {loading ? (
            <div className="px-4 py-10 text-center text-sm text-muted-foreground">Loading…</div>
          ) : filtered.length === 0 ? (
            <div className="px-4 py-10 text-center text-sm text-muted-foreground">No customers match the current filters.</div>
          ) : (
            filtered.map((c) => {
              const bal = c._bal;
              const out = c._out;
              const profit = c._profit;
              return (
                <div key={c.id} className="grid grid-cols-12 gap-2 border-b px-4 py-3 text-sm last:border-0 items-center hover:bg-muted/30">
                  <div className="col-span-3 font-medium">{c.name}</div>
                  <div className="col-span-2 text-right font-medium rounded px-1 py-0.5 bg-rose-50 text-rose-800">{formatGHS(c.previous_balance || 0)}</div>
                  <div className="col-span-2 text-right font-semibold rounded px-1 py-0.5 bg-amber-50 text-amber-900">{formatGHS(out)}</div>
                  <div className="col-span-2 text-right font-semibold rounded px-1 py-0.5 bg-slate-100 text-slate-900">{formatGHS(bal)}</div>
                  <div className="col-span-1 text-right font-semibold rounded px-1 py-0.5 bg-emerald-50 text-emerald-800 text-xs">{formatGHS(profit)}</div>
                  <div className="col-span-2 flex justify-end gap-1">
                    <Button variant="outline" size="sm" onClick={() => setLedgerTarget(c)} title="Ledger">
                      <BookOpen className="h-3.5 w-3.5" />
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => { setEditTarget(c); setFormOpen(true); }} title="Edit">
                      <Pencil className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      <CustomerFormDialog open={formOpen} onClose={() => setFormOpen(false)} onSave={handleSaveCustomer} customer={editTarget} />
      <CustomerLedgerDialog
        customer={ledgerTarget}
        open={!!ledgerTarget}
        onClose={() => setLedgerTarget(null)}
        transactions={transactions}
        onRefresh={load}
      />
      {modal}
    </Layout>
  );
}