import { useEffect, useMemo, useState } from "react";
import { base44 } from "@/api/base44Client";
import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Plus, Truck, Pencil, Trash2 } from "lucide-react";
import { formatGHS, formatDate } from "@/lib/format";
import { withScrollRetention } from "@/lib/scroll";
import { usePassphraseGuard } from "@/hooks/useGuard";
import VehicleFormDialog from "@/components/vehicles/VehicleFormDialog";
import VehicleLedgerDialog from "@/components/vehicles/VehicleLedgerDialog";
import VehicleExpenseFormDialog from "@/components/vehicles/VehicleExpenseFormDialog";

export default function Vehicles() {
  const [vehicles, setVehicles] = useState([]);
  const [expenses, setExpenses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [formOpen, setFormOpen] = useState(false);
  const [editingVehicle, setEditingVehicle] = useState(null);
  const [ledgerVehicle, setLedgerVehicle] = useState(null);
  const [expenseVehicle, setExpenseVehicle] = useState(null);
  const { requirePassphrase, modal } = usePassphraseGuard();

  const load = withScrollRetention(async () => {
    setLoading(true);
    try {
      const [v, ex] = await Promise.all([
        base44.entities.Vehicle.list("-created_date", 500),
        base44.entities.VehicleExpense.list("-date", 5000),
      ]);
      setVehicles(v);
      setExpenses(ex);
    } finally {
      setLoading(false);
    }
  });

  useEffect(() => { load(); }, []);

  const byVehicle = useMemo(() => {
    const map = {};
    for (const e of expenses) {
      map[e.vehicle_id] = map[e.vehicle_id] || { total: 0, recent: [] };
      map[e.vehicle_id].total += Number(e.amount || 0);
      map[e.vehicle_id].recent.push(e);
    }
    return map;
  }, [expenses]);

  const handleDeleteVehicle = (v) => {
    requirePassphrase(`delete vehicle ${v.name}`, async () => {
      await base44.entities.VehicleExpense.deleteMany({ vehicle_id: v.id });
      await base44.entities.Vehicle.delete(v.id);
      load();
    });
  };

  return (
    <Layout>
      <div className="flex flex-col gap-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="font-heading text-2xl font-semibold">Company Vehicles</h1>
            <p className="text-sm text-muted-foreground">Fleet directory & expense tracking (GHS)</p>
          </div>
          <Button onClick={() => { setEditingVehicle(null); setFormOpen(true); }}><Plus className="h-4 w-4" /> Add New Vehicle</Button>
        </div>

        {loading && <div className="text-center text-sm text-muted-foreground">Loading fleet…</div>}
        {!loading && vehicles.length === 0 && (
          <div className="rounded-xl border bg-card p-10 text-center text-sm text-muted-foreground">
            No vehicles registered yet. Click "Add New Vehicle" to begin.
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {vehicles.map((v) => {
            const info = byVehicle[v.id] || { total: 0, recent: [] };
            const recent = [...info.recent].sort((a, b) => new Date(b.date) - new Date(a.date)).slice(0, 3);
            return (
              <div key={v.id} className="rounded-xl border bg-card shadow-sm p-4 flex flex-col gap-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-sky-100 text-sky-600"><Truck className="h-5 w-5" /></span>
                    <div>
                      <p className="font-heading font-semibold leading-tight">{v.name}</p>
                      <p className="text-xs text-muted-foreground">{v.registration_number || "No reg."}</p>
                    </div>
                  </div>
                  <div className="flex gap-1">
                    <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => { setEditingVehicle(v); setFormOpen(true); }} title="Edit"><Pencil className="h-3.5 w-3.5" /></Button>
                    <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={() => handleDeleteVehicle(v)} title="Delete"><Trash2 className="h-3.5 w-3.5" /></Button>
                  </div>
                </div>
                <div className="text-sm space-y-0.5">
                  <p className="text-muted-foreground"><span className="text-foreground/70">Driver:</span> {v.assigned_driver || "—"}</p>
                  {v.notes && <p className="text-muted-foreground line-clamp-2">{v.notes}</p>}
                </div>
                <div className="flex items-center justify-between rounded-lg bg-muted/40 px-3 py-2">
                  <span className="text-xs text-muted-foreground">Total Expenses</span>
                  <span className="font-heading font-semibold text-rose-600">{formatGHS(info.total)}</span>
                </div>
                <div>
                  <p className="text-xs font-medium text-muted-foreground mb-1">Recent Activity</p>
                  {recent.length === 0 ? (
                    <p className="text-xs text-muted-foreground">No expenses logged.</p>
                  ) : (
                    <ul className="space-y-1 text-xs">
                      {recent.map((e) => (
                        <li key={e.id} className="flex justify-between">
                          <span>{e.expense_type} · {formatDate(e.date)}</span>
                          <span className="text-rose-600 font-medium">{formatGHS(e.amount)}</span>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
                <div className="flex gap-2 pt-1">
                  <Button size="sm" className="flex-1" onClick={() => setExpenseVehicle(v)}><Plus className="h-4 w-4" /> Log Expense</Button>
                  <Button size="sm" variant="outline" className="flex-1" onClick={() => setLedgerVehicle(v)}>View Ledger</Button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <VehicleFormDialog open={formOpen} onClose={() => setFormOpen(false)} onSaved={load} vehicle={editingVehicle} />
      <VehicleLedgerDialog open={!!ledgerVehicle} onClose={() => setLedgerVehicle(null)} vehicle={ledgerVehicle} onChanged={load} />
      <VehicleExpenseFormDialog open={!!expenseVehicle} onClose={() => setExpenseVehicle(null)} onSaved={load} vehicle={expenseVehicle} />
      {modal}
    </Layout>
  );
}