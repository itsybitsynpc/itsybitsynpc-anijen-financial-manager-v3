import { useState } from "react";
import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { useSuppliers } from "@/hooks/useSuppliers";
import { useCapital } from "@/hooks/useCapital";
import { base44 } from "@/api/base44Client";
import { formatGHS } from "@/lib/format";
import { toast } from "@/components/ui/use-toast";
import { usePassphraseGuard } from "@/hooks/useGuard";
import DebtSummary from "@/components/suppliers/DebtSummary";
import SupplierTable from "@/components/suppliers/SupplierTable";
import SupplierFormDialog from "@/components/suppliers/SupplierFormDialog";
import SupplierDebtDialog from "@/components/suppliers/SupplierDebtDialog";
import SupplierRepayDialog from "@/components/suppliers/SupplierRepayDialog";
import SupplierHistoryDialog from "@/components/suppliers/SupplierHistoryDialog";

export default function OurDebt() {
  const { suppliers, transactions, loading, reload: reloadSuppliers } = useSuppliers();
  const { accounts: capitalAccounts, transactions: capitalTransactions, reload: reloadCapital } = useCapital();
  const { requirePassphrase, modal } = usePassphraseGuard();
  const [supplierDialog, setSupplierDialog] = useState({ open: false, initial: null });
  const [debtDialog, setDebtDialog] = useState({ open: false, supplier: null, initial: null });
  const [repayDialog, setRepayDialog] = useState({ open: false, supplier: null, initial: null });
  const [history, setHistory] = useState({ open: false, supplier: null });

  // Repayments touch BOTH supplier debt and company capital, so refresh both.
  const refreshAll = () => { reloadSuppliers(); reloadCapital(); };

  const openAddSupplier = () => setSupplierDialog({ open: true, initial: null });
  const openAddDebt = (s) => setDebtDialog({ open: true, supplier: s, initial: null });
  const openRepay = (s) => setRepayDialog({ open: true, supplier: s, initial: null });
  const openHistory = (s) => setHistory({ open: true, supplier: s });

  const editTx = (t) => {
    const supplier = suppliers.find((s) => s.id === t.supplier_id);
    setHistory({ open: false, supplier: null });
    if (t.type === "repayment") setRepayDialog({ open: true, supplier, initial: t });
    else setDebtDialog({ open: true, supplier, initial: t });
  };

  const deleteTx = (t) => {
    requirePassphrase(`delete supplier ${t.type} of ${formatGHS(t.amount)}`, async () => {
      if (t.type === "repayment" && t.linked_capital_tx_id) {
        await base44.entities.CapitalTransaction.delete(t.linked_capital_tx_id);
      }
      await base44.entities.SupplierTransaction.delete(t.id);
      toast({ title: "Transaction deleted", description: "Debt and capital totals recalculated." });
      refreshAll();
    });
  };

  return (
    <Layout>
      <div className="flex flex-col gap-6 pb-16 md:pb-8">
        <div className="flex items-end justify-between gap-3 flex-wrap">
          <div>
            <h1 className="font-heading text-2xl font-semibold">Our Debt (Suppliers)</h1>
            <p className="text-sm text-muted-foreground">Track money owed to suppliers, linked to company capital (GHS)</p>
          </div>
          <Button className="gap-2" onClick={openAddSupplier}><Plus className="h-4 w-4" />Add Supplier</Button>
        </div>

        <DebtSummary suppliers={suppliers} transactions={transactions} />

        <SupplierTable
          suppliers={suppliers}
          transactions={transactions}
          onAddDebt={openAddDebt}
          onRepay={openRepay}
          onHistory={openHistory}
        />

        {loading && <div className="text-center text-sm text-muted-foreground">Loading…</div>}
      </div>

      <SupplierFormDialog open={supplierDialog.open} onClose={() => setSupplierDialog((s) => ({ ...s, open: false }))} onSaved={reloadSuppliers} initial={supplierDialog.initial} />
      <SupplierDebtDialog open={debtDialog.open} onClose={() => setDebtDialog((s) => ({ ...s, open: false }))} onSaved={refreshAll} supplier={debtDialog.supplier} initial={debtDialog.initial} />
      <SupplierRepayDialog open={repayDialog.open} onClose={() => setRepayDialog((s) => ({ ...s, open: false }))} onSaved={refreshAll} supplier={repayDialog.supplier} capitalAccounts={capitalAccounts} capitalTransactions={capitalTransactions} supplierTransactions={transactions} initial={repayDialog.initial} />
      <SupplierHistoryDialog open={history.open} onClose={() => setHistory({ open: false, supplier: null })} supplier={history.supplier} transactions={transactions} onEdit={editTx} onDelete={deleteTx} />
      {modal}
    </Layout>
  );
}