import { useEffect, useMemo, useState } from "react";
import { base44 } from "@/api/base44Client";
import Layout from "@/components/Layout";
import { TrendingUp, TrendingDown, CalendarDays, BarChart3, Percent, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { formatGHS } from "@/lib/format";
import { withScrollRetention } from "@/lib/scroll";
import { buildMonthlySeries } from "@/lib/trends";
import { downloadCSV } from "@/lib/csv";
import ProfitGrowthChart from "@/components/trends/ProfitGrowthChart";
import ExpenseRatioChart from "@/components/trends/ExpenseRatioChart";

export default function Trends() {
  const [custTx, setCustTx] = useState([]);
  const [incomeLogs, setIncomeLogs] = useState([]);
  const [factoryPayments, setFactoryPayments] = useState([]);
  const [expenses, setExpenses] = useState([]);
  const [vehicleExpenses, setVehicleExpenses] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = withScrollRetention(async () => {
    setLoading(true);
    try {
      // Load sequentially to stay within Base44 request rate limits.
      const ct = await base44.entities.CustomerTransaction.list("-created_date", 5000);
      const il = await base44.entities.IncomeLog.list("-created_date", 2000);
      const fp = await base44.entities.FactoryPayment.list("-created_date", 2000);
      const ex = await base44.entities.Expense.list("-created_date", 2000);
      const ve = await base44.entities.VehicleExpense.list("-date", 5000);
      setCustTx(ct);
      setIncomeLogs(il);
      setFactoryPayments(fp);
      setExpenses(ex);
      setVehicleExpenses(ve);
    } finally {
      setLoading(false);
    }
  });

  useEffect(() => { load(); }, []);

  const rows = useMemo(
    () => buildMonthlySeries({ custTx, incomeLogs, factoryPayments, expenses, vehicleExpenses }),
    [custTx, incomeLogs, factoryPayments, expenses, vehicleExpenses]
  );

  const summary = useMemo(() => {
    const totalProfit = rows.reduce((s, r) => s + r.profit, 0);
    const totalRevenue = rows.reduce((s, r) => s + r.revenue, 0);
    const totalExpenses = rows.reduce((s, r) => s + r.expenses, 0);
    const avgProfit = rows.length ? totalProfit / rows.length : 0;
    const best = rows.reduce(
      (acc, r) => (r.profit > (acc?.profit ?? -Infinity) ? r : acc),
      null
    );
    const worst = rows.reduce(
      (acc, r) => (r.profit < (acc?.profit ?? Infinity) ? r : acc),
      null
    );
    const ratioRows = rows.filter((r) => r.revenue > 0);
    const avgRatio = ratioRows.length
      ? ratioRows.reduce((s, r) => s + r.expenseRatio, 0) / ratioRows.length
      : 0;
    return { totalProfit, totalRevenue, totalExpenses, avgProfit, best, worst, avgRatio };
  }, [rows]);

  const handleExportCSV = () => {
    downloadCSV(
      `anijen-monthly-analytics-${new Date().toISOString().slice(0, 10)}`,
      [
        { label: "Month", value: (r) => r.label },
        { label: "Revenue (GHS)", value: (r) => r.revenue.toFixed(2) },
        { label: "Profit (GHS)", value: (r) => r.profit.toFixed(2) },
        { label: "Growth (%)", value: (r) => (r.growth == null ? "" : r.growth.toFixed(1)) },
        { label: "Income (GHS)", value: (r) => r.income.toFixed(2) },
        { label: "Expenses (GHS)", value: (r) => r.expenses.toFixed(2) },
        { label: "Expense Ratio (%)", value: (r) => r.expenseRatio.toFixed(1) },
      ],
      [...rows].reverse()
    );
  };

  return (
    <Layout>
      <div className="flex flex-col gap-6">
        <div>
          <h1 className="font-heading text-2xl font-semibold">Visual Trends</h1>
          <p className="text-sm text-muted-foreground">Monthly profit growth and expense ratios to spot peak business periods</p>
        </div>

        {loading ? (
          <div className="rounded-xl border bg-card shadow-sm p-10 text-center text-sm text-muted-foreground">
            Loading trends…
          </div>
        ) : rows.length === 0 ? (
          <div className="rounded-xl border bg-card shadow-sm p-10 text-center text-sm text-muted-foreground">
            No transaction data yet — record sales and expenses to see trends.
          </div>
        ) : (
          <>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
              <SummaryCard label="Total Profit (All-Time)" value={formatGHS(summary.totalProfit)} icon={TrendingUp} tone="emerald" />
              <SummaryCard label="Avg Monthly Profit" value={formatGHS(summary.avgProfit)} icon={BarChart3} tone="primary" />
              <SummaryCard label="Peak Profit Month" value={summary.best ? `${summary.best.label} · ${formatGHS(summary.best.profit)}` : "—"} icon={CalendarDays} tone="sky" />
              <SummaryCard label="Avg Expense Ratio" value={`${summary.avgRatio.toFixed(1)}%`} icon={Percent} tone="amber" />
            </div>

            <ProfitGrowthChart data={rows} />
            <ExpenseRatioChart data={rows} />

            <div className="rounded-xl border bg-card shadow-sm overflow-hidden">
              <div className="px-4 py-3 border-b flex items-center justify-between gap-3">
                <div>
                  <h2 className="font-heading font-semibold">Monthly Breakdown</h2>
                  <p className="text-xs text-muted-foreground">Per-month revenue, profit, growth and expense ratio</p>
                </div>
                <Button variant="outline" size="sm" onClick={handleExportCSV} className="shrink-0">
                  <Download className="h-4 w-4" />
                  Export to Spreadsheet
                </Button>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="sticky-header text-left text-xs text-muted-foreground">
                      <th className="px-4 py-2 font-semibold">Month</th>
                      <th className="px-4 py-2 font-semibold text-right">Revenue</th>
                      <th className="px-4 py-2 font-semibold text-right">Profit</th>
                      <th className="px-4 py-2 font-semibold text-right">Growth</th>
                      <th className="px-4 py-2 font-semibold text-right">Income</th>
                      <th className="px-4 py-2 font-semibold text-right">Expenses</th>
                      <th className="px-4 py-2 font-semibold text-right">Expense Ratio</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[...rows].reverse().map((r) => (
                      <tr key={r.key} className="border-t hover:bg-muted/30">
                        <td className="px-4 py-2.5 font-medium">{r.label}</td>
                        <td className="px-4 py-2.5 text-right">{formatGHS(r.revenue)}</td>
                        <td className="px-4 py-2.5 text-right font-medium text-emerald-600">{formatGHS(r.profit)}</td>
                        <td className="px-4 py-2.5 text-right">
                          {r.growth == null ? (
                            <span className="text-muted-foreground">—</span>
                          ) : (
                            <span className={`inline-flex items-center gap-0.5 ${r.growth >= 0 ? "text-emerald-600" : "text-rose-600"}`}>
                              {r.growth >= 0 ? <TrendingUp className="h-3.5 w-3.5" /> : <TrendingDown className="h-3.5 w-3.5" />}
                              {r.growth >= 0 ? "+" : ""}{r.growth.toFixed(1)}%
                            </span>
                          )}
                        </td>
                        <td className="px-4 py-2.5 text-right">{formatGHS(r.income)}</td>
                        <td className="px-4 py-2.5 text-right text-rose-600">{formatGHS(r.expenses)}</td>
                        <td className="px-4 py-2.5 text-right">
                          <span className={`rounded px-1.5 py-0.5 text-xs font-medium ${r.expenseRatio > 50 ? "bg-rose-50 text-rose-700" : "bg-amber-50 text-amber-800"}`}>
                            {r.expenseRatio.toFixed(1)}%
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </>
        )}
      </div>
    </Layout>
  );
}

function SummaryCard({ label, value, icon: Icon, tone }) {
  const toneMap = {
    primary: "bg-primary/10 text-primary",
    emerald: "bg-emerald-100 text-emerald-600",
    rose: "bg-rose-100 text-rose-600",
    amber: "bg-amber-100 text-amber-600",
    sky: "bg-sky-100 text-sky-600",
  };
  return (
    <div className="rounded-xl border bg-card shadow-sm p-4">
      <div className="flex items-center justify-between">
        <p className="text-xs font-medium text-muted-foreground">{label}</p>
        <span className={`flex h-8 w-8 items-center justify-center rounded-lg ${toneMap[tone] || "bg-muted text-muted-foreground"}`}>
          <Icon className="h-4 w-4" />
        </span>
      </div>
      <p className="mt-2 font-heading text-lg font-semibold">{value}</p>
    </div>
  );
}