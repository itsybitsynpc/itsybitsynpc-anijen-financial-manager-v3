import { useState } from "react";
import Layout from "@/components/Layout";
import { useCapital } from "@/hooks/useCapital";
import { Button } from "@/components/ui/button";
import { Plus, ArrowRightLeft, Landmark, Smartphone, Wallet, Receipt } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import CapitalSummary from "@/components/capital/CapitalSummary";
import AccountCard from "@/components/capital/AccountCard";
import AccountFormDialog from "@/components/capital/AccountFormDialog";
import TransactionFormDialog from "@/components/capital/TransactionFormDialog";
import TransactionList from "@/components/capital/TransactionList";
import { accountTransactions } from "@/lib/capital";
import { base44 } from "@/api/base44Client";
import { formatGHS } from "@/lib/format";
import { toast } from "@/components/ui/use-toast";
import { usePassphraseGuard } from "@/hooks/useGuard";

const TABS = [
  { k: "overview", l: "Overview", icon: Landmark },
  { k: "banks", l: "Banks", icon: Landmark },
  { k: "momo", l: "Mobile Money", icon: Smartphone },
  { k: "cash", l: "Cash at Hand", icon: Wallet },
  { k: "transactions", l: "Bank Transactions", icon: Receipt },
];

export default function OtherCapital() {
  const { accounts, transactions, loading, reload } = useCapital();
  const { requirePassphrase, modal } = usePassphraseGuard();
  const [tab, setTab] = useState("overview");
  const [acctDialog, setAcctDialog] = useState({ open: false, initial: null, type: "bank" });
  const [txnDialog, setTxnDialog] = useState({ open: false, initial: null, initialMode: "inflow", lockAccount: null });
  const [history, setHistory] = useState({ open: false, account: null });

  const banks = accounts.filter((a) => a.account_type === "bank");
  const momos = accounts.filter((a) => a.account_type === "momo");
  const cash = accounts.find((a) => a.account_type === "cash");

  const openAdd = (type) => setAcctDialog({ open: true, initial: null, type });
  const editAccount = (a) => setAcctDialog({ open: true, initial: a, type: a.account_type });
  const openDeposit = (a) => setTxnDialog({ open: true, initial: null, initialMode: "inflow", lockAccount: a });
  const openWithdraw = (a) => setTxnDialog({ open: true, initial: null, initialMode: "outflow", lockAccount: a });
  const openRecord = () => setTxnDialog({ open: true, initial: null, initialMode: "inflow", lockAccount: null });
  const openTransfer = () => setTxnDialog({ open: true, initial: null, initialMode: "transfer", lockAccount: null });
  const editTxn = (t) => setTxnDialog({ open: true, initial: t, initialMode: t.direction, lockAccount: null });
  const openHistory = (a) => setHistory({ open: true, account: a });

  const deleteTxn = (t) => {
    requirePassphrase(`delete capital transaction of ${formatGHS(t.amount)}`, async () => {
      await base44.entities.CapitalTransaction.delete(t.id);
      toast({ title: "Transaction deleted", description: "Affected balances recalculated." });
      setHistory({ open: false, account: null });
      reload();
    });
  };

  const deleteAccount = (a) => {
    requirePassphrase(`delete ${a.account_type} account "${a.name}"`, async () => {
      await base44.entities.CapitalAccount.delete(a.id);
      toast({ title: "Account deleted" });
      reload();
    });
  };

  const sortedTxns = [...transactions].sort((a, b) => new Date(b.date || b.created_date) - new Date(a.date || a.created_date));
  const histTxns = history.account ? accountTransactions(history.account, transactions) : [];

  return (
    <Layout>
      <div className="flex flex-col gap-6 pb-16 md:pb-8">
        <div className="flex items-end justify-between gap-3 flex-wrap">
          <div>
            <h1 className="font-heading text-2xl font-semibold">Other Capital Distribution</h1>
            <p className="text-sm text-muted-foreground">Track capital across banks, Mobile Money, and cash (GHS)</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" className="gap-2" onClick={openTransfer}><ArrowRightLeft className="h-4 w-4" />Transfer</Button>
            <Button className="gap-2" onClick={openRecord}><Plus className="h-4 w-4" />Record Transaction</Button>
          </div>
        </div>

        <CapitalSummary accounts={accounts} transactions={transactions} />

        <div className="flex gap-1 rounded-lg bg-muted/50 p-1 overflow-x-auto">
          {TABS.map((t) => (
            <button
              key={t.k}
              onClick={() => setTab(t.k)}
              className={`flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium whitespace-nowrap ${tab === t.k ? "bg-background shadow-sm" : "text-muted-foreground hover:text-foreground"}`}
            >
              <t.icon className="h-3.5 w-3.5" />{t.l}
            </button>
          ))}
        </div>

        {tab === "overview" && (
          <Panel title="Recent Activity">
            <TransactionList transactions={sortedTxns.slice(0, 12)} emptyText="No transactions recorded yet." />
          </Panel>
        )}

        {tab === "banks" && (
          <AccountsGrid
            addLabel="Add Bank"
            onAdd={() => openAdd("bank")}
            onEdit={editAccount}
            onDelete={deleteAccount}
            onDeposit={openDeposit}
            onWithdraw={openWithdraw}
            onOpenHistory={openHistory}
            accounts={banks}
            allAccounts={accounts}
            transactions={transactions}
            emptyText="No bank accounts yet. Add your first bank."
          />
        )}

        {tab === "momo" && (
          <AccountsGrid
            addLabel="Add MoMo Account"
            onAdd={() => openAdd("momo")}
            onEdit={editAccount}
            onDelete={deleteAccount}
            onDeposit={openDeposit}
            onWithdraw={openWithdraw}
            onOpenHistory={openHistory}
            accounts={momos}
            allAccounts={accounts}
            transactions={transactions}
            inLabel="Received"
            outLabel="Sent"
            emptyText="No MoMo accounts yet. Add your first wallet."
          />
        )}

        {tab === "cash" && (
          <div className="space-y-4">
            {cash ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <AccountCard
                  account={cash}
                  transactions={transactions}
                  inLabel="Cash In"
                  outLabel="Cash Out"
                  onDeposit={() => openDeposit(cash)}
                  onWithdraw={() => openWithdraw(cash)}
                  onEdit={() => editAccount(cash)}
                  onOpenHistory={() => openHistory(cash)}
                />
              </div>
            ) : (
              <Panel title="Cash at Hand">
                <div className="px-4 py-6 text-center text-sm text-muted-foreground">
                  No cash account yet.{" "}
                  <Button variant="link" className="px-1" onClick={() => openAdd("cash")}>Set up Cash at Hand</Button>
                </div>
              </Panel>
            )}
          </div>
        )}

        {tab === "transactions" && (
          <Panel title="All Capital Transactions">
            <TransactionList transactions={sortedTxns} onEdit={editTxn} onDelete={deleteTxn} emptyText="No transactions yet. Use Record Transaction or Transfer above." />
          </Panel>
        )}

        {loading && <div className="text-center text-sm text-muted-foreground">Loading…</div>}
      </div>

      <AccountFormDialog
        open={acctDialog.open}
        onClose={() => setAcctDialog((s) => ({ ...s, open: false }))}
        onSaved={reload}
        initial={acctDialog.initial}
        type={acctDialog.type}
      />
      <TransactionFormDialog
        open={txnDialog.open}
        onClose={() => setTxnDialog((s) => ({ ...s, open: false }))}
        onSaved={reload}
        accounts={accounts}
        initial={txnDialog.initial}
        initialMode={txnDialog.initialMode}
        lockAccount={txnDialog.lockAccount}
      />
      <Dialog open={history.open} onOpenChange={(o) => !o && setHistory({ open: false, account: null })}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>{history.account?.name} — Transaction History</DialogTitle>
          </DialogHeader>
          <div className="max-h-[60vh] overflow-auto">
            <TransactionList
              transactions={histTxns}
              onEdit={(t) => { setHistory({ open: false, account: null }); editTxn(t); }}
              onDelete={deleteTxn}
              emptyText="No transactions for this account."
            />
          </div>
        </DialogContent>
      </Dialog>
      {modal}
    </Layout>
  );
}

function Panel({ title, children }) {
  return (
    <div className="rounded-xl border bg-card shadow-sm overflow-hidden">
      <h2 className="font-heading font-semibold px-4 py-3 border-b">{title}</h2>
      {children}
    </div>
  );
}

function AccountsGrid({ accounts, allAccounts, transactions, addLabel, onAdd, onEdit, onDelete, onDeposit, onWithdraw, onOpenHistory, inLabel, outLabel, emptyText }) {
  return (
    <div className="space-y-4">
      <div className="flex justify-end">
        <Button variant="outline" className="gap-2" onClick={onAdd}><Plus className="h-4 w-4" />{addLabel}</Button>
      </div>
      {accounts.length === 0 ? (
        <div className="rounded-xl border bg-card p-6 text-center text-sm text-muted-foreground">{emptyText}</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {accounts.map((a) => (
            <AccountCard
              key={a.id}
              account={a}
              transactions={transactions}
              inLabel={inLabel}
              outLabel={outLabel}
              onDeposit={() => onDeposit(a)}
              onWithdraw={() => onWithdraw(a)}
              onEdit={() => onEdit(a)}
              onDelete={() => onDelete(a)}
              onOpenHistory={() => onOpenHistory(a)}
            />
          ))}
        </div>
      )}
    </div>
  );
}