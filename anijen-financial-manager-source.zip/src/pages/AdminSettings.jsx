import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Shield, ShieldCheck, Lock, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import Layout from "@/components/Layout";
import ResetBalancesCard from "@/components/workspace/ResetBalancesCard";
import { base44 } from "@/api/base44Client";

export default function AdminSettings() {
  const navigate = useNavigate();
  const [test, setTest] = useState("");
  const [status, setStatus] = useState(null);
  const [checking, setChecking] = useState(false);

  const handleTest = async (e) => {
    e.preventDefault();
    setChecking(true);
    setStatus(null);
    try {
      const res = await base44.functions.invoke("verifyPassphrase", { passphrase: test });
      setStatus(res.data?.valid ? "valid" : "invalid");
    } catch (err) {
      setStatus("error");
    } finally {
      setChecking(false);
    }
  };

  return (
    <Layout>
      <div className="flex flex-col gap-6 max-w-2xl">
        <button onClick={() => navigate("/")} className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground w-fit">
          <ArrowLeft className="h-4 w-4" /> Back to dashboard
        </button>

        <div>
          <h1 className="font-heading text-2xl font-semibold flex items-center gap-2">
            <Shield className="h-6 w-6 text-primary" /> Admin Settings
          </h1>
          <p className="text-sm text-muted-foreground">Hidden admin panel · passphrase-protected delete controls</p>
        </div>

        <div className="rounded-xl border bg-card shadow-sm p-5 flex flex-col sm:flex-row sm:items-center gap-3 sm:justify-between">
          <div>
            <p className="font-heading font-semibold">Workspace &amp; company controls</p>
            <p className="text-sm text-muted-foreground mt-1">
              Manage the active company, its members, and permanent workspace deletion.
            </p>
          </div>
          <Button variant="outline" onClick={() => navigate("/workspace-settings")}>
            Open Workspace Settings
          </Button>
        </div>

        <div className="rounded-xl border bg-card shadow-sm p-5">
          <div className="flex items-start gap-3">
            <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-emerald-100 text-emerald-600">
              <ShieldCheck className="h-5 w-5" />
            </span>
            <div>
              <p className="font-heading font-semibold">Delete Protection: Active</p>
              <p className="text-sm text-muted-foreground mt-1">
                All deletions across Customers, Sales Persons and Factory require the master admin passphrase.
                The passphrase is stored securely in backend settings and verified server-side before any
                transaction, payment log, or profile is removed.
              </p>
            </div>
          </div>
        </div>

        <ResetBalancesCard />

        <div className="rounded-xl border bg-card shadow-sm p-5">
          <h2 className="font-heading font-semibold flex items-center gap-2"><Lock className="h-4 w-4" /> Test Passphrase</h2>
          <p className="text-sm text-muted-foreground mt-1 mb-4">Verify the configured passphrase works.</p>
          <form onSubmit={handleTest} className="flex flex-col sm:flex-row gap-2 items-start sm:items-end">
            <div className="space-y-1.5 flex-1 w-full">
              <Label htmlFor="test">Passphrase</Label>
              <Input id="test" type="password" value={test} onChange={(e) => setTest(e.target.value)} placeholder="Enter passphrase" />
            </div>
            <Button type="submit" disabled={checking || !test}>{checking ? "Checking…" : "Verify"}</Button>
          </form>
          {status === "valid" && <p className="mt-3 text-sm text-emerald-600 font-medium">✓ Passphrase is valid. Delete controls are authorized.</p>}
          {status === "invalid" && <p className="mt-3 text-sm text-rose-600 font-medium">✗ Incorrect passphrase.</p>}
          {status === "error" && <p className="mt-3 text-sm text-rose-600 font-medium">Verification failed. Try again.</p>}
        </div>

        <div className="rounded-xl border bg-amber-50 border-amber-200 p-4">
          <p className="text-sm text-amber-800">
            This page is intentionally hidden from navigation. Only users with the link and the master passphrase
            (<code className="font-mono bg-amber-100 px-1 rounded">ANIJEN2026</code>) can authorize deletions.
          </p>
        </div>
      </div>
    </Layout>
  );
}