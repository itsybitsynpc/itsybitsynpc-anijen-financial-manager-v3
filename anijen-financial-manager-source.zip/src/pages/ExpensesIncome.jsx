import { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Plus, Trash2, TrendingDown, TrendingUp } from "lucide-react";
import Layout from "@/components/Layout";
import { usePassphraseGuard } from "@/hooks/useGuard";
import { formatGHS, formatDate } from "@/lib/format";
import ExpenseFormDialog from "@/components/expenses/ExpenseFormDialog";
import IncomeFormDialog from "@/components/expenses/IncomeFormDialog";
import { withScrollRetention } from "@/lib/scroll";

export default function ExpensesIncome() {
  const [tab, setTab] = useState("expenses");
  const [expenses, setExpenses] = useState([]);
  const [incomes, setIncomes] = useState([]);
  const [expOpen, setExpOpen] = useState(false);
  const [incOpen, setIncOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const { requirePassphrase, modal } = usePassphraseGuard();

  const load = withScrollRetention(async () => {
    setLoading(true);
    try {
      const [ex, il] = await Promise.all([
        base44.entities.Expense.list("-created_date", 500),
        base44.entities.IncomeLog.list("-created_date", 500),
      ]);
      setExpenses(ex);
      setIncomes(il);
    } finally {
      setLoading(false);
    }
  });

  useEffect(() => { load(); }, []);

  const manualIncomes = incomes.filter((i) => i.source === "manual");
  const totalExpenses = expenses.reduce((s, e) => s + Number(e.amount || 0), 0);
  const totalManualIncome = manualIncomes.reduce((s, i) => s + Number(i.amount || 0), 0);

  const deleteExpense = (e) => {
    requirePassphrase(`delete expense "${e.item}"`, async () => {
      await base44.entities.Expense.delete(e.id);
      load();
    });
  };

  const deleteIncome = (i) => {
    requirePassphrase(`delete income "${i.reference_name}"`, async () => {
      await base44.entities.IncomeLog.delete(i.id);
      load();
    });
  };

  return (
    <Layout>
      <div className="flex flex-col gap-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div>
            <h1 className="font-heading text-2xl font-semibold">Expenses & Income</h1>
            <p className="text-sm text-muted-foreground">Standalone business expenses and additional income (GHS)</p>
          </div>
          <Button onClick={() => (tab === "expenses" ? setExpOpen(true) : setIncOpen(true))}>
            <Plus className="h-4 w-4 mr-1" /> {tab === "expenses" ? "Add Expense" : "Add Income"}
          </Button>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <SummaryCard label="Total Expenses" value={formatGHS(totalExpenses)} icon={TrendingDown} tone="rose" />
          <SummaryCard label="Additional Income" value={formatGHS(totalManualIncome)} icon={TrendingUp} tone="emerald" />
        </div>

        <div className="flex gap-1 rounded-lg bg-muted/50 p-1 w-fit">
          {[
            { key: "expenses", label: "Expenses" },
            { key: "income", label: "Income" },
          ].map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={`rounded-md px-4 py-1.5 text-sm font-medium transition-colors ${
                tab === t.key ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        <div className="rounded-xl border bg-card shadow-sm overflow-hidden">
          <div className="divide-y max-h-[60vh] overflow-auto">
            {loading && <div className="px-4 py-10 text-center text-sm text-muted-foreground">Loading…</div>}
            {!loading && tab === "expenses" && expenses.length === 0 && <Empty text="No expenses logged yet." />}
            {!loading && tab === "income" && manualIncomes.length === 0 && <Empty text="No additional income logged yet." />}
            {!loading && tab === "expenses" && expenses.map((e) => (
              <div key={e.id} className="flex items-center justify-between px-4 py-3 text-sm">
                <div>
                  <p className="font-medium">{e.item}</p>
                  <p className="text-xs text-muted-foreground">{e.category}{e.payment_method ? ` · ${e.payment_method}` : ""}{e.notes ? ` · ${e.notes}` : ""}</p>
                  <p className="text-[11px] text-muted-foreground">{formatDate(e.date || e.created_date)}</p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="font-medium text-rose-600">{formatGHS(e.amount || 0)}</span>
                  <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={() => deleteExpense(e)}><Trash2 className="h-3.5 w-3.5" /></Button>
                </div>
              </div>
            ))}
            {!loading && tab === "income" && manualIncomes.map((i) => (
              <div key={i.id} className="flex items-center justify-between px-4 py-3 text-sm">
                <div>
                  <p className="font-medium">{i.reference_name || "—"}</p>
                  <p className="text-xs text-muted-foreground">{i.payment_method ? i.payment_method : ""}{i.description ? ` · ${i.description}` : ""}</p>
                  <p className="text-[11px] text-muted-foreground">{formatDate(i.date || i.created_date)}</p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="font-medium text-emerald-600">{formatGHS(i.amount || 0)}</span>
                  <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={() => deleteIncome(i)}><Trash2 className="h-3.5 w-3.5" /></Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
      <ExpenseFormDialog open={expOpen} onClose={() => setExpOpen(false)} onRefresh={load} />
      <IncomeFormDialog open={incOpen} onClose={() => setIncOpen(false)} onRefresh={load} />
      {modal}
    </Layout>
  );
}

function SummaryCard({ label, value, icon: Icon, tone }) {
  const toneMap = { rose: "bg-rose-100 text-rose-600", emerald: "bg-emerald-100 text-emerald-600" };
  return (
    <div className="rounded-xl border bg-card shadow-sm p-4">
      <div className="flex items-center justify-between">
        <p className="text-xs font-medium text-muted-foreground">{label}</p>
        <span className={`flex h-8 w-8 items-center justify-center rounded-lg ${toneMap[tone] || "bg-muted text-muted-foreground"}`}>
          <Icon className="h-4 w-4" />
        </span>
      </div>
      <p className="mt-2 font-heading text-2xl font-semibold">{value}</p>
    </div>
  );
}

function Empty({ text }) {
  return <div className="px-4 py-10 text-center text-sm text-muted-foreground">{text}</div>;
}