import { useState, useCallback } from "react";
import PassphraseModal from "@/components/PassphraseModal";

const SESSION_KEY = "anijen_admin_unlock_at";
const SESSION_TTL = 10000; // 10 seconds

function isRecentlyUnlocked() {
  const t = Number(sessionStorage.getItem(SESSION_KEY) || 0);
  return t > 0 && Date.now() - t < SESSION_TTL;
}

function markUnlocked() {
  sessionStorage.setItem(SESSION_KEY, String(Date.now()));
}

export function usePassphraseGuard() {
  const [open, setOpen] = useState(false);
  const [context, setContext] = useState("");
  const [pending, setPending] = useState(null);

  const requirePassphrase = useCallback((ctx, action) => {
    // Within 10s of a previous successful unlock, skip the prompt and run
    // the privileged action immediately, refreshing the window each time.
    if (isRecentlyUnlocked()) {
      markUnlocked();
      action();
      return;
    }
    setContext(ctx);
    setPending(() => action);
    setOpen(true);
  }, []);

  const handleSuccess = useCallback(() => {
    markUnlocked();
    if (pending) pending();
  }, [pending]);

  const handleClose = useCallback(() => {
    setOpen(false);
    setPending(null);
  }, []);

  const modal = (
    <PassphraseModal
      open={open}
      onClose={handleClose}
      onSuccess={handleSuccess}
      context={context}
    />
  );

  return { requirePassphrase, modal };
}