import { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";

/**
 * The workspaces the signed-in user belongs to, and which one is active.
 * Active company always comes from the user record (server-assigned), never
 * from local UI state.
 */
export default function useActiveCompany() {
  const { user } = useAuth();
  const [memberships, setMemberships] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user?.id) {
      setMemberships([]);
      setLoading(false);
      return;
    }
    let cancelled = false;
    setLoading(true);
    base44.entities.CompanyMembership
      .filter({ user_id: user.id }, { sort: "company_name", limit: 50 })
      .then((page) => {
        if (!cancelled) setMemberships(page.items || []);
      })
      .catch(() => {
        if (!cancelled) setMemberships([]);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [user?.id]);

  const activeId = user?.active_company_id || "";
  const active = memberships.find((m) => m.company_id === activeId) || null;

  return { memberships, activeId, active, activeName: active?.company_name || "", loading };
}