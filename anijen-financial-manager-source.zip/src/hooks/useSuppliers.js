import { useState, useEffect, useCallback } from "react";
import { base44 } from "@/api/base44Client";

// Loads all suppliers + their transactions and exposes reload() so any
// mutation recalculates debt totals everywhere.
export function useSuppliers() {
  const [suppliers, setSuppliers] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);

  const reload = useCallback(async () => {
    setLoading(true);
    try {
      const s = await base44.entities.Supplier.list("name", 200);
      const t = await base44.entities.SupplierTransaction.list("-date", 2000);
      setSuppliers(s);
      setTransactions(t);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    reload();
  }, [reload]);

  return { suppliers, transactions, loading, reload };
}