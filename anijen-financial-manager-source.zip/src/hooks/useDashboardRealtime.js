import { useEffect, useRef, useState } from "react";
import { base44 } from "@/api/base44Client";

// Global real-time engine for the Dashboard. Subscribes to Base44 entity
// mutations (create/update/delete) on EVERY core ledger, inventory, capital
// and supplier table, and debounces a single full-dashboard refetch
// (onRefresh) so every KPI card, chart, customer/salesperson table, vehicle
// expense tracker, capital figure and inventory alert recomputes instantly —
// no manual reload required.
//
// This is the Base44 equivalent of a Supabase Realtime multi-table
// postgres_changes channel: one consolidated subscription fan-in instead of
// per-table channels. Profit/margin stay READ-ONLY derived metrics — never
// written to any ledger; recomputed from freshly fetched records each tick.
const CHANNEL_ENTITIES = [
  "CustomerTransaction", // sales & customer profit / revenue
  "SalesPersonTransaction", // agent issues & realized profit
  "IncomeLog", // income feed & net income
  "FactoryPayment", // factory costs & total capital
  "Expense", // operating / Bank / GRA charges
  "VehicleExpense", // fleet expense tracker
  "Product", // inventory value, est. gross revenue, low-stock alerts
  "CapitalAccount", // other capital balances
  "CapitalTransaction", // capital inflows/outflows/transfers
  "Supplier", // supplier debt
  "SupplierTransaction", // debt / repayments -> total capital
  "NetIncomeCorrection", // corrected net profit
  "Customer", // customer master balances
  "SalesPerson", // salesperson master balances
];

export function useDashboardRealtime({ onRefresh } = {}) {
  const [isLive, setIsLive] = useState(false);
  const [lastUpdated, setLastUpdated] = useState(() => new Date());

  // Keep the latest refresh callback in a ref so the subscription effect can
  // mount once (no re-subscribe per render) even though the dashboard's
  // `load` wrapper changes identity each render.
  const refreshRef = useRef(onRefresh);
  refreshRef.current = onRefresh;

  useEffect(() => {
    let timer;
    const trigger = () => {
      clearTimeout(timer);
      timer = setTimeout(() => {
        setLastUpdated(new Date());
        if (refreshRef.current) refreshRef.current();
      }, 400);
    };

    // One subscription per core entity. Any INSERT/UPDATE/DELETE on any of
    // them collapses into a single debounced dashboard-wide refetch.
    const unsubs = CHANNEL_ENTITIES.map(
      (name) => base44.entities[name]?.subscribe?.(trigger)
    );
    setIsLive(true);
    return () => {
      clearTimeout(timer);
      unsubs.forEach((u) => u && u());
      setIsLive(false);
    };
  }, []);

  return { isLive, lastUpdated };
}