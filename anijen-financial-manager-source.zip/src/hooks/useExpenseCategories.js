import { useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";

export const DEFAULT_EXPENSE_CATEGORIES = [
  "Fuel",
  "Transport",
  "Worker Wages/Salaries",
  "Utilities",
  "Supplies",
  "Packaging/Supplies",
  "Rent",
  "Maintenance",
  "Bank Charges",
  "GRA Charges",
  "Miscellaneous",
];

export function useExpenseCategories() {
  return useQuery({
    queryKey: ["expense-categories"],
    queryFn: async () => {
      const items = await base44.entities.ExpenseCategory.list("name", 200);
      const custom = items.map((c) => c.name).filter(Boolean);
      const merged = [...new Set([...DEFAULT_EXPENSE_CATEGORIES, ...custom])];
      return merged;
    },
  });
}

export function useInvalidateExpenseCategories() {
  const qc = useQueryClient();
  return () => qc.invalidateQueries({ queryKey: ["expense-categories"] });
}