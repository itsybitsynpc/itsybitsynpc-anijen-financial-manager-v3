import { useMemo } from "react";
import {
  getWtdRange,
  getWeeklyRealizedProfit,
  getWeeklyTotalExpenses,
  getNetDynamicCashMargin,
  getWeeklyProductVolume,
  getWeeklySalespersonPerformance,
  getWeeklySalespersonRealizedProfit,
  getWeeklyCustomerPerformance,
} from "@/lib/weeklyAnalytics";

// Pure Week-to-Date metrics computation. Derives every WTD figure from the
// dashboard records passed in as props — profit/margin remain READ-ONLY
// derived metrics, never written to any ledger.
//
// Real-time reactivity is driven by the global subscription in
// `useDashboardRealtime` (Dashboard level), which refetches all dashboard
// data on any core-table mutation; the refreshed arrays flow back in here
// and the metrics recompute instantly. This hook therefore stays a pure
// function of its inputs — no subscription of its own.
export function useRealTimeWeeklyProfit({
  customerTransactions = [],
  salesPersonTransactions = [],
  expenses = [],
  vehicleExpenses = [],
} = {}) {
  return useMemo(() => {
    const range = getWtdRange();
    // Global live WTD profit = customer sales profit + salesperson issue
    // profit. Both are strictly realized margins from completed sales/issues
    // — never stock estimates. The two channels are independent ledger
    // entries, so summing them does not double-count.
    const customerProfit = getWeeklyRealizedProfit(customerTransactions, range);
    const salespersonProfit = getWeeklySalespersonRealizedProfit(salesPersonTransactions, range);
    const wtdProfit = customerProfit + salespersonProfit;
    const wtdExpenses = getWeeklyTotalExpenses(expenses, vehicleExpenses, range);
    return {
      range,
      wtdProfit,
      customerProfit,
      salespersonProfit,
      wtdExpenses,
      netWtdMargin: getNetDynamicCashMargin(wtdProfit, wtdExpenses),
      productVolume: getWeeklyProductVolume(customerTransactions, range),
      spPerformance: getWeeklySalespersonPerformance(salesPersonTransactions, range),
      customerPerformance: getWeeklyCustomerPerformance(customerTransactions, range),
    };
  }, [customerTransactions, salesPersonTransactions, expenses, vehicleExpenses]);
}