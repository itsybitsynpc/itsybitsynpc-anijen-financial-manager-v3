import { useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { getActiveCompanyId } from "@/lib/tenant";

export function useProducts() {
  return useQuery({
    // Scoped by workspace so stock from one company never feeds another's totals.
    queryKey: ["products", getActiveCompanyId()],
    queryFn: async () => {
      const items = await base44.entities.Product.list("-sort_order", 200);
      return items.sort((a, b) => (a.sort_order || 0) - (b.sort_order || 0));
    },
  });
}

export function useInvalidateProducts() {
  const qc = useQueryClient();
  return () => qc.invalidateQueries({ queryKey: ["products"] });
}