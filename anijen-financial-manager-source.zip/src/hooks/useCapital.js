import { useState, useEffect, useCallback } from "react";
import { base44 } from "@/api/base44Client";

// Loads all capital accounts + transactions and exposes reload() so any
// mutation (create/edit/delete) recalculates balances everywhere.
export function useCapital() {
  const [accounts, setAccounts] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);

  const reload = useCallback(async () => {
    setLoading(true);
    try {
      const accs = await base44.entities.CapitalAccount.list("sort_order", 200);
      const txns = await base44.entities.CapitalTransaction.list("-date", 2000);
      setAccounts(accs);
      setTransactions(txns);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    reload();
  }, [reload]);

  return { accounts, transactions, loading, reload };
}