import { useState } from "react";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { sanitizeAmountInput } from "@/lib/money";
import { Label } from "@/components/ui/label";
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
} from "@/components/ui/select";
import { base44 } from "@/api/base44Client";
import { PAYMENT_METHODS } from "@/lib/format";
import { useExpenseCategories, useInvalidateExpenseCategories } from "@/hooks/useExpenseCategories";

export default function ExpenseFormDialog({ open, onClose, onRefresh }) {
  const { data: categories = [] } = useExpenseCategories();
  const invalidateCats = useInvalidateExpenseCategories();
  const [item, setItem] = useState("");
  const [amount, setAmount] = useState("");
  const [category, setCategory] = useState("");
  const [method, setMethod] = useState("");
  const [notes, setNotes] = useState("");
  const [newCat, setNewCat] = useState("");
  const [addingCat, setAddingCat] = useState(false);
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState("");

  const reset = () => {
    setItem(""); setAmount(""); setCategory(""); setMethod(""); setNotes("");
    setNewCat(""); setAddingCat(false); setErr("");
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true); setErr("");
    let finalCategory = category;
    try {
      if (addingCat && newCat.trim()) {
        const created = await base44.entities.ExpenseCategory.create({ name: newCat.trim() });
        finalCategory = created.name;
        await invalidateCats();
      }
      if (!finalCategory) {
        setErr("Please select or add a category");
        setSaving(false);
        return;
      }
      await base44.entities.Expense.create({
        item: item.trim(),
        amount: Number(amount) || 0,
        category: finalCategory,
        payment_method: method,
        notes: notes,
        date: new Date().toISOString(),
      });
      reset();
      onRefresh?.();
      onClose?.();
    } catch (error) {
      setErr(error?.message || "Failed to log expense");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && (reset(), onClose?.())}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Log Business Expense</DialogTitle>
          <DialogDescription>Record a standalone business expense.</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label>Expense Item / Description</Label>
            <Input value={item} onChange={(e) => setItem(e.target.value)} required autoFocus />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>Amount (GHS)</Label>
              <Input type="number" min="0" step="0.01" value={amount} onChange={(e) => setAmount(sanitizeAmountInput(e.target.value))} required />
            </div>
            <div className="space-y-2">
              <Label>Payment Method</Label>
              <Select value={method} onValueChange={setMethod}>
                <SelectTrigger><SelectValue placeholder="Select method" /></SelectTrigger>
                <SelectContent>
                  {PAYMENT_METHODS.map((m) => <SelectItem key={m} value={m}>{m}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-2">
            <Label>Category</Label>
            {!addingCat ? (
              <div className="flex gap-2">
                <Select value={category} onValueChange={setCategory}>
                  <SelectTrigger className="flex-1"><SelectValue placeholder="Select category" /></SelectTrigger>
                  <SelectContent>
                    {categories.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                  </SelectContent>
                </Select>
                <Button type="button" variant="outline" size="sm" onClick={() => setAddingCat(true)}>+ Add New</Button>
              </div>
            ) : (
              <div className="flex gap-2">
                <Input value={newCat} onChange={(e) => setNewCat(e.target.value)} placeholder="New category name" autoFocus />
                <Button type="button" variant="ghost" size="sm" onClick={() => setAddingCat(false)}>Cancel</Button>
              </div>
            )}
          </div>
          <div className="space-y-2">
            <Label>Notes (optional)</Label>
            <Input value={notes} onChange={(e) => setNotes(e.target.value)} />
          </div>
          {err && <p className="text-sm text-destructive">{err}</p>}
          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
            <Button type="submit" disabled={saving}>{saving ? "Saving…" : "Log Expense"}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}