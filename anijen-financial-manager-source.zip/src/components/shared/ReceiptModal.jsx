import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Printer, X, Loader2, Cloud } from "lucide-react";
import { formatGHS, formatDate } from "@/lib/format";
import { transactionLines, paidAtPurchase, invoicePaymentStatus, INVOICE_STATUS_LABELS } from "@/lib/finance";
import { base44 } from "@/api/base44Client";
import { toast } from "@/components/ui/use-toast";
import { buildReceiptPdf } from "@/lib/receiptPdf";

export default function ReceiptModal({ open, onClose, party, partyType, transaction, previousBalance, remainingBalance, balances }) {
  const [printTime, setPrintTime] = useState(() => new Date());
  const [uploading, setUploading] = useState(false);
  const [drive, setDrive] = useState(null);

  if (!open || !transaction) return null;

  // Opening, viewing and printing are read-only: nothing is written or uploaded
  // until the user explicitly asks for the PDF to be saved to Drive.
  const handleSaveToDrive = async () => {
    const refId = transaction.reference_number || (transaction.id || "").slice(-8).toUpperCase();
    setUploading(true);
    try {
      const doc = buildReceiptPdf({ party, partyType, transaction, previousBalance, remainingBalance, balances, printTime: new Date() });
      const pdfBase64 = doc.output("datauristring").split(",")[1];
      const res = await base44.functions.invoke("uploadReceiptToDrive", { customerName: party?.name, reference: refId, pdfBase64 });
      setDrive(res.data);
      if (res.data?.status === "uploaded") {
        toast({ title: "Invoice saved to Google Drive", description: `${party?.name || "Invoice"} · ${refId}` });
      } else {
        toast({ title: "Drive upload failed", description: res.data?.error || "Google Drive did not accept the file.", variant: "destructive" });
      }
    } catch (e) {
      toast({ title: "Drive upload failed", description: String(e?.message || e), variant: "destructive" });
    } finally {
      setUploading(false);
    }
  };

  const handlePrint = () => {
    setPrintTime(new Date());
    requestAnimationFrame(() => window.print());
  };

  const isSale = transaction.type === "sale" || transaction.type === "issue";
  const isCustomer = partyType === "customer";
  const lines = transactionLines(transaction);
  const amount = Number(transaction.amount || 0);
  const sellingTotal = lines.reduce((s, l) => s + Number(l.quantity_cartons || 0) * Number(l.selling_price_per_unit || 0), 0);
  // Upfront payment taken at the point of sale (zero when none was taken).
  const upfrontPaid = isSale ? paidAtPurchase(transaction) : 0;
  const balanceDue = Math.max(0, amount - upfrontPaid);
  const statusLabel = INVOICE_STATUS_LABELS[invoicePaymentStatus(transaction)];
  const ref = transaction.reference_number || (transaction.id || "").slice(-8).toUpperCase();
  const typeLabel =
    transaction.type === "sale" ? "Product Sale"
      : transaction.type === "issue" ? "Product Issue"
      : transaction.type === "payment" ? "Debt Settlement"
      : "Cash Settlement";
  const partyLabel = isCustomer ? "Customer" : "Sales Representative";

  // Dual-ledger snapshot (falls back to legacy single-balance values).
  const prevBefore = balances?.previousBefore ?? Number(previousBalance || 0);
  const outBefore = balances?.outstandingBefore ?? 0;
  const prevAfter = balances?.previousAfter ?? prevBefore;
  const outAfter = balances?.outstandingAfter ??
    (isSale ? Math.max(0, outBefore + amount - upfrontPaid) : Math.max(0, outBefore - amount));
  const totalBefore = prevBefore + outBefore;
  const totalAfter = prevAfter + outAfter;

  let appliedPrev = 0, appliedOut = 0;
  if (!isSale) {
    if (transaction.payment_target === "PREVIOUS_BALANCE") {
      appliedPrev = Math.min(amount, prevBefore);
      appliedOut = Math.max(0, amount - prevBefore);
    } else {
      appliedOut = amount;
    }
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-[148mm] max-h-[92vh] overflow-y-auto my-auto">
        <div className="no-print flex justify-end p-2">
          <Button variant="ghost" size="icon" onClick={onClose} className="h-8 w-8">
            <X className="h-4 w-4" />
          </Button>
        </div>

        <div id="receipt-printable" className="receipt-modal bg-white text-black px-8 pb-8">
          <div className="text-center pb-1 mb-2">
            <h1 className="text-2xl font-bold tracking-widest uppercase">Official Invoice</h1>
          </div>

          <div className="flex justify-between text-xs mb-2">
            <span>Ref: <b>{ref || "N/A"}</b></span>
            <span>Date: <b>{formatDate(transaction.date || transaction.created_date)}</b></span>
          </div>
          <div className="text-right text-[10px] text-gray-500 mb-3">Printed: {formatDate(printTime)}</div>

          <div className="grid grid-cols-2 gap-2 text-sm mb-3 border-y py-2">
            <div>
              <p className="text-xs text-gray-500">{partyLabel}</p>
              <p className="font-semibold">{party?.name || "—"}</p>
            </div>
            <div>
              <p className="text-xs text-gray-500">Transaction Type</p>
              <p className="font-semibold">
                {typeLabel}
                {isSale && (
                  <span className={`ml-2 rounded px-1.5 py-0.5 text-[10px] font-semibold uppercase ${invoicePaymentStatus(transaction) === "paid" ? "bg-emerald-100 text-emerald-800" : invoicePaymentStatus(transaction) === "partial" ? "bg-amber-100 text-amber-900" : "bg-rose-100 text-rose-800"}`}>
                    {statusLabel}
                  </span>
                )}
              </p>
            </div>
          </div>

          {isSale && lines.length > 0 && (
            <table className="w-full text-sm border-collapse mb-4">
              <thead>
                <tr className="border-b-2 border-black text-xs">
                  <th className="text-left py-1.5">Product</th>
                  <th className="text-right py-1.5">Qty (Cartons)</th>
                  <th className="text-right py-1.5">Unit Price (GHS)</th>
                  <th className="text-right py-1.5">Subtotal (GHS)</th>
                </tr>
              </thead>
              <tbody>
                {lines.map((l, i) => {
                  const unit = Number(l.selling_price_per_unit || 0);
                  const q = Number(l.quantity_cartons || 0);
                  return (
                    <tr key={i} className="border-b">
                      <td className="py-1.5">{l.product_name || "—"}</td>
                      <td className="text-right py-1.5">{q.toLocaleString()}</td>
                      <td className="text-right py-1.5">{unit.toLocaleString(undefined, { minimumFractionDigits: 2 })}</td>
                      <td className="text-right py-1.5 font-medium">{formatGHS(q * unit).replace("GHS ", "")}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}

          <div className="space-y-1.5 text-sm mb-4">
            <div className="flex justify-between rounded bg-rose-50 px-2 py-1 text-rose-800">
              <span>Previous Balance (Arrears)</span>
              <span className="font-medium">{formatGHS(prevBefore)}</span>
            </div>
            <div className="flex justify-between rounded bg-amber-50 px-2 py-1 text-amber-900">
              <span>Outstanding Balance (Goods)</span>
              <span className="font-medium">{formatGHS(outBefore)}</span>
            </div>
            <div className="flex justify-between border-b pb-1">
              <span className="font-medium text-gray-700">Total Debt Before</span>
              <span className="font-medium">{formatGHS(totalBefore)}</span>
            </div>
            {isSale ? (
              <>
                <div className="flex justify-between">
                  <span className="text-gray-600">Subtotal</span>
                  <span className="font-medium">{formatGHS(sellingTotal)}</span>
                </div>
                <div className="flex justify-between border-t pt-1">
                  <span className="font-medium text-gray-700">Total Amount</span>
                  <span className="font-semibold">{formatGHS(amount)}</span>
                </div>
                {upfrontPaid > 0 && (
                  <div className="flex justify-between">
                    <span className="text-gray-600">Amount Paid at Purchase</span>
                    <span className="font-medium text-emerald-700">-{formatGHS(upfrontPaid)}</span>
                  </div>
                )}
                <div className="flex justify-between border-t pt-1">
                  <span className="font-medium text-gray-700">Balance Due</span>
                  <span className={`font-semibold ${balanceDue > 0 ? "text-rose-700" : "text-emerald-700"}`}>{formatGHS(balanceDue)}</span>
                </div>
              </>
            ) : (
              <div className="flex justify-between">
                <span className="text-gray-600">Amount Paid</span>
                <span className="font-medium">{formatGHS(amount)}</span>
              </div>
            )}
            {!isSale && transaction.payment_target && (
              <div className="flex justify-between">
                <span className="text-gray-600">Payment Target</span>
                <span className="font-medium">{transaction.payment_target === "PREVIOUS_BALANCE" ? "Previous Balance / Arrears" : "Current Goods / Invoice"}</span>
              </div>
            )}
            {!isSale && appliedPrev > 0 && (
              <div className="flex justify-between">
                <span className="text-gray-600">Applied to Previous</span>
                <span className="font-medium">{formatGHS(appliedPrev)}</span>
              </div>
            )}
            {!isSale && appliedOut > 0 && (
              <div className="flex justify-between">
                <span className="text-gray-600">Applied to Outstanding</span>
                <span className="font-medium">{formatGHS(appliedOut)}</span>
              </div>
            )}
            {(isSale ? transaction.initial_payment_method : transaction.payment_method) && (
              <div className="flex justify-between">
                <span className="text-gray-600">Payment Method</span>
                <span className="font-medium">{isSale ? transaction.initial_payment_method : transaction.payment_method}</span>
              </div>
            )}
            <div className="flex justify-between rounded bg-rose-50 px-2 py-1 text-rose-800 border-t pt-1.5">
              <span>Remaining Previous Balance</span>
              <span className="font-medium">{formatGHS(prevAfter)}</span>
            </div>
            <div className="flex justify-between rounded bg-amber-50 px-2 py-1 text-amber-900">
              <span>Remaining Outstanding Balance</span>
              <span className="font-medium">{formatGHS(outAfter)}</span>
            </div>
            <div className="flex justify-between rounded bg-amber-100 px-2 py-1.5 text-base font-bold text-amber-900 border-t-2 border-black">
              <span>Total Remaining Debt</span>
              <span>{formatGHS(totalAfter)}</span>
            </div>
          </div>

          <div className="border-t pt-3 text-center text-xs">
            <p className="italic mb-3">Thank you for your business.</p>
            <div className="flex justify-between items-end">
              <div className="text-left">
                <div className="border-t border-black w-40 pt-1 mt-6">Authorized Signature</div>
              </div>
              <div className="text-right text-[10px] text-gray-500">
                <p>Generated: {formatDate(printTime)}</p>
              </div>
            </div>
          </div>
        </div>

        <div className="no-print flex items-center justify-between gap-2 p-4 border-t bg-muted/30">
          {uploading ? (
            <span className="inline-flex items-center gap-1.5 text-xs text-muted-foreground">
              <Loader2 className="h-3.5 w-3.5 animate-spin" /> Saving to Drive…
            </span>
          ) : drive?.webViewLink ? (
            <a href={drive.webViewLink} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1.5 text-xs text-emerald-600 hover:underline">
              <Cloud className="h-3.5 w-3.5" /> Saved to Drive · Open
            </a>
          ) : (
            <button
              type="button"
              onClick={handleSaveToDrive}
              className="inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground hover:underline"
            >
              <Cloud className="h-3.5 w-3.5" /> Save PDF to Drive
            </button>
          )}
          <div className="flex gap-2">
            <Button variant="outline" onClick={onClose}>Close</Button>
            <Button onClick={handlePrint}>
              <Printer className="h-4 w-4 mr-1" /> Print Receipt
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}