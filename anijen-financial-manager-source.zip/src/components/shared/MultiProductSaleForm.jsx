import { useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
} from "@/components/ui/select";
import { formatGHS, PAYMENT_METHODS } from "@/lib/format";
import { sanitizeAmountInput } from "@/lib/money";
import { availableStock } from "@/lib/finance";

export default function MultiProductSaleForm({
  products,
  onSubmit,
  onCancel,
  saving,
  submitLabel = "Record Sale",
  allowUpfront = false,
  upfrontBasis = "sell",
}) {
  const [rows, setRows] = useState({});
  const [upfrontAmount, setUpfrontAmount] = useState("");
  const [upfrontMethod, setUpfrontMethod] = useState("");
  const [formErr, setFormErr] = useState("");
  const setVal = (id, field, val) =>
    setRows((r) => ({ ...r, [id]: { ...(r[id] || {}), [field]: val } }));

  const lines = useMemo(
    () =>
      products
        .map((p) => {
          const r = rows[p.id] || {};
          const qty = Number(r.qty) || 0;
          const cost =
            r.cost != null && r.cost !== "" ? Number(r.cost) : Number(p.default_cost_price || 0);
          const sell =
            r.sell != null && r.sell !== "" ? Number(r.sell) : Number(p.default_selling_price || 0);
          return { product: p, qty, cost, sell };
        })
        .filter((l) => l.qty > 0),
    [rows, products]
  );

  const totalCost = lines.reduce((s, l) => s + l.qty * l.cost, 0);
  const totalSell = lines.reduce((s, l) => s + l.qty * l.sell, 0);
  const totalProfit = totalSell - totalCost;

  // Upfront payment is capped at the amount owed, never above it. Sales are
  // measured on the selling total, salesperson issues on the cost-based debt.
  const payableTotal = upfrontBasis === "cost" ? totalCost : totalSell;
  const rawPaid = allowUpfront ? Math.max(0, Number(upfrontAmount) || 0) : 0;
  const overPaid = allowUpfront && rawPaid > payableTotal;
  const paid = Math.min(rawPaid, payableTotal);
  const balanceDue = Math.max(0, payableTotal - paid);
  const statusLabel =
    paid <= 0 || payableTotal <= 0
      ? "Pending"
      : paid >= payableTotal ? "Paid in full" : "Partially paid";
  const upfrontInvalid = overPaid || (paid > 0 && !upfrontMethod);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!lines.length) return;
    if (overPaid) { setFormErr("Amount paid cannot exceed the total amount."); return; }
    if (paid > 0 && !upfrontMethod) { setFormErr("Select how the upfront payment was made."); return; }
    setFormErr("");
    onSubmit(
      lines.map((l) => ({
        product_id: l.product.id,
        product_name: l.product.name,
        quantity_cartons: l.qty,
        cost_price_per_unit: l.cost,
        selling_price_per_unit: l.sell,
      })),
      allowUpfront ? { amount: paid, method: paid > 0 ? upfrontMethod : "" } : undefined
    );
  };

  return (
    <form onSubmit={handleSubmit} className="rounded-lg border p-3 bg-muted/30 space-y-3">
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-xs text-muted-foreground border-b">
              <th className="text-left py-1.5 font-medium">Product</th>
              <th className="text-right font-medium">Stock</th>
              <th className="text-right font-medium">Qty (Cartons)</th>
              <th className="text-right font-medium">Cost / Unit</th>
              <th className="text-right font-medium">Sell / Unit</th>
              <th className="text-right font-medium">Profit</th>
            </tr>
          </thead>
          <tbody>
            {products.map((p) => {
              const r = rows[p.id] || {};
              const qty = Number(r.qty) || 0;
              const cost =
                r.cost != null && r.cost !== "" ? Number(r.cost) : Number(p.default_cost_price || 0);
              const sell =
                r.sell != null && r.sell !== "" ? Number(r.sell) : Number(p.default_selling_price || 0);
              const profit = qty * (sell - cost);
              const stock = availableStock(p);
              const projected = stock - qty;
              const stockTone = projected < 0
                ? "text-rose-600 font-semibold bg-rose-50"
                : qty > 0
                  ? "text-amber-600 font-semibold"
                  : "text-muted-foreground";
              return (
                <tr key={p.id} className="border-b last:border-0">
                  <td className="py-1.5 font-medium">
                    {p.name}
                  </td>
                  <td className={`text-right rounded ${stockTone}`}>
                    {projected.toLocaleString()}
                  </td>
                  <td className="text-right">
                    <Input
                      type="number"
                      min="0"
                      step="0.01"
                      value={r.qty || ""}
                      onChange={(e) => setVal(p.id, "qty", sanitizeAmountInput(e.target.value))}
                      disabled={stock <= 0}
                      className="h-8 w-20 ml-auto text-right"
                      placeholder={stock <= 0 ? "Out of Stock" : "0"}
                    />
                  </td>
                  <td className="text-right">
                    <Input
                      type="number"
                      min="0"
                      step="0.01"
                      value={r.cost ?? ""}
                      onChange={(e) => setVal(p.id, "cost", sanitizeAmountInput(e.target.value))}
                      className="h-8 w-24 ml-auto text-right"
                      placeholder={String(p.default_cost_price || 0)}
                    />
                  </td>
                  <td className="text-right">
                    <Input
                      type="number"
                      min="0"
                      step="0.01"
                      value={r.sell ?? ""}
                      onChange={(e) => setVal(p.id, "sell", sanitizeAmountInput(e.target.value))}
                      className="h-8 w-24 ml-auto text-right"
                      placeholder={String(p.default_selling_price || 0)}
                    />
                  </td>
                  <td className={`text-right font-medium ${profit > 0 ? "text-emerald-600" : profit < 0 ? "text-rose-600" : "text-muted-foreground"}`}>
                    {qty ? formatGHS(profit).replace("GHS ", "") : "—"}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      <div className="flex flex-wrap justify-end gap-4 text-sm">
        <span>Total Cost: <b className="text-foreground">{formatGHS(totalCost)}</b></span>
        <span>Total Sell: <b className="text-foreground">{formatGHS(totalSell)}</b></span>
        <span className="text-emerald-600">Profit: <b>{formatGHS(totalProfit)}</b></span>
      </div>

      {allowUpfront && (
        <div className="rounded-lg border bg-background p-3 space-y-2">
          <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
            Upfront Payment Details <span className="font-normal normal-case">(optional)</span>
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label htmlFor="upfront-amount">Amount Paid at Time of Purchase (GHS)</Label>
              <Input
                id="upfront-amount"
                type="number"
                min="0"
                step="0.01"
                value={upfrontAmount}
                onChange={(e) => { setUpfrontAmount(sanitizeAmountInput(e.target.value)); setFormErr(""); }}
                placeholder="0.00"
                className={overPaid ? "border-destructive" : ""}
              />
            </div>
            <div className="space-y-1.5">
              <Label>Payment Method</Label>
              <Select value={upfrontMethod} onValueChange={(v) => { setUpfrontMethod(v); setFormErr(""); }} disabled={paid <= 0}>
                <SelectTrigger><SelectValue placeholder={paid <= 0 ? "Enter an amount first" : "Select method"} /></SelectTrigger>
                <SelectContent>
                  {PAYMENT_METHODS.map((m) => <SelectItem key={m} value={m}>{m}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
            <span className="text-muted-foreground">
              Total: <b className="text-foreground">{formatGHS(payableTotal)}</b> · Balance Due:{" "}
              <b className={balanceDue > 0 ? "text-rose-600" : "text-emerald-600"}>{formatGHS(balanceDue)}</b>
            </span>
            <span className={`font-medium ${paid <= 0 ? "text-muted-foreground" : paid >= payableTotal ? "text-emerald-700" : "text-amber-700"}`}>
              {statusLabel}
            </span>
          </div>
          {(formErr || overPaid || (paid > 0 && !upfrontMethod)) && (
            <p className="text-xs text-destructive">
              {overPaid
                ? "Amount paid cannot exceed the total amount."
                : formErr || "Select how the upfront payment was made."}
            </p>
          )}
        </div>
      )}

      <div className="flex justify-end gap-2">
        <Button type="button" variant="ghost" onClick={onCancel}>Cancel</Button>
        <Button type="submit" disabled={saving || !lines.length || upfrontInvalid}>{saving ? "Saving…" : submitLabel}</Button>
      </div>
    </form>
  );
}