import { formatGHS } from "@/lib/format";

// Shared profit view: Est. Gross Revenue − Inventory Cost Value per product,
// minus all expenses (incl. damage) → net profit. Used in Factory and Dashboard.
export default function ProfitBreakdown({ breakdown }) {
  const {
    grossMargin = 0,
    byProduct = [],
    damageExpenses = 0,
    totalExpenses = 0,
    netProfit = 0,
  } = breakdown || {};

  return (
    <div className="rounded-xl border bg-card shadow-sm overflow-hidden">
      <div className="px-4 py-3 border-b flex items-center justify-between">
        <h2 className="font-heading font-semibold">Profit Analysis</h2>
        <span className="text-xs text-muted-foreground">Est. Revenue − Cost − expenses</span>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 p-4 border-b">
        <Mini label="Gross Margin (Stock)" value={formatGHS(grossMargin)} tone="emerald" />
        <Mini label="Damage Expenses" value={formatGHS(damageExpenses)} tone="rose" />
        <Mini label="Total Expenses" value={formatGHS(totalExpenses)} tone="rose" />
        <Mini label="Net Profit" value={formatGHS(netProfit)} tone={netProfit >= 0 ? "emerald" : "rose"} />
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-muted/40 border-b">
            <tr className="text-xs text-muted-foreground">
              <th className="text-left px-4 py-2.5 font-semibold">Product</th>
              <th className="text-right px-4 py-2.5 font-semibold">Stock (Cartons)</th>
              <th className="text-right px-4 py-2.5 font-semibold">Est. Revenue</th>
              <th className="text-right px-4 py-2.5 font-semibold">Cost Value</th>
              <th className="text-right px-4 py-2.5 font-semibold">Profit</th>
            </tr>
          </thead>
          <tbody>
            {byProduct.map((p) => (
              <tr key={p.product_id || p.product_name} className="border-b last:border-0 hover:bg-muted/30">
                <td className="px-4 py-2.5 font-medium">{p.product_name}</td>
                <td className="px-4 py-2.5 text-right">{Number(p.cartons || 0).toLocaleString()}</td>
                <td className="px-4 py-2.5 text-right">{formatGHS(p.revenue)}</td>
                <td className="px-4 py-2.5 text-right text-muted-foreground">{formatGHS(p.cost)}</td>
                <td className={`px-4 py-2.5 text-right font-medium ${p.profit >= 0 ? "text-emerald-600" : "text-rose-600"}`}>
                  {formatGHS(p.profit)}
                </td>
              </tr>
            ))}
            {byProduct.length === 0 && (
              <tr>
                <td colSpan={5} className="px-4 py-6 text-center text-sm text-muted-foreground">No products stocked yet.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function Mini({ label, value, tone }) {
  const toneClass = tone === "emerald" ? "text-emerald-600" : tone === "rose" ? "text-rose-600" : "text-foreground";
  return (
    <div>
      <p className="text-xs font-medium text-muted-foreground">{label}</p>
      <p className={`mt-1 font-heading text-lg font-semibold ${toneClass}`}>{value}</p>
    </div>
  );
}