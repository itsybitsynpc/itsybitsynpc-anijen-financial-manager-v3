import { useState } from "react";
import { sanitizeAmountInput } from "@/lib/money";
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Plus } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useProducts, useInvalidateProducts } from "@/hooks/useProducts";

export default function ProductPicker({ value, onChange, placeholder = "Select product" }) {
  const { data: products = [] } = useProducts();
  const invalidate = useInvalidateProducts();
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [cost, setCost] = useState("");
  const [sell, setSell] = useState("");
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState("");

  const handleAdd = async (e) => {
    e.preventDefault();
    setSaving(true);
    setErr("");
    try {
      const created = await base44.entities.Product.create({
        name: name.trim(),
        default_cost_price: Number(cost) || 0,
        default_selling_price: Number(sell) || 0,
        factory_stock_cartons: 0,
        damaged_quantity: 0,
        sort_order: (products.length || 0) + 1,
      });
      await invalidate();
      onChange?.(created.id, created);
      setOpen(false);
      setName("");
      setCost("");
      setSell("");
    } catch (error) {
      setErr(error?.message || "Failed to add product");
    } finally {
      setSaving(false);
    }
  };

  const selected = products.find((p) => p.id === value);

  return (
    <div className="flex items-center gap-2">
      <Select value={value || ""} onValueChange={(v) => onChange?.(v, products.find((p) => p.id === v))}>
        <SelectTrigger className="flex-1">
          <SelectValue placeholder={placeholder}>
            {selected ? selected.name : placeholder}
          </SelectValue>
        </SelectTrigger>
        <SelectContent>
          {products.map((p) => (
            <SelectItem key={p.id} value={p.id}>
              {p.name}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
      <Button type="button" variant="outline" size="icon" onClick={() => setOpen(true)} title="Add new product">
        <Plus className="h-4 w-4" />
      </Button>

      <Dialog open={open} onOpenChange={(o) => !o && setOpen(false)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Add New Product</DialogTitle>
            <DialogDescription>
              New products appear instantly in all Customer, Sales Person and Factory dropdowns.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleAdd} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="pname">Product Name</Label>
              <Input id="pname" value={name} onChange={(e) => setName(e.target.value)} autoFocus required />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label htmlFor="pcost">Default Cost / Unit (GHS)</Label>
                <Input id="pcost" type="number" min="0" step="0.01" value={cost} onChange={(e) => setCost(sanitizeAmountInput(e.target.value))} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="psell">Default Sell / Unit (GHS)</Label>
                <Input id="psell" type="number" min="0" step="0.01" value={sell} onChange={(e) => setSell(sanitizeAmountInput(e.target.value))} />
              </div>
            </div>
            {err && <p className="text-sm text-destructive">{err}</p>}
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
              <Button type="submit" disabled={saving || !name.trim()}>{saving ? "Adding…" : "Add Product"}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}