import { NavLink, useNavigate } from "react-router-dom";
import { LayoutDashboard, Users, Briefcase, Factory, Settings, LogOut, Receipt, Truck, LineChart, Landmark, HandCoins, Building2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useState } from "react";
import CompanySwitcher from "@/components/CompanySwitcher";

const navItems = [
  { to: "/", label: "Dashboard", icon: LayoutDashboard, end: true },
  { to: "/customers", label: "Customers", icon: Users },
  { to: "/sales-persons", label: "Sales Persons", icon: Briefcase },
  { to: "/factory", label: "Factory", icon: Factory },
  { to: "/expenses-income", label: "Expenses & Income", icon: Receipt },
  { to: "/trends", label: "Trends", icon: LineChart },
  { to: "/vehicles", label: "Company Vehicles", icon: Truck },
  { to: "/other-capital", label: "Other Capital", icon: Landmark },
  { to: "/our-debt", label: "Our Debt", icon: HandCoins },
];

export default function Layout({ children }) {
  const navigate = useNavigate();
  const [leaving, setLeaving] = useState(false);

  const handleLogout = async () => {
    setLeaving(true);
    await base44.auth.logout();
  };

  return (
    <div className="min-h-screen bg-muted/30 text-foreground">
      <div className="flex">
        <aside className="hidden md:flex md:w-64 md:flex-col md:fixed md:inset-y-0 border-r bg-sidebar">
          <div className="flex h-16 items-center gap-2 border-b px-5">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary text-primary-foreground font-heading text-sm font-bold">
              A1
            </div>
            <div className="leading-tight">
              <p className="font-heading text-sm font-semibold">Financial Manager</p>
              <p className="text-[11px] text-muted-foreground">Multi-company</p>
            </div>
          </div>
          <div className="px-3 pt-3">
            <CompanySwitcher />
          </div>
          <nav className="flex-1 space-y-1 p-3">
            {navItems.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.end}
                className={({ isActive }) =>
                  `flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors ${
                    isActive
                      ? "bg-sidebar-primary text-sidebar-primary-foreground"
                      : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                  }`
                }
              >
                <item.icon className="h-4 w-4" />
                {item.label}
              </NavLink>
            ))}
            <button
              onClick={() => navigate("/workspace-settings")}
              className="flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
            >
              <Building2 className="h-4 w-4" />
              Workspace Settings
            </button>
            <button
              onClick={() => navigate("/admin-settings")}
              className="flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-sidebar-foreground/40 opacity-50 transition-opacity hover:opacity-100"
              title="Admin Settings (hidden)"
            >
              <Settings className="h-4 w-4" />
              Admin Settings
            </button>
          </nav>
          <div className="border-t p-3">
            <button
              onClick={handleLogout}
              disabled={leaving}
              className="flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
            >
              <LogOut className="h-4 w-4" />
              {leaving ? "Signing out…" : "Sign out"}
            </button>
          </div>
        </aside>

        <div className="flex-1 md:pl-64">
          {/* Mobile top bar */}
          <header className="md:hidden sticky top-0 z-30 flex h-14 items-center justify-between border-b bg-background px-4">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-primary-foreground text-xs font-bold">
                A1
              </div>
              <span className="font-heading text-sm font-semibold">ANIJEN ONE</span>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={() => navigate("/workspace-settings")}
                className="text-muted-foreground"
                title="Workspace settings"
              >
                <Building2 className="h-5 w-5" />
              </button>
              <button
                onClick={() => navigate("/admin-settings")}
                className="text-muted-foreground"
              >
                <Settings className="h-5 w-5" />
              </button>
            </div>
          </header>
          <div className="md:hidden border-b bg-background px-3 py-2">
            <CompanySwitcher compact />
          </div>
          <main className="p-4 md:p-8">{children}</main>
        </div>
      </div>

      {/* Mobile bottom nav */}
      <nav className="md:hidden fixed bottom-0 inset-x-0 z-30 border-t bg-background flex">
        {navItems.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.end}
            className={({ isActive }) =>
              `flex flex-1 flex-col items-center gap-1 py-2.5 text-[11px] font-medium ${
                isActive ? "text-primary" : "text-muted-foreground"
              }`
            }
          >
            <item.icon className="h-5 w-5" />
            {item.label}
          </NavLink>
        ))}
      </nav>
    </div>
  );
}