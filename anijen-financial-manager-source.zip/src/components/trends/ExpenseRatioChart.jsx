import {
  ComposedChart, Bar, Line, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, Legend,
} from "recharts";
import { formatGHS } from "@/lib/format";

export default function ExpenseRatioChart({ data }) {
  return (
    <div className="rounded-xl border bg-card shadow-sm">
      <div className="px-4 py-3 border-b">
        <h2 className="font-heading font-semibold">Expense Ratio</h2>
        <p className="text-xs text-muted-foreground">Income & expenses per month, with expense ratio (expenses ÷ revenue)</p>
      </div>
      <div className="h-72 w-full px-2 py-3">
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={data} margin={{ top: 10, right: 16, left: 8, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
            <XAxis dataKey="label" tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" interval="preserveStartEnd" minTickGap={8} />
            <YAxis yAxisId="left" tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" tickFormatter={(v) => (v >= 1000 ? `${(v / 1000).toFixed(1)}k` : String(v))} width={48} />
            <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" tickFormatter={(v) => `${v.toFixed(0)}%`} width={44} />
            <Tooltip
              contentStyle={{ borderRadius: 8, border: "1px solid hsl(var(--border))", fontSize: 12 }}
              formatter={(v, name) => (name === "Expense Ratio" ? [`${Number(v).toFixed(1)}%`, name] : [formatGHS(v), name])}
            />
            <Legend wrapperStyle={{ fontSize: 12 }} />
            <Bar yAxisId="left" dataKey="income" name="Income" fill="#0ea5e9" radius={[4, 4, 0, 0]} />
            <Bar yAxisId="left" dataKey="expenses" name="Expenses" fill="#f43f5e" radius={[4, 4, 0, 0]} />
            <Line yAxisId="right" type="monotone" dataKey="expenseRatio" name="Expense Ratio" stroke="#f59e0b" strokeWidth={2} dot={{ r: 3 }} />
          </ComposedChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}