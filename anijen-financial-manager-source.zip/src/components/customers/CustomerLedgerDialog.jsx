import { useEffect, useMemo, useState } from "react";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { nonNegative, sanitizeAmountInput } from "@/lib/money";
import { Label } from "@/components/ui/label";
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
} from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Trash2, ShoppingBag, Wallet, Receipt, Download } from "lucide-react";
import { downloadCSV } from "@/lib/csv";
import { base44 } from "@/api/base44Client";
import { useProducts, useInvalidateProducts } from "@/hooks/useProducts";
import { adjustStock } from "@/lib/stock";
import { formatGHS, formatDate, PAYMENT_METHODS } from "@/lib/format";
import { transactionProfit, transactionItemsLabel } from "@/lib/finance";
import { usePassphraseGuard } from "@/hooks/useGuard";
import MultiProductSaleForm from "@/components/shared/MultiProductSaleForm";
import ReceiptModal from "@/components/shared/ReceiptModal";
import { nextReferenceNumbers } from "@/lib/reference";
import {
  ensureOutstandingBalance,
  applySaleToOutstanding,
  processDualLedgerPayment,
  reverseTransactionBalance,
} from "@/lib/paymentService";

const PAYMENT_TARGETS = [
  { value: "OUTSTANDING_BALANCE", label: "Pay Current Issued Goods / Invoice" },
  { value: "PREVIOUS_BALANCE", label: "Pay Previous Balance / Arrears" },
];

export default function CustomerLedgerDialog({ customer, open, onClose, transactions, onRefresh }) {
  const { data: products = [] } = useProducts();
  const invalidate = useInvalidateProducts();
  const { requirePassphrase, modal } = usePassphraseGuard();

  const [live, setLive] = useState(customer);
  const [mode, setMode] = useState(null);
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState("");

  // payment form
  const [payAmount, setPayAmount] = useState("");
  const [payMethod, setPayMethod] = useState("");
  const [payTarget, setPayTarget] = useState("OUTSTANDING_BALANCE");
  const [payDesc, setPayDesc] = useState("");

  // receipt
  const [receipt, setReceipt] = useState(null);

  // Backfill outstanding_balance from history on open (lazy dual-ledger migration).
  useEffect(() => {
    if (!open || !customer) return;
    let cancelled = false;
    setLive(customer);
    (async () => {
      const e = await ensureOutstandingBalance("CUSTOMER", customer, transactions);
      if (!cancelled) setLive(e);
    })();
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, customer?.id]);

  const myTx = useMemo(
    () =>
      (transactions || [])
        .filter((t) => t.customer_id === customer?.id)
        .sort((a, b) => new Date(b.date || b.created_date) - new Date(a.date || a.created_date)),
    [transactions, customer]
  );

  const prevBal = Number(live?.previous_balance || 0);
  const outBal = Number(live?.outstanding_balance || 0);
  const totalDebt = prevBal + outBal;

  const resetForms = () => {
    setMode(null);
    setPayAmount(""); setPayMethod(""); setPayTarget("OUTSTANDING_BALANCE"); setPayDesc("");
    setErr("");
  };

  const handleSale = async (lines, upfront) => {
    setSaving(true); setErr("");
    try {
      const [refNum] = await nextReferenceNumbers(1);
      const total = lines.reduce((s, l) => s + Number(l.quantity_cartons) * Number(l.selling_price_per_unit), 0);
      // Upfront payment can never exceed the invoice total.
      const paidUpfront = Math.min(Math.max(0, Number(upfront?.amount) || 0), total);
      const method = paidUpfront > 0 ? (upfront?.method || "") : "";
      const status = paidUpfront <= 0 ? "unpaid" : paidUpfront >= total ? "paid" : "partial";
      const outBefore = Number(live?.outstanding_balance || 0);
      const sale = await base44.entities.CustomerTransaction.create({
        customer_id: customer.id,
        customer_name: customer.name,
        type: "sale",
        amount: total,
        reference_number: refNum,
        lines: lines.map((l) => ({
          product_id: l.product_id,
          product_name: l.product_name,
          quantity_cartons: l.quantity_cartons,
          cost_price_per_unit: l.cost_price_per_unit,
          selling_price_per_unit: l.selling_price_per_unit,
        })),
        amount_paid_at_purchase: paidUpfront,
        initial_payment_method: method,
        payment_status: status,
        previous_balance_before: prevBal,
        previous_balance_after: prevBal,
        outstanding_balance_before: outBefore,
        outstanding_balance_after: outBefore + total,
        date: new Date().toISOString(),
      });
      for (const l of lines) {
        await adjustStock(l.product_id, -Number(l.quantity_cartons));
      }
      await invalidate();
      let newOut = await applySaleToOutstanding("CUSTOMER", customer.id, total);

      // Record the upfront payment as its own ledger entry (and income), so the
      // goods balance only carries what is genuinely still owed.
      if (paidUpfront > 0) {
        const snap = await processDualLedgerPayment({
          entityType: "CUSTOMER",
          entityId: customer.id,
          amount: paidUpfront,
          paymentTarget: "OUTSTANDING_BALANCE",
        });
        const [payRef] = await nextReferenceNumbers(1);
        await base44.entities.CustomerTransaction.create({
          customer_id: customer.id,
          customer_name: customer.name,
          type: "payment",
          amount: paidUpfront,
          reference_number: payRef,
          payment_method: method,
          payment_target: "OUTSTANDING_BALANCE",
          invoice_id: sale?.id || "",
          description: `Payment at time of purchase · ${refNum}`,
          previous_balance_before: snap.previousBalanceBefore,
          previous_balance_after: snap.previousBalanceAfter,
          outstanding_balance_before: snap.outstandingBalanceBefore,
          outstanding_balance_after: snap.outstandingBalanceAfter,
          date: new Date().toISOString(),
        });
        await base44.entities.IncomeLog.create({
          source: "customer",
          reference_id: customer.id,
          reference_name: customer.name,
          amount: paidUpfront,
          payment_method: method,
          description: `Payment at time of purchase — ${customer.name}`,
          date: new Date().toISOString(),
        });
        newOut = snap.outstandingBalanceAfter;
      }

      setLive((p) => ({ ...p, outstanding_balance: newOut }));
      resetForms();
      onRefresh?.();
    } catch (error) {
      setErr(error?.message || "Failed to record sale");
    } finally {
      setSaving(false);
    }
  };

  const handlePayment = async (e) => {
    e.preventDefault();
    setSaving(true); setErr("");
    try {
      const amt = Number(payAmount) || 0;
      const snap = await processDualLedgerPayment({
        entityType: "CUSTOMER",
        entityId: customer.id,
        amount: amt,
        paymentTarget: payTarget,
      });
      const [refNum] = await nextReferenceNumbers(1);
      await base44.entities.CustomerTransaction.create({
        customer_id: customer.id,
        customer_name: customer.name,
        type: "payment",
        amount: amt,
        reference_number: refNum,
        payment_method: payMethod,
        payment_target: payTarget,
        description: payDesc,
        previous_balance_before: snap.previousBalanceBefore,
        previous_balance_after: snap.previousBalanceAfter,
        outstanding_balance_before: snap.outstandingBalanceBefore,
        outstanding_balance_after: snap.outstandingBalanceAfter,
        date: new Date().toISOString(),
      });
      await base44.entities.IncomeLog.create({
        source: "customer",
        reference_id: customer.id,
        reference_name: customer.name,
        amount: amt,
        payment_method: payMethod,
        description: `Payment from ${customer.name}`,
        date: new Date().toISOString(),
      });
      setLive((p) => ({
        ...p,
        previous_balance: snap.previousBalanceAfter,
        outstanding_balance: snap.outstandingBalanceAfter,
      }));
      resetForms();
      onRefresh?.();
    } catch (error) {
      setErr(error?.message || "Failed to record payment");
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = (t) => {
    requirePassphrase(`delete ${t.type} entry for ${customer?.name}`, async () => {
      await reverseTransactionBalance("CUSTOMER", customer.id, t);
      await base44.entities.CustomerTransaction.delete(t.id);
      if (t.type === "sale") {
        // A sale carrying an upfront payment also owns that payment entry —
        // remove it too so the ledger and balances stay exact.
        const linkedUpfront = myTx.filter((x) => x.type === "payment" && x.invoice_id === t.id);
        for (const p of linkedUpfront) {
          await reverseTransactionBalance("CUSTOMER", customer.id, p);
          await base44.entities.CustomerTransaction.delete(p.id);
        }
        const lines = Array.isArray(t.lines) && t.lines.length
          ? t.lines
          : (t.product_id ? [{ product_id: t.product_id, quantity_cartons: t.quantity_cartons }] : []);
        for (const l of lines) {
          if (l.product_id && l.quantity_cartons) await adjustStock(l.product_id, Number(l.quantity_cartons) || 0);
        }
        await invalidate();
      }
      const ent = await base44.entities.Customer.get(customer.id);
      setLive(ent);
      onRefresh?.();
    });
  };

  const handleExport = () => {
    downloadCSV(`${customer?.name || "customer"}-ledger`, [
      { label: "Date", value: (t) => formatDate(t.date || t.created_date) },
      { label: "Reference", value: (t) => t.reference_number || "" },
      { label: "Type", value: (t) => (t.type === "sale" ? "Sale" : "Payment") },
      { label: "Details", value: (t) => (t.type === "sale" ? transactionItemsLabel(t) : (t.description || "")) },
      { label: "Amount (GHS)", value: (t) => Number(t.amount || 0).toFixed(2) },
      { label: "Payment Target", value: (t) => (t.type === "payment" ? (t.payment_target || "OUTSTANDING_BALANCE") : "") },
      { label: "Prev. Before", value: (t) => (t.previous_balance_before != null ? Number(t.previous_balance_before).toFixed(2) : "") },
      { label: "Prev. After", value: (t) => (t.previous_balance_after != null ? Number(t.previous_balance_after).toFixed(2) : "") },
      { label: "Out. Before", value: (t) => (t.outstanding_balance_before != null ? Number(t.outstanding_balance_before).toFixed(2) : "") },
      { label: "Out. After", value: (t) => (t.outstanding_balance_after != null ? Number(t.outstanding_balance_after).toFixed(2) : "") },
      { label: "Profit (GHS)", value: (t) => (t.type === "sale" ? transactionProfit(t).toFixed(2) : "") },
      { label: "Payment Method", value: (t) => t.payment_method || "" },
      { label: "Description", value: (t) => t.description || "" },
    ], myTx);
  };

  const openReceipt = (t) => {
    const prevBefore = Number(t.previous_balance_before ?? prevBal);
    const outBefore = Number(t.outstanding_balance_before ?? outBal);
    const isSale = t.type === "sale";
    const amt = Number(t.amount || 0);
    const prevAfter = Number(t.previous_balance_after ?? prevBefore);
    const storedOutAfter = nonNegative(t.outstanding_balance_after ?? (isSale ? outBefore + amt : Math.max(0, outBefore - amt)));
    // The upfront payment on this sale is already settled, so it must not show
    // up as still owed on the invoice.
    const paidUpfront = isSale ? Math.max(0, Number(t.amount_paid_at_purchase || 0)) : 0;
    const outAfter = Math.max(0, storedOutAfter - paidUpfront);
    setReceipt({
      tx: t,
      balances: { previousBefore: prevBefore, previousAfter: prevAfter, outstandingBefore: outBefore, outstandingAfter: outAfter },
    });
  };

  // Live preview of how the payment splits across the two balances.
  const amt = Number(payAmount) || 0;
  let appliedPrev = 0, appliedOut = 0, previewPrev = prevBal, previewOut = outBal;
  if (payTarget === "PREVIOUS_BALANCE") {
    appliedPrev = Math.min(amt, prevBal);
    appliedOut = Math.max(0, amt - prevBal);
    previewPrev = Math.max(0, prevBal - amt);
    previewOut = Math.max(0, outBal - appliedOut);
  } else {
    appliedOut = amt;
    previewOut = Math.max(0, outBal - amt);
  }

  return (
    <Dialog open={open} onOpenChange={(o) => !o && (resetForms(), onClose?.())}>
      <DialogContent className="sm:max-w-3xl">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between gap-2 pr-8">
            <span>Ledger — {customer?.name}</span>
          </DialogTitle>
          <DialogDescription className="flex flex-wrap gap-2">
            <span className="inline-block rounded bg-rose-50 px-2 py-0.5 text-rose-800">Previous Balance: <b>{formatGHS(prevBal)}</b></span>
            <span className="inline-block rounded bg-amber-50 px-2 py-0.5 text-amber-900">Outstanding Balance: <b>{formatGHS(outBal)}</b></span>
            <span className="inline-block rounded bg-slate-100 px-2 py-0.5 text-slate-900">Total Combined Debt: <b>{formatGHS(totalDebt)}</b></span>
          </DialogDescription>
        </DialogHeader>

        <div className="flex gap-2">
          <Button
            type="button"
            size="sm"
            variant={mode === "sale" ? "default" : "outline"}
            onClick={() => { setMode(mode === "sale" ? null : "sale"); setErr(""); }}
          >
            <ShoppingBag className="h-4 w-4 mr-1" /> Record Sale
          </Button>
          <Button
            type="button"
            size="sm"
            variant={mode === "payment" ? "default" : "outline"}
            onClick={() => { setMode(mode === "payment" ? null : "payment"); setErr(""); }}
          >
            <Wallet className="h-4 w-4 mr-1" /> Pay Balance
          </Button>
          <Button type="button" size="sm" variant="outline" className="ml-auto" onClick={handleExport} disabled={myTx.length === 0}>
            <Download className="h-4 w-4 mr-1" /> Export CSV
          </Button>
        </div>

        {mode === "sale" && (
          <MultiProductSaleForm
            products={products}
            onSubmit={handleSale}
            onCancel={() => setMode(null)}
            saving={saving}
            submitLabel="Record Sale"
            allowUpfront
          />
        )}

        {mode === "payment" && (
          <form onSubmit={handlePayment} className="grid grid-cols-1 sm:grid-cols-2 gap-3 rounded-lg border p-3 bg-muted/30">
            <div className="space-y-1.5">
              <Label>Payment Amount (GHS)</Label>
              <Input type="number" min="0" step="0.01" value={payAmount} onChange={(e) => setPayAmount(sanitizeAmountInput(e.target.value))} required />
            </div>
            <div className="space-y-1.5">
              <Label>Payment Method</Label>
              <Select value={payMethod} onValueChange={setPayMethod} required>
                <SelectTrigger><SelectValue placeholder="Select method" /></SelectTrigger>
                <SelectContent>
                  {PAYMENT_METHODS.map((m) => <SelectItem key={m} value={m}>{m}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="sm:col-span-2 space-y-1.5">
              <Label>Payment Target</Label>
              <Select value={payTarget} onValueChange={setPayTarget} required>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {PAYMENT_TARGETS.map((t) => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="sm:col-span-2 space-y-1.5">
              <Label>Description (optional)</Label>
              <Input value={payDesc} onChange={(e) => setPayDesc(e.target.value)} />
            </div>
            {amt > 0 && (
              <div className="sm:col-span-2 rounded-md border bg-background p-2.5 text-sm space-y-1">
                <p className="font-medium">Allocation preview</p>
                {payTarget === "PREVIOUS_BALANCE" ? (
                  <>
                    <p className="text-muted-foreground">Applied to Previous: <b className="text-rose-700">{formatGHS(appliedPrev)}</b>{appliedOut > 0 && <> · Overflow to Outstanding: <b className="text-amber-700">{formatGHS(appliedOut)}</b></>}</p>
                  </>
                ) : (
                  <p className="text-muted-foreground">Applied to Outstanding: <b className="text-amber-700">{formatGHS(appliedOut)}</b></p>
                )}
                <p className="text-muted-foreground">Remaining Previous: <b className="text-rose-700">{formatGHS(previewPrev)}</b> · Remaining Outstanding: <b className="text-amber-700">{formatGHS(previewOut)}</b></p>
                <p className="text-muted-foreground">Total remaining debt: <b className="text-slate-900">{formatGHS(previewPrev + previewOut)}</b></p>
              </div>
            )}
            <div className="sm:col-span-2 flex justify-end gap-2">
              <Button type="button" variant="ghost" onClick={() => setMode(null)}>Cancel</Button>
              <Button type="submit" disabled={saving || !payMethod}>Record Payment</Button>
            </div>
          </form>
        )}

        {err && <p className="text-sm text-destructive">{err}</p>}

        <div className="rounded-lg border">
          <div className="sticky-header grid grid-cols-12 gap-2 px-3 py-2 text-xs font-semibold text-muted-foreground">
            <div className="col-span-2">Date</div>
            <div className="col-span-2">Type</div>
            <div className="col-span-2">Details</div>
            <div className="col-span-2 text-right">Amount</div>
            <div className="col-span-2 text-right">Profit</div>
            <div className="col-span-2 text-right">Actions</div>
          </div>
          <ScrollArea className="max-h-64">
            {myTx.length === 0 && (
              <div className="px-3 py-6 text-center text-sm text-muted-foreground">No transactions yet.</div>
            )}
            {myTx.map((t) => {
              const profit = transactionProfit(t);
              return (
                <div key={t.id} className="grid grid-cols-12 gap-2 border-b px-3 py-2 text-sm last:border-0 items-center">
                  <div className="col-span-2 text-xs text-muted-foreground">{formatDate(t.date || t.created_date)}</div>
                  <div className="col-span-2">
                    <span className={`inline-block rounded px-1.5 py-0.5 text-xs font-medium ${t.type === "sale" ? "bg-blue-100 text-blue-700" : "bg-emerald-100 text-emerald-700"}`}>
                      {t.type === "sale" ? "Sale" : "Payment"}
                    </span>
                    {t.type === "payment" && t.payment_target && (
                      <span className="ml-1 text-[10px] text-muted-foreground">{t.payment_target === "PREVIOUS_BALANCE" ? "→ Prev" : "→ Curr"}</span>
                    )}
                  </div>
                  <div className="col-span-2 text-xs">
                    {t.type === "sale" ? transactionItemsLabel(t) : (t.description || "—")}
                  </div>
                  <div className={`col-span-2 text-right font-medium ${t.type === "sale" ? "text-amber-600" : "text-emerald-600"}`}>
                    {t.type === "sale" ? "+" : "−"}{formatGHS(t.amount)}
                  </div>
                  <div className={`col-span-2 text-right text-xs font-medium rounded px-1 ${t.type === "sale" && profit > 0 ? "bg-emerald-50 text-emerald-800" : "text-muted-foreground"}`}>
                    {t.type === "sale" ? formatGHS(profit) : "—"}
                  </div>
                  <div className="col-span-2 flex justify-end gap-1">
                    <Button type="button" variant="ghost" size="icon" className="h-7 w-7" onClick={() => openReceipt(t)} title="Print receipt">
                      <Receipt className="h-3.5 w-3.5" />
                    </Button>
                    <Button type="button" variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={() => handleDelete(t)} title="Delete">
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </div>
              );
            })}
          </ScrollArea>
        </div>

        <ReceiptModal
          open={!!receipt}
          onClose={() => setReceipt(null)}
          party={customer}
          partyType="customer"
          transaction={receipt?.tx}
          balances={receipt?.balances}
        />
        {modal}
      </DialogContent>
    </Dialog>
  );
}