import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { sanitizeAmountInput } from "@/lib/money";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { base44 } from "@/api/base44Client";
import { toast } from "@/components/ui/use-toast";

const todayInput = () => new Date().toISOString().slice(0, 10);

// One dialog for every capital movement: Money In (inflow), Money Out (outflow),
// or Transfer (between two accounts). Transfers move capital without changing
// the total. Supports editing existing transactions.
export default function TransactionFormDialog({ open, onClose, onSaved, accounts = [], initial, initialMode = "inflow", lockAccount }) {
  const [mode, setMode] = useState(initialMode);
  const [accountId, setAccountId] = useState("");
  const [fromId, setFromId] = useState("");
  const [toId, setToId] = useState("");
  const [amount, setAmount] = useState("");
  const [date, setDate] = useState(todayInput());
  const [reference, setReference] = useState("");
  const [description, setDescription] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!open) return;
    if (initial) {
      setMode(initial.direction || "inflow");
      setAccountId(initial.to_account_id || initial.from_account_id || lockAccount?.id || "");
      setFromId(initial.from_account_id || "");
      setToId(initial.to_account_id || "");
      setAmount(String(initial.amount ?? ""));
      setDate((initial.date ? new Date(initial.date) : new Date()).toISOString().slice(0, 10));
      setReference(initial.reference || "");
      setDescription(initial.description || "");
    } else {
      setMode(initialMode);
      if (initialMode === "transfer") {
        setFromId(lockAccount?.id || "");
        setToId("");
        setAccountId("");
      } else {
        setAccountId(lockAccount?.id || "");
        setFromId("");
        setToId("");
      }
      setAmount("");
      setDate(todayInput());
      setReference("");
      setDescription("");
    }
  }, [open, initial, initialMode, lockAccount]);

  const nameOf = (id) => accounts.find((a) => a.id === id)?.name || "";

  const handleSave = async () => {
    const amt = Number(amount);
    if (!Number.isFinite(amt) || amt <= 0) {
      toast({ title: "Enter a valid amount", variant: "destructive" });
      return;
    }
    let fromId2 = "", toId2 = "", direction = mode;
    if (mode === "inflow") {
      toId2 = accountId;
      if (!toId2) { toast({ title: "Select an account", variant: "destructive" }); return; }
    } else if (mode === "outflow") {
      fromId2 = accountId;
      if (!fromId2) { toast({ title: "Select an account", variant: "destructive" }); return; }
    } else {
      fromId2 = fromId;
      toId2 = toId;
      if (!fromId2 || !toId2) { toast({ title: "Select both accounts", variant: "destructive" }); return; }
      if (fromId2 === toId2) { toast({ title: "Choose different accounts", variant: "destructive" }); return; }
    }
    setSaving(true);
    try {
      const payload = {
        amount: amt,
        from_account_id: fromId2,
        from_account_name: nameOf(fromId2),
        to_account_id: toId2,
        to_account_name: nameOf(toId2),
        direction,
        reference,
        description,
        date: new Date(date).toISOString(),
      };
      if (initial?.id) await base44.entities.CapitalTransaction.update(initial.id, payload);
      else await base44.entities.CapitalTransaction.create(payload);
      toast({ title: initial?.id ? "Transaction updated" : "Transaction recorded", description: "Affected balances recalculated." });
      onSaved?.();
      onClose();
    } catch (e) {
      toast({ title: "Could not save", description: e.message, variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{initial ? "Edit Transaction" : "Record Transaction"}</DialogTitle>
          <DialogDescription>
            Money In adds capital, Money Out removes it, and Transfer moves it between accounts without changing the total.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-3 py-2">
          {!lockAccount && (
            <div className="grid grid-cols-3 gap-1 rounded-lg bg-muted/50 p-1">
              {[{ k: "inflow", l: "Money In" }, { k: "outflow", l: "Money Out" }, { k: "transfer", l: "Transfer" }].map((o) => (
                <button
                  key={o.k}
                  type="button"
                  onClick={() => setMode(o.k)}
                  className={`rounded-md px-2 py-1.5 text-xs font-medium ${mode === o.k ? "bg-background shadow-sm" : "text-muted-foreground hover:text-foreground"}`}
                >
                  {o.l}
                </button>
              ))}
            </div>
          )}

          {mode === "transfer" ? (
            <div className="grid grid-cols-2 gap-3">
              <Field label="From">
                <Select value={fromId} onValueChange={setFromId} disabled={!!lockAccount}>
                  <SelectTrigger><SelectValue placeholder="Account" /></SelectTrigger>
                  <SelectContent>
                    {accounts.map((a) => <SelectItem key={a.id} value={a.id}>{a.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </Field>
              <Field label="To">
                <Select value={toId} onValueChange={setToId}>
                  <SelectTrigger><SelectValue placeholder="Account" /></SelectTrigger>
                  <SelectContent>
                    {accounts.map((a) => <SelectItem key={a.id} value={a.id}>{a.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </Field>
            </div>
          ) : (
            <Field label={mode === "inflow" ? "Receiving Account" : "Sending Account"}>
              <Select value={accountId} onValueChange={setAccountId} disabled={!!lockAccount}>
                <SelectTrigger><SelectValue placeholder="Select account" /></SelectTrigger>
                <SelectContent>
                  {accounts.map((a) => <SelectItem key={a.id} value={a.id}>{a.name}{a.reference ? ` · ${a.reference}` : ""}</SelectItem>)}
                </SelectContent>
              </Select>
            </Field>
          )}

          <Field label="Amount (GHS)"><Input type="number" step="0.01" value={amount} onChange={(e) => setAmount(sanitizeAmountInput(e.target.value))} /></Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Date"><Input type="date" value={date} onChange={(e) => setDate(e.target.value)} /></Field>
            <Field label="Reference"><Input value={reference} onChange={(e) => setReference(e.target.value)} placeholder="optional" /></Field>
          </div>
          <Field label="Description"><Input value={description} onChange={(e) => setDescription(e.target.value)} placeholder="optional notes" /></Field>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={saving}>Cancel</Button>
          <Button onClick={handleSave} disabled={saving}>{saving ? "Saving…" : "Save"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function Field({ label, children }) {
  return <div className="space-y-1.5"><Label>{label}</Label>{children}</div>;
}