import { formatGHS } from "@/lib/format";
import { Landmark, Smartphone, Wallet, Coins } from "lucide-react";
import { totalByType, accountBalance } from "@/lib/capital";

// Top-of-page summary: total bank / MoMo / cash / total other capital, plus a
// per-account breakdown of where capital currently sits.
export default function CapitalSummary({ accounts = [], transactions = [] }) {
  const bank = totalByType(accounts, transactions, "bank");
  const momo = totalByType(accounts, transactions, "momo");
  const cash = totalByType(accounts, transactions, "cash");
  const total = bank + momo + cash;
  const banks = accounts.filter((a) => a.account_type === "bank");
  const momos = accounts.filter((a) => a.account_type === "momo");

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <SummaryCard label="Total Bank Capital" value={formatGHS(bank)} icon={Landmark} tone="sky" />
        <SummaryCard label="Total MoMo Capital" value={formatGHS(momo)} icon={Smartphone} tone="violet" />
        <SummaryCard label="Cash at Hand" value={formatGHS(cash)} icon={Wallet} tone="amber" />
        <SummaryCard label="Total Other Capital" value={formatGHS(total)} icon={Coins} tone="emerald" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Breakdown title="Bank Breakdown" accounts={banks} transactions={transactions} icon={Landmark} />
        <Breakdown title="MoMo Breakdown" accounts={momos} transactions={transactions} icon={Smartphone} />
      </div>
    </div>
  );
}

function SummaryCard({ label, value, icon: Icon, tone }) {
  const toneMap = {
    sky: "bg-sky-100 text-sky-600",
    violet: "bg-violet-100 text-violet-600",
    amber: "bg-amber-100 text-amber-600",
    emerald: "bg-emerald-100 text-emerald-600",
  };
  return (
    <div className="rounded-xl border bg-card shadow-sm p-4">
      <div className="flex items-center justify-between">
        <p className="text-xs font-medium text-muted-foreground">{label}</p>
        <span className={`flex h-8 w-8 items-center justify-center rounded-lg ${toneMap[tone] || "bg-muted text-muted-foreground"}`}>
          <Icon className="h-4 w-4" />
        </span>
      </div>
      <p className="mt-2 font-heading text-2xl font-semibold">{value}</p>
    </div>
  );
}

function Breakdown({ title, accounts, transactions, icon: Icon }) {
  return (
    <div className="rounded-xl border bg-card shadow-sm overflow-hidden">
      <h3 className="font-heading font-semibold px-4 py-3 border-b flex items-center gap-2">
        <Icon className="h-4 w-4 text-muted-foreground" />{title}
      </h3>
      <div className="divide-y">
        {accounts.length === 0 && <div className="px-4 py-4 text-sm text-muted-foreground">No accounts yet.</div>}
        {accounts.map((a) => (
          <div key={a.id} className="flex items-center justify-between gap-2 px-4 py-2.5 text-sm">
            <div className="min-w-0">
              <p className="font-medium truncate">{a.name}</p>
              {a.reference && <p className="text-xs text-muted-foreground truncate">{a.reference}</p>}
            </div>
            <span className="font-medium shrink-0">{formatGHS(accountBalance(a, transactions))}</span>
          </div>
        ))}
      </div>
    </div>
  );
}