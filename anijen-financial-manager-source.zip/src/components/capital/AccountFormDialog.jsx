import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { sanitizeAmountInput } from "@/lib/money";
import { Label } from "@/components/ui/label";
import { base44 } from "@/api/base44Client";
import { toast } from "@/components/ui/use-toast";

// Add or edit a capital account (bank / MoMo / cash). Cash is a single account
// representing physical money on hand; its opening balance is the current cash.
export default function AccountFormDialog({ open, onClose, onSaved, initial, type = "bank" }) {
  const [name, setName] = useState("");
  const [reference, setReference] = useState("");
  const [opening, setOpening] = useState("0");
  const [saving, setSaving] = useState(false);

  const t = initial?.account_type || type;
  const title = t === "bank" ? "Bank" : t === "momo" ? "Mobile Money Account" : "Cash Account";

  useEffect(() => {
    if (!open) return;
    setName(initial?.name || "");
    setReference(initial?.reference || "");
    setOpening(String(initial?.opening_balance ?? 0));
  }, [open, initial]);

  const handleSave = async () => {
    if (!name.trim()) {
      toast({ title: "Enter a name", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      const payload = {
        name: name.trim(),
        account_type: t,
        reference: reference.trim(),
        opening_balance: Number(opening) || 0,
        sort_order: initial?.sort_order || 0,
      };
      if (initial?.id) await base44.entities.CapitalAccount.update(initial.id, payload);
      else await base44.entities.CapitalAccount.create(payload);
      onSaved?.();
      onClose();
    } catch (e) {
      toast({ title: "Could not save", description: e.message, variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{initial ? `Edit ${title}` : `Add ${title}`}</DialogTitle>
          {t === "cash" && (
            <DialogDescription>Enter the current physical cash on hand. Cash in/out transactions adjust it automatically.</DialogDescription>
          )}
        </DialogHeader>
        <div className="space-y-3 py-2">
          <div className="space-y-1.5">
            <Label>{t === "bank" ? "Bank Name" : t === "momo" ? "MoMo Provider / Name" : "Name"}</Label>
            <Input value={name} onChange={(e) => setName(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label>{t === "bank" ? "Account / Reference Number" : t === "momo" ? "MoMo Number" : "Reference"}</Label>
            <Input value={reference} onChange={(e) => setReference(e.target.value)} placeholder="optional" />
          </div>
          <div className="space-y-1.5">
            <Label>Opening Balance (GHS)</Label>
            <Input type="number" step="0.01" value={opening} onChange={(e) => setOpening(sanitizeAmountInput(e.target.value))} />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={saving}>Cancel</Button>
          <Button onClick={handleSave} disabled={saving}>{saving ? "Saving…" : "Save"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}