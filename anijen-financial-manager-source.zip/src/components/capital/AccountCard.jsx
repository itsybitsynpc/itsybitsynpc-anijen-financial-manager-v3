import { formatGHS, formatDate } from "@/lib/format";
import { accountBalance, accountDeposited, accountWithdrawn, accountTransactions } from "@/lib/capital";
import { Button } from "@/components/ui/button";
import { Pencil, Trash2, ArrowDownCircle, ArrowUpCircle, History } from "lucide-react";

export default function AccountCard({ account, transactions, onDeposit, onWithdraw, onEdit, onDelete, onOpenHistory, inLabel = "Deposit", outLabel = "Withdraw" }) {
  const balance = accountBalance(account, transactions);
  const deposited = accountDeposited(account, transactions);
  const withdrawn = accountWithdrawn(account, transactions);
  const recent = accountTransactions(account, transactions).slice(0, 4);

  return (
    <div className="rounded-xl border bg-card shadow-sm p-4 flex flex-col gap-3">
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <p className="font-heading font-semibold truncate">{account.name}</p>
          {account.reference && <p className="text-xs text-muted-foreground truncate">{account.reference}</p>}
        </div>
        <div className="flex items-center gap-0.5 shrink-0">
          {onEdit && (
            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={onEdit} title="Edit account"><Pencil className="h-3.5 w-3.5" /></Button>
          )}
          {onDelete && (
            <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={onDelete} title="Delete account"><Trash2 className="h-3.5 w-3.5" /></Button>
          )}
        </div>
      </div>

      <div className="rounded-lg bg-muted/40 px-3 py-2">
        <p className="text-xs text-muted-foreground">Current Balance</p>
        <p className={`font-heading text-xl font-semibold ${balance >= 0 ? "text-emerald-600" : "text-rose-600"}`}>{formatGHS(balance)}</p>
      </div>

      <div className="grid grid-cols-2 gap-2 text-sm">
        <div><p className="text-xs text-muted-foreground">In</p><p className="font-medium text-emerald-600">{formatGHS(deposited)}</p></div>
        <div><p className="text-xs text-muted-foreground">Out</p><p className="font-medium text-rose-600">{formatGHS(withdrawn)}</p></div>
      </div>

      <div className="flex gap-2">
        <Button size="sm" className="gap-1 flex-1" onClick={onDeposit}><ArrowDownCircle className="h-4 w-4" />{inLabel}</Button>
        <Button size="sm" variant="outline" className="gap-1 flex-1" onClick={onWithdraw}><ArrowUpCircle className="h-4 w-4" />{outLabel}</Button>
      </div>

      <button onClick={onOpenHistory} className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground self-start">
        <History className="h-3.5 w-3.5" />View transaction history
      </button>

      {recent.length > 0 && (
        <div className="border-t pt-2 space-y-1.5">
          {recent.map((t) => <RecentRow key={t.id} t={t} accountId={account.id} />)}
        </div>
      )}
    </div>
  );
}

function RecentRow({ t, accountId }) {
  const incoming = t.to_account_id === accountId;
  return (
    <div className="flex items-center justify-between text-xs">
      <div className="min-w-0">
        <p className="font-medium truncate">{t.description || (incoming ? "Money in" : "Money out")}</p>
        <p className="text-muted-foreground">{formatDate(t.date || t.created_date)}</p>
      </div>
      <span className={`shrink-0 ${incoming ? "text-emerald-600" : "text-rose-600"}`}>{incoming ? "+" : "−"}{formatGHS(t.amount)}</span>
    </div>
  );
}