import { formatGHS, formatDate } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Pencil, Trash2 } from "lucide-react";

// Reusable transaction history list with optional edit/delete. Used in the
// Bank Transactions section and per-account history dialogs.
export default function TransactionList({ transactions = [], onEdit, onDelete, emptyText = "No transactions yet." }) {
  if (transactions.length === 0) {
    return <div className="px-4 py-6 text-center text-sm text-muted-foreground">{emptyText}</div>;
  }
  return (
    <div className="divide-y">
      {transactions.map((t) => {
        const from = t.from_account_name || (t.from_account_id ? "" : "External");
        const to = t.to_account_name || (t.to_account_id ? "" : "External");
        const label = t.direction === "transfer" ? `${from} → ${to}` : t.direction === "inflow" ? `In → ${to}` : `${from} → Out`;
        return (
          <div key={t.id} className="flex items-center justify-between gap-3 px-3 py-2.5 text-sm">
            <div className="min-w-0">
              <p className="font-medium truncate">{t.description || label}</p>
              <p className="text-xs text-muted-foreground truncate">{label} · {formatDate(t.date || t.created_date)}{t.reference ? ` · Ref ${t.reference}` : ""}</p>
            </div>
            <div className="flex items-center gap-1.5 shrink-0">
              <span className="font-medium">{formatGHS(t.amount)}</span>
              {onEdit && <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => onEdit(t)} title="Edit"><Pencil className="h-3.5 w-3.5" /></Button>}
              {onDelete && <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={() => onDelete(t)} title="Delete"><Trash2 className="h-3.5 w-3.5" /></Button>}
            </div>
          </div>
        );
      })}
    </div>
  );
}