import { Navigate, Outlet } from "react-router-dom";
import { useAuth } from "@/lib/AuthContext";

/**
 * Blocks every authenticated screen until the user belongs to at least one
 * company workspace, sending them to onboarding instead. Nobody sees a
 * dashboard scoped to a company they have not been provisioned into.
 */
export default function CompanyGate() {
  const { user } = useAuth();
  const companies = user?.company_ids || [];

  if (companies.length === 0) return <Navigate to="/onboarding" replace />;
  return <Outlet />;
}