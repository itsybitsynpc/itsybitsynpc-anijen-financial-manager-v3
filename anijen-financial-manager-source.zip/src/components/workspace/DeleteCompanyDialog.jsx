import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { queryClientInstance } from "@/lib/query-client";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { AlertTriangle, Loader2, Lock, ShieldAlert } from "lucide-react";

const CONFIRMATION_PHRASE = "DELETE MY COMPANY";

/**
 * Mandatory two-factor confirmation for destroying a workspace: an exact typed
 * phrase plus the master admin passphrase, both verified server-side before a
 * single record is touched.
 */
export default function DeleteCompanyDialog({ open, onClose, companyId, companyName }) {
  const [phrase, setPhrase] = useState("");
  const [passphrase, setPassphrase] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const phraseOk = phrase.trim() === CONFIRMATION_PHRASE;
  const canDelete = phraseOk && passphrase.length > 0 && !busy;

  const reset = () => {
    setPhrase("");
    setPassphrase("");
    setError("");
    setBusy(false);
  };

  const handleClose = () => {
    if (busy) return;
    reset();
    onClose?.();
  };

  const handleDelete = async () => {
    setBusy(true);
    setError("");
    try {
      const { data } = await base44.functions.invoke("deleteCompany", {
        company_id: companyId,
        confirmation: phrase.trim(),
        passphrase,
      });
      // Nothing from the destroyed tenant may survive in memory or cache.
      queryClientInstance.clear();
      window.location.href = data?.active_company_id ? "/" : "/onboarding";
    } catch (err) {
      const data = err?.response?.data;
      setError(data?.error || err?.message || "Deletion failed. Nothing was removed.");
      setBusy(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && handleClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <span className="flex h-9 w-9 items-center justify-center rounded-full bg-destructive/10 text-destructive">
              <AlertTriangle className="h-4 w-4" />
            </span>
            Delete workspace permanently
          </DialogTitle>
          <DialogDescription>
            This erases <span className="font-medium text-foreground">{companyName}</span> and all of its
            customers, ledgers, transactions, stock, expenses, capital accounts and logs. This cannot be undone.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="confirm-phrase">
              Type <code className="rounded bg-muted px-1 font-mono text-xs">{CONFIRMATION_PHRASE}</code> to confirm
            </Label>
            <Input
              id="confirm-phrase"
              value={phrase}
              onChange={(e) => setPhrase(e.target.value)}
              placeholder={CONFIRMATION_PHRASE}
              autoComplete="off"
              spellCheck={false}
              disabled={busy}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="admin-passphrase" className="flex items-center gap-1.5">
              <Lock className="h-3.5 w-3.5" /> Admin passphrase
            </Label>
            <Input
              id="admin-passphrase"
              type="password"
              value={passphrase}
              onChange={(e) => setPassphrase(e.target.value)}
              autoComplete="new-password"
              placeholder="Enter the security admin passphrase"
              disabled={busy}
            />
          </div>

          {error && (
            <div className="flex items-start gap-2 rounded-md bg-destructive/10 p-2 text-sm text-destructive">
              <ShieldAlert className="mt-0.5 h-4 w-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={handleClose} disabled={busy}>
            Cancel
          </Button>
          <Button variant="destructive" onClick={handleDelete} disabled={!canDelete}>
            {busy ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Deleting…
              </>
            ) : (
              "Delete workspace forever"
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}