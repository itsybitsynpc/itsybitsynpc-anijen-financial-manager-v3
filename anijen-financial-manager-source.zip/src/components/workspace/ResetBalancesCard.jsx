import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "@/components/ui/use-toast";
import { base44 } from "@/api/base44Client";
import useActiveCompany from "@/hooks/useActiveCompany";
import { RotateCcw, ShieldAlert } from "lucide-react";

const CONFIRMATION = "RESET BALANCES";

// Centralised "Clear all balances" control. Runs a server-verified reset for
// the active company only: every customer, sales person and capital account
// balance is wiped back to 0.00, invoice upfront payments are cleared and
// statuses return to Unpaid. Transaction history is preserved.
export default function ResetBalancesCard() {
  const [passphrase, setPassphrase] = useState("");
  const [confirmation, setConfirmation] = useState("");
  const [includeCapitalLedger, setIncludeCapitalLedger] = useState(false);
  const [working, setWorking] = useState(false);
  const [cleared, setCleared] = useState(null);

  const { activeId, memberships, activeName, loading } = useActiveCompany();

  // The company to reset: the server-assigned active one, or the caller's only
  // workspace when the account has no active company selected yet.
  const companyId = activeId || (memberships.length === 1 ? memberships[0].company_id : "");
  const companyLabel = activeName || memberships.find((m) => m.company_id === companyId)?.company_name || "";
  const hasCompany = Boolean(companyId);

  const ready =
    hasCompany && !loading && passphrase.length > 0 && confirmation.trim().toUpperCase() === CONFIRMATION;

  const handleReset = async (e) => {
    e.preventDefault();
    if (!ready || working) return;
    setWorking(true);
    setCleared(null);
    try {
      const res = await base44.functions.invoke("resetFinancialData", {
        companyId,
        passphrase,
        confirmation: CONFIRMATION,
        includeCapitalLedger,
      });
      setCleared(res.data?.cleared || {});
      setPassphrase("");
      setConfirmation("");
      setIncludeCapitalLedger(false);
      toast({
        title: "All balances reset to GHS 0.00",
        description: "Customer, sales person and account balances are now zero.",
      });
    } catch (error) {
      const message = error?.response?.data?.error || error?.message || "Please try again.";
      toast({ title: "Reset failed", description: message, variant: "destructive" });
    } finally {
      setWorking(false);
    }
  };

  return (
    <div className="rounded-xl border border-rose-200 bg-rose-50/50 p-5">
      <div className="flex items-start gap-3">
        <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-rose-100 text-rose-600">
          <ShieldAlert className="h-5 w-5" />
        </span>
        <div>
          <p className="font-heading font-semibold">Clear All Balances</p>
          <p className="text-sm text-muted-foreground mt-1">
            Resets every balance in the active company to GHS 0.00 — customer and sales person
            previous / outstanding balances, invoice upfront payments (status back to Unpaid), and
            capital account opening balances. Nothing can drop below zero. Transaction history is kept.
          </p>
        </div>
      </div>

      <form onSubmit={handleReset} className="mt-4 space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div className="space-y-1.5">
            <Label htmlFor="reset-passphrase">Master passphrase</Label>
            <Input
              id="reset-passphrase"
              type="password"
              value={passphrase}
              onChange={(e) => setPassphrase(e.target.value)}
              placeholder="Enter admin passphrase"
              autoComplete="off"
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="reset-confirmation">Type “{CONFIRMATION}” to confirm</Label>
            <Input
              id="reset-confirmation"
              value={confirmation}
              onChange={(e) => setConfirmation(e.target.value)}
              placeholder={CONFIRMATION}
              autoComplete="off"
            />
          </div>
        </div>

        <label className="flex items-start gap-2 text-sm text-muted-foreground">
          <Checkbox
            checked={includeCapitalLedger}
            onCheckedChange={(v) => setIncludeCapitalLedger(v === true)}
            className="mt-0.5"
          />
          <span>
            Also clear capital movement history (Money In / Money Out / Transfers) so account totals
            read 0.00. This permanently deletes those ledger entries.
          </span>
        </label>

        {hasCompany ? (
          <p className="text-xs text-muted-foreground">
            Active company: <span className="font-medium text-foreground">{companyLabel || "Selected workspace"}</span>
          </p>
        ) : (
          <p className="text-xs text-destructive">
            {loading
              ? "Checking your workspaces…"
              : "No active company is selected. Choose a workspace in Workspace Settings before resetting balances."}
          </p>
        )}

        <Button type="submit" variant="destructive" disabled={!ready || working}>
          <RotateCcw className="h-4 w-4 mr-1" />
          {working ? "Resetting…" : "Reset all balances to 0.00"}
        </Button>

        {cleared && (
          <p className="text-xs text-muted-foreground">
            Reset complete — {cleared.customers ?? 0} customers, {cleared.salespersons ?? 0} sales
            persons, {cleared.invoices ?? 0} invoices, {cleared.accounts ?? 0} accounts
            {includeCapitalLedger ? `, ${cleared.capitalTransactions ?? 0} capital movements` : ""}.
          </p>
        )}
      </form>
    </div>
  );
}