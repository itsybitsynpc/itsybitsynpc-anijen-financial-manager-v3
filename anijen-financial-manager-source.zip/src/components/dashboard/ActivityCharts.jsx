import { useMemo, useState } from "react";
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from "recharts";
import { formatGHS } from "@/lib/format";
import { transactionProfit } from "@/lib/finance";
import { TrendingUp, TrendingDown } from "lucide-react";

const CATEGORIES = [
  { key: "income", label: "Income & Cash Flow", tone: "#10b981" },
  { key: "expenses", label: "Expenses & Transport", tone: "#f43f5e" },
  { key: "sales", label: "Sales & Volume", tone: "#0ea5e9" },
  { key: "profit", label: "Profit & Net Margin", tone: "#8b5cf6" },
  { key: "vehicle", label: "Vehicle Expenses", tone: "#f59e0b" },
];

function buildRecords(category, data) {
  const { incomeLogs = [], factoryPayments = [], expenses = [], custTx = [], vehicleExpenses = [] } = data;
  const pick = (r) => ({ date: r.date || r.created_date, value: Number(r.amount || 0) });
  switch (category) {
    case "income":
      return incomeLogs.map(pick);
    case "expenses":
      return [...factoryPayments.map(pick), ...expenses.map(pick)];
    case "vehicle":
      return vehicleExpenses.map(pick);
    case "sales":
      return custTx.filter((t) => t.type === "sale").map(pick);
    case "profit":
      return custTx
        .filter((t) => t.type === "sale")
        .map((t) => ({ date: t.date || t.created_date, value: transactionProfit(t) }));
    default:
      return [];
  }
}

function hourlySeries(records, dayStr) {
  const buckets = Array.from({ length: 24 }, (_, h) => ({ label: String(h).padStart(2, "0") + ":00", value: 0 }));
  for (const r of records) {
    const d = new Date(r.date);
    if (Number.isNaN(d.getTime())) continue;
    if (localDayStr(d) !== dayStr) continue;
    buckets[d.getHours()].value += r.value;
  }
  return buckets;
}

function monthlySeries(records) {
  const map = new Map();
  for (const r of records) {
    const d = new Date(r.date);
    if (Number.isNaN(d.getTime())) continue;
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
    map.set(key, (map.get(key) || 0) + r.value);
  }
  return [...map.entries()]
    .sort((a, b) => a[0].localeCompare(b[0]))
    .map(([key, value]) => ({
      label: new Date(Number(key.slice(0, 4)), Number(key.slice(5, 7)) - 1, 1)
        .toLocaleDateString(undefined, { month: "short", year: "2-digit" }),
      value,
    }));
}

function localDayStr(d) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function averages(records) {
  const total = records.reduce((s, r) => s + r.value, 0);
  const times = records.map((r) => new Date(r.date).getTime()).filter((t) => !Number.isNaN(t));
  if (!times.length) return { total: 0, daily: 0, monthly: 0, avgTx: 0 };
  const min = Math.min(...times);
  const max = Math.max(...times);
  const days = Math.max(1, Math.ceil((max - min) / 86400000) + 1);
  const minD = new Date(min);
  const maxD = new Date(max);
  const monthsSpan = (maxD.getFullYear() - minD.getFullYear()) * 12 + (maxD.getMonth() - minD.getMonth()) + 1;
  return {
    total,
    daily: total / days,
    monthly: total / Math.max(1, monthsSpan),
    avgTx: total / records.length,
  };
}

function selectedDayTotal(records, dayStr) {
  return records
    .filter((r) => localDayStr(new Date(r.date)) === dayStr)
    .reduce((s, r) => s + r.value, 0);
}

export default function ActivityCharts({ incomeLogs, factoryPayments, expenses, custTx, vehicleExpenses, mode, customDate }) {
  const [category, setCategory] = useState("income");
  const active = CATEGORIES.find((c) => c.key === category);
  const isCustom = mode === "custom" && !!customDate;

  const records = useMemo(
    () => buildRecords(category, { incomeLogs, factoryPayments, expenses, custTx, vehicleExpenses }),
    [category, incomeLogs, factoryPayments, expenses, custTx]
  );

  const series = useMemo(
    () => (isCustom ? hourlySeries(records, customDate) : monthlySeries(records)),
    [records, isCustom, customDate]
  );

  const avg = useMemo(() => averages(records), [records]);
  const dayTotal = useMemo(
    () => (isCustom ? selectedDayTotal(records, customDate) : avg.daily),
    [records, isCustom, customDate, avg.daily]
  );
  const pct = avg.daily ? ((dayTotal - avg.daily) / avg.daily) * 100 : 0;
  const up = pct >= 0;

  return (
    <div className="rounded-xl border bg-card shadow-sm">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 px-4 py-3 border-b">
        <h2 className="font-heading font-semibold">Visual Analytics</h2>
        <div className="flex flex-wrap gap-1 rounded-lg bg-muted/50 p-1">
          {CATEGORIES.map((c) => (
            <button
              key={c.key}
              onClick={() => setCategory(c.key)}
              className={`rounded-md px-2.5 py-1 text-xs font-medium transition-colors ${
                category === c.key ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {c.label}
            </button>
          ))}
        </div>
      </div>

      <div className="px-4 pt-3">
        <p className="text-xs text-muted-foreground">
          {active.label} · {isCustom ? `Hourly breakdown for ${new Date(customDate + "T00:00:00").toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" })}` : "Monthly trend (all-time)"}
        </p>
      </div>

      <div className="h-64 w-full px-2 py-3">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={series} margin={{ top: 10, right: 16, left: 8, bottom: 0 }}>
            <defs>
              <linearGradient id={`grad-${category}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor={active.tone} stopOpacity={0.35} />
                <stop offset="95%" stopColor={active.tone} stopOpacity={0.02} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
            <XAxis dataKey="label" tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" interval="preserveStartEnd" minTickGap={isCustom ? 2 : 0} />
            <YAxis tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" tickFormatter={(v) => (v >= 1000 ? `${(v / 1000).toFixed(1)}k` : String(v))} width={48} />
            <Tooltip
              contentStyle={{ borderRadius: 8, border: "1px solid hsl(var(--border))", fontSize: 12 }}
              formatter={(v) => [formatGHS(v), active.label]}
              labelStyle={{ fontWeight: 600 }}
            />
            <Area type="monotone" dataKey="value" stroke={active.tone} strokeWidth={2} fill={`url(#grad-${category})`} />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 px-4 pb-4">
        <AvgStat label="Daily Average" value={formatGHS(avg.daily)} />
        <AvgStat label="Monthly Average" value={formatGHS(avg.monthly)} />
        <AvgStat label="Avg Transaction" value={formatGHS(avg.avgTx)} />
        <div className="rounded-lg bg-muted/40 px-3 py-2">
          <p className="text-[11px] font-medium text-muted-foreground">
            {isCustom ? "Selected Day" : "Period Total"}
          </p>
          <div className="mt-0.5 flex items-center gap-2">
            <p className="font-heading text-sm font-semibold">{formatGHS(dayTotal)}</p>
            {isCustom && avg.daily > 0 && (
              <span className={`inline-flex items-center gap-0.5 rounded-full px-1.5 py-0.5 text-[10px] font-semibold ${up ? "bg-emerald-100 text-emerald-700" : "bg-rose-100 text-rose-700"}`}>
                {up ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
                {up ? "+" : ""}{pct.toFixed(1)}% vs daily avg
              </span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function AvgStat({ label, value }) {
  return (
    <div className="rounded-lg bg-muted/40 px-3 py-2">
      <p className="text-[11px] font-medium text-muted-foreground">{label}</p>
      <p className="mt-0.5 font-heading text-sm font-semibold">{value}</p>
    </div>
  );
}