import { useState } from "react";
import { AlertTriangle, Check, Package } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useInvalidateProducts } from "@/hooks/useProducts";
import { isLowStock, availableStock } from "@/lib/finance";
import { sanitizeAmountInput } from "@/lib/money";

export default function LowStockCard({ products }) {
  const invalidate = useInvalidateProducts();
  const [draft, setDraft] = useState({});
  const [saving, setSaving] = useState(null);

  const sorted = [...products].sort((a, b) => {
    const al = isLowStock(a) ? 0 : 1;
    const bl = isLowStock(b) ? 0 : 1;
    if (al !== bl) return al - bl;
    return availableStock(a) - availableStock(b);
  });

  const save = async (p) => {
    const val = draft[p.id];
    if (val == null || val === "") return;
    setSaving(p.id);
    try {
      await base44.entities.Product.update(p.id, { low_stock_threshold: Number(val) || 0 });
      await invalidate();
    } finally {
      setSaving(null);
    }
  };

  const lowCount = products.filter(isLowStock).length;

  return (
    <div className="rounded-xl border bg-card shadow-sm">
      <div className="flex items-center gap-2 px-4 py-3 border-b">
        <Package className="h-4 w-4 text-muted-foreground" />
        <h2 className="font-heading font-semibold">Stock Thresholds</h2>
        <span className="ml-1 text-xs text-muted-foreground hidden sm:inline">Set a minimum level; items at or below it are flagged red.</span>
        {lowCount > 0 && (
          <span className="ml-auto inline-flex items-center gap-1 rounded-full bg-red-100 text-red-700 px-2 py-0.5 text-xs font-semibold">
            <AlertTriangle className="h-3 w-3" /> {lowCount} low
          </span>
        )}
      </div>
      <div className="max-h-72 overflow-auto divide-y">
        {sorted.map((p) => {
          const stock = availableStock(p);
          const low = isLowStock(p);
          const cur = draft[p.id] ?? (p.low_stock_threshold ?? "");
          const changed = draft[p.id] != null && Number(draft[p.id]) !== Number(p.low_stock_threshold ?? 0);
          return (
            <div key={p.id} className={`flex items-center gap-3 px-4 py-2.5 text-sm ${low ? "bg-red-50 border-l-4 border-red-500" : ""}`}>
              <div className="flex-1 min-w-0">
                <p className={`font-medium truncate ${low ? "text-red-600 font-semibold" : ""}`}>{p.name}</p>
                <p className={`text-xs ${low ? "text-red-600 font-medium" : "text-muted-foreground"}`}>
                  {stock.toLocaleString()} cartons{low ? " · at/below threshold" : ""}
                </p>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="text-xs text-muted-foreground">Min</span>
                <input
                  type="number"
                  min="0"
                  step="1"
                  value={cur}
                  placeholder="—"
                  onChange={(e) => setDraft((d) => ({ ...d, [p.id]: sanitizeAmountInput(e.target.value) }))}
                  className="w-16 h-7 rounded-md border border-input bg-transparent px-2 text-right text-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
                />
                <button
                  onClick={() => save(p)}
                  disabled={!changed || saving === p.id}
                  className="inline-flex h-7 w-7 items-center justify-center rounded-md border text-emerald-600 hover:bg-emerald-50 disabled:opacity-40"
                  title="Save threshold"
                >
                  <Check className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}