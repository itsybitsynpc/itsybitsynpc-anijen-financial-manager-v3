import { useState } from "react";
import { AlertTriangle, X } from "lucide-react";
import { lowStockProducts, availableStock } from "@/lib/finance";

// Prominent, dismissible highlight shown whenever any product is at or below
// its configured low-stock threshold. Re-appears on the next load if dismissed.
export default function LowStockBanner({ products }) {
  const [dismissed, setDismissed] = useState(false);
  const low = lowStockProducts(products);

  if (low.length === 0 || dismissed) return null;

  return (
    <div className="rounded-xl border-2 border-red-500 bg-red-50 shadow-sm overflow-hidden">
      <div className="flex items-start gap-3 px-4 py-3">
        <span className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-red-600 text-white">
          <AlertTriangle className="h-5 w-5 animate-pulse" />
        </span>
        <div className="flex-1 min-w-0">
          <p className="font-heading font-bold text-red-700">
            Low Stock Alert — {low.length} product{low.length > 1 ? "s" : ""} at or below threshold
          </p>
          <p className="text-xs text-red-600 font-medium mt-0.5">Restock these items to avoid running out.</p>
          <div className="mt-2 flex flex-wrap gap-1.5">
            {low.map((p) => (
              <span
                key={p.id}
                className="inline-flex items-center gap-1 rounded-full bg-white border border-red-300 px-2.5 py-1 text-xs font-semibold text-red-700"
              >
                {p.name}: {availableStock(p).toLocaleString()} / {Number(p.low_stock_threshold || 0).toLocaleString()} cartons
              </span>
            ))}
          </div>
        </div>
        <button
          onClick={() => setDismissed(true)}
          className="shrink-0 rounded-md p-1 text-red-600 hover:bg-red-100 transition-colors"
          title="Dismiss"
          aria-label="Dismiss low stock alert"
        >
          <X className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}