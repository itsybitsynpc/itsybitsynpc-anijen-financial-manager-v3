import { RefreshCw, TrendingUp, TrendingDown, Wallet } from "lucide-react";
import {
  ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, Cell,
} from "recharts";
import { formatGHS } from "@/lib/format";
import { weekLabel } from "@/lib/weeklyAnalytics";
import { useRealTimeWeeklyProfit } from "@/hooks/useRealTimeWeeklyProfit";

const SERIES_COLORS = ["#10b981", "#0ea5e9", "#6366f1", "#f59e0b", "#ec4899", "#8b5cf6", "#14b8a6"];

function ChartTooltip({ active, payload, label, moneyKey }) {
  if (!active || !payload || !payload.length) return null;
  return (
    <div className="rounded-md border bg-background px-3 py-2 text-xs shadow-md">
      <p className="font-medium mb-1">{label}</p>
      {payload.map((p) => (
        <p key={p.dataKey} className="text-muted-foreground">
          {p.name}:{" "}
          <span className="font-medium text-foreground">
            {moneyKey && p.dataKey === moneyKey ? formatGHS(p.value) : Number(p.value || 0).toLocaleString()}
          </span>
        </p>
      ))}
    </div>
  );
}

function KpiCard({ label, value, subtitle, icon: Icon, tone }) {
  const toneMap = { emerald: "text-emerald-600", rose: "text-rose-600", primary: "text-primary" };
  return (
    <div className="rounded-xl border bg-card shadow-sm p-4">
      <div className="flex items-center justify-between">
        <p className="text-xs font-medium text-muted-foreground">{label}</p>
        <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-muted/60">
          <Icon className="h-4 w-4" />
        </span>
      </div>
      <p className={`mt-2 font-heading text-2xl font-semibold ${toneMap[tone] || "text-foreground"}`}>{value}</p>
      {subtitle && <p className="text-[11px] text-muted-foreground mt-0.5">{subtitle}</p>}
    </div>
  );
}

function ChartCard({ title, empty, children }) {
  return (
    <div className="rounded-xl border bg-card shadow-sm">
      <h3 className="font-heading font-semibold px-4 py-3 border-b text-sm">{title}</h3>
      <div className="p-4">
        {children || <div className="h-56 flex items-center justify-center text-sm text-muted-foreground">{empty}</div>}
      </div>
    </div>
  );
}

export default function DashboardWeeklyAnalytics({
  customerTransactions = [],
  salesPersonTransactions = [],
  expenses = [],
  vehicleExpenses = [],
  onRefresh,
  isLive = false,
  lastUpdated,
}) {
  const {
    range, wtdProfit, customerProfit, salespersonProfit, wtdExpenses, netWtdMargin,
    productVolume, spPerformance, customerPerformance,
  } = useRealTimeWeeklyProfit({ customerTransactions, salesPersonTransactions, expenses, vehicleExpenses });

  const label = weekLabel(range);
  const updatedTime = (lastUpdated ? new Date(lastUpdated) : new Date()).toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit", second: "2-digit" });

  return (
    <div className="rounded-xl border bg-card shadow-sm">
      <div className="flex items-center justify-between px-4 py-3 border-b">
        <div>
          <h2 className="font-heading font-semibold flex items-center gap-2">
            Weekly Analytics
            <span className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-medium ${isLive ? "bg-emerald-100 text-emerald-700" : "bg-muted text-muted-foreground"}`}>
              <span className={`h-1.5 w-1.5 rounded-full ${isLive ? "bg-emerald-500 animate-pulse" : "bg-muted-foreground"}`} />
              {isLive ? "Live" : "Connecting…"}
            </span>
          </h2>
          <p className="text-xs text-muted-foreground">{label} · Ghana (GMT) · updated {updatedTime}</p>
        </div>
        {onRefresh && (
          <button
            onClick={onRefresh}
            className="inline-flex items-center gap-1.5 rounded-md border px-2.5 py-1.5 text-xs font-medium hover:bg-accent"
            title="Re-fetch dashboard data"
          >
            <RefreshCw className="h-3.5 w-3.5" /> Refresh
          </button>
        )}
      </div>

      <div className="p-4 space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <KpiCard
            label="Weekly Realized Profit (WTD)"
            value={formatGHS(wtdProfit)}
            subtitle={`Customers ${formatGHS(customerProfit)} + Salespersons ${formatGHS(salespersonProfit)} · completed sales up to now.`}
            icon={TrendingUp}
            tone="emerald"
          />
          <KpiCard
            label="Weekly Total Expenses (WTD)"
            value={formatGHS(wtdExpenses)}
            subtitle="Includes operational, vehicle, Bank & GRA charges."
            icon={TrendingDown}
            tone="rose"
          />
          <KpiCard
            label="Net Dynamic Cash Margin"
            value={formatGHS(netWtdMargin)}
            subtitle="Realized Profit − Total Expenses (live)"
            icon={Wallet}
            tone={netWtdMargin >= 0 ? "emerald" : "rose"}
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <ChartCard title="Product Volume Sold This Week" empty="No completed sales recorded this week.">
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={productVolume} margin={{ top: 8, right: 8, left: 0, bottom: 8 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} className="stroke-muted" />
                  <XAxis dataKey="product_name" tick={{ fontSize: 11 }} interval={0} angle={-15} textAnchor="end" height={50} />
                  <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
                  <Tooltip content={<ChartTooltip />} />
                  <Bar dataKey="quantity_sold" name="Units Sold" radius={[4, 4, 0, 0]}>
                    {productVolume.map((_, i) => (
                      <Cell key={i} fill={SERIES_COLORS[i % SERIES_COLORS.length]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </ChartCard>

          <ChartCard title="Salesperson Performance This Week" empty="No agent activity recorded this week.">
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={spPerformance} margin={{ top: 8, right: 8, left: 0, bottom: 8 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} className="stroke-muted" />
                  <XAxis dataKey="salesperson_name" tick={{ fontSize: 11 }} interval={0} angle={-15} textAnchor="end" height={50} />
                  <YAxis yAxisId="units" orientation="left" tick={{ fontSize: 11 }} allowDecimals={false} />
                  <YAxis yAxisId="profit" orientation="right" tick={{ fontSize: 11 }} tickFormatter={(v) => `GH₵${Number(v).toLocaleString()}`} />
                  <Tooltip content={<ChartTooltip moneyKey="total_profit_earned" />} />
                  <Legend wrapperStyle={{ fontSize: 11 }} />
                  <Bar yAxisId="units" dataKey="total_quantity_sold" name="Units Sold" fill="#0ea5e9" radius={[4, 4, 0, 0]} />
                  <Bar yAxisId="profit" dataKey="total_profit_earned" name="Realized Profit" fill="#10b981" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </ChartCard>
        </div>

        {/* Per-customer realized profit & revenue breakdown (WTD) */}
        <ChartCard title="Customer Profit Breakdown This Week" empty="No completed customer sales recorded this week.">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-xs text-muted-foreground border-b">
                  <th className="py-2 pr-3 font-medium">Customer</th>
                  <th className="py-2 px-3 font-medium text-right">Sales</th>
                  <th className="py-2 px-3 font-medium text-right">Units</th>
                  <th className="py-2 px-3 font-medium text-right">Revenue</th>
                  <th className="py-2 pl-3 font-medium text-right">Realized Profit</th>
                </tr>
              </thead>
              <tbody>
                {customerPerformance.length === 0 && (
                  <tr><td colSpan={5} className="py-6 text-center text-sm text-muted-foreground">No completed customer sales recorded this week.</td></tr>
                )}
                {customerPerformance.map((c) => (
                  <tr key={c.customer_id} className="border-b last:border-0">
                    <td className="py-2 pr-3 font-medium">{c.customer_name}</td>
                    <td className="py-2 px-3 text-right text-muted-foreground">{c.sales_count}</td>
                    <td className="py-2 px-3 text-right text-muted-foreground">{Number(c.total_quantity).toLocaleString()}</td>
                    <td className="py-2 px-3 text-right">{formatGHS(c.total_spent)}</td>
                    <td className={`py-2 pl-3 text-right font-medium ${c.total_profit >= 0 ? "text-emerald-600" : "text-rose-600"}`}>{formatGHS(c.total_profit)}</td>
                  </tr>
                ))}
              </tbody>
              {customerPerformance.length > 0 && (
                <tfoot>
                  <tr className="border-t font-medium">
                    <td className="py-2 pr-3">Customer Channel</td>
                    <td className="py-2 px-3 text-right">{customerPerformance.reduce((s, c) => s + c.sales_count, 0)}</td>
                    <td className="py-2 px-3 text-right">{customerPerformance.reduce((s, c) => s + c.total_quantity, 0).toLocaleString()}</td>
                    <td className="py-2 px-3 text-right">{formatGHS(customerPerformance.reduce((s, c) => s + c.total_spent, 0))}</td>
                    <td className={`py-2 pl-3 text-right ${customerProfit >= 0 ? "text-emerald-600" : "text-rose-600"}`}>{formatGHS(customerProfit)}</td>
                  </tr>
                  <tr className="font-medium text-muted-foreground">
                    <td className="py-2 pr-3">Salesperson Channel</td>
                    <td className="py-2 px-3 text-right" colSpan={3} />
                    <td className={`py-2 pl-3 text-right ${salespersonProfit >= 0 ? "text-emerald-600" : "text-rose-600"}`}>{formatGHS(salespersonProfit)}</td>
                  </tr>
                  <tr className="border-t font-semibold">
                    <td className="py-2 pr-3">Total WTD Realized Profit</td>
                    <td className="py-2 px-3 text-right" colSpan={3} />
                    <td className={`py-2 pl-3 text-right ${wtdProfit >= 0 ? "text-emerald-600" : "text-rose-600"}`}>{formatGHS(wtdProfit)}</td>
                  </tr>
                </tfoot>
              )}
            </table>
          </div>
        </ChartCard>

        <p className="text-xs text-muted-foreground text-center">
          Real-time, derived on every change — profit & margin are never stored as fixed ledger values.
        </p>
      </div>
    </div>
  );
}