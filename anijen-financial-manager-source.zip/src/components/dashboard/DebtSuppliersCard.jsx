import { Link } from "react-router-dom";
import { formatGHS, formatDate } from "@/lib/format";
import { HandCoins, ArrowRight, Users, CheckCircle2, AlertCircle, TrendingUp } from "lucide-react";
import { totalOutstanding, totalDebtAdded, totalRepaid, supplierOutstanding } from "@/lib/suppliers";

// Dedicated Debt / Suppliers dashboard section. "Owed to Suppliers" is
// computed from the same SupplierTransaction data as the Our Debt page, so it
// always matches. Total Company Capital on the dashboard subtracts this same
// outstanding figure, so adding supplier debt reduces capital automatically.
export default function DebtSuppliersCard({ suppliers = [], transactions = [] }) {
  const outstanding = totalOutstanding(suppliers, transactions);
  const added = totalDebtAdded(transactions);
  const repaid = totalRepaid(transactions);

  const rows = suppliers
    .map((s) => ({ id: s.id, name: s.name, outstanding: supplierOutstanding(s, transactions) }))
    .sort((a, b) => b.outstanding - a.outstanding);

  const byDate = (a, b) => new Date(b.date || b.created_date) - new Date(a.date || a.created_date);
  const recentDebt = [...transactions].filter((t) => t.type === "debt").sort(byDate).slice(0, 6);
  const recentRepay = [...transactions].filter((t) => t.type === "repayment").sort(byDate).slice(0, 6);
  const supName = (id) => suppliers.find((s) => s.id === id)?.name || "—";

  return (
    <section className="rounded-2xl border bg-card shadow-sm overflow-hidden">
      <div className="px-5 py-4 border-b bg-rose-50/60 flex items-center justify-between gap-3">
        <div>
          <h2 className="font-heading text-lg font-semibold flex items-center gap-2"><HandCoins className="h-5 w-5 text-rose-500" />Debt / Suppliers</h2>
          <p className="text-xs text-muted-foreground">Currently owed to suppliers</p>
        </div>
        <div className="text-right">
          <p className="text-2xl font-heading font-bold text-rose-600">{formatGHS(outstanding)}</p>
          <Link to="/our-debt" className="text-xs text-muted-foreground hover:text-foreground flex items-center justify-end gap-1">Open section <ArrowRight className="h-3.5 w-3.5" /></Link>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 p-4 border-b">
        <Stat label="Total Supplier Debt" value={formatGHS(added)} icon={TrendingUp} tone="rose" hint="gross debt incurred" />
        <Stat label="Outstanding Supplier Debt" value={formatGHS(outstanding)} icon={AlertCircle} tone="rose" hint="currently owed" />
        <Stat label="Total Amount Repaid" value={formatGHS(repaid)} icon={CheckCircle2} tone="emerald" />
        <Stat label="Number of Suppliers" value={suppliers.length} icon={Users} tone="sky" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2">
        <div className="p-4">
          <h3 className="font-heading font-semibold text-sm mb-2">Individual Supplier Balances</h3>
          <div className="divide-y">
            {rows.length === 0 && <p className="text-sm text-muted-foreground py-3">No suppliers.</p>}
            {rows.map((r) => (
              <div key={r.id} className="flex items-center justify-between py-2 text-sm">
                <span className="font-medium truncate">{r.name}</span>
                <span className={`font-medium ${r.outstanding > 0 ? "text-rose-600" : "text-muted-foreground"}`}>{formatGHS(Math.max(0, r.outstanding))}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="p-4 lg:border-l border-border grid grid-cols-1 gap-4">
          <div>
            <h3 className="font-heading font-semibold text-sm mb-2">Recent Debt Added</h3>
            <div className="divide-y">
              {recentDebt.length === 0 && <p className="text-sm text-muted-foreground py-3">No debt recorded.</p>}
              {recentDebt.map((t) => (
                <div key={t.id} className="flex items-center justify-between gap-2 py-2 text-sm">
                  <div className="min-w-0">
                    <p className="font-medium truncate">{supName(t.supplier_id)}</p>
                    <p className="text-xs text-muted-foreground truncate">{formatDate(t.date || t.created_date)}{t.description ? ` · ${t.description}` : ""}</p>
                  </div>
                  <span className="font-medium text-rose-600 shrink-0">+{formatGHS(t.amount)}</span>
                </div>
              ))}
            </div>
          </div>
          <div>
            <h3 className="font-heading font-semibold text-sm mb-2">Recent Repayments</h3>
            <div className="divide-y">
              {recentRepay.length === 0 && <p className="text-sm text-muted-foreground py-3">No repayments recorded.</p>}
              {recentRepay.map((t) => (
                <div key={t.id} className="flex items-center justify-between gap-2 py-2 text-sm">
                  <div className="min-w-0">
                    <p className="font-medium truncate">{supName(t.supplier_id)}</p>
                    <p className="text-xs text-muted-foreground truncate">{formatDate(t.date || t.created_date)}{t.payment_account_name ? ` · ${t.payment_account_name}` : ""}</p>
                  </div>
                  <span className="font-medium text-emerald-600 shrink-0">{formatGHS(t.amount)}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Stat({ label, value, icon: Icon, tone, hint }) {
  const toneMap = { rose: "bg-rose-100 text-rose-600", sky: "bg-sky-100 text-sky-600", emerald: "bg-emerald-100 text-emerald-600" };
  return (
    <div className="rounded-xl border bg-background/60 p-3">
      <div className="flex items-center justify-between">
        <p className="text-xs font-medium text-muted-foreground">{label}</p>
        <span className={`flex h-7 w-7 items-center justify-center rounded-lg ${toneMap[tone] || "bg-muted text-muted-foreground"}`}><Icon className="h-4 w-4" /></span>
      </div>
      <p className="mt-1 font-heading text-xl font-semibold">{value}</p>
      {hint && <p className="text-[10px] text-muted-foreground mt-0.5">{hint}</p>}
    </div>
  );
}