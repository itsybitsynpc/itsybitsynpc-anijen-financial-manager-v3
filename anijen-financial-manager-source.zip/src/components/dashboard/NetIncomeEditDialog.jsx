import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { sanitizeAmountInput } from "@/lib/money";
import { Label } from "@/components/ui/label";
import { base44 } from "@/api/base44Client";
import { formatGHS } from "@/lib/format";
import { toast } from "@/components/ui/use-toast";

// Manual override for the all-time Net Profit figure (informational only).
// Use only to fix a mistake: the corrected value replaces the auto-calculated
// net profit shown on the Dashboard. Profit is a derived, read-only metric —
// it NEVER feeds into Total Company Capital or any ledger balance. One active
// correction (latest wins).
export default function NetIncomeEditDialog({ open, onClose, currentValue, autoValue, correctionId, onSaved }) {
  const [amount, setAmount] = useState("");
  const [note, setNote] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (open) {
      setAmount(String(currentValue ?? ""));
      setNote("");
    }
  }, [open, currentValue]);

  const handleSave = async () => {
    const num = Number(amount);
    if (!Number.isFinite(num)) {
      toast({ title: "Enter a valid amount", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      const payload = { amount: num, note, date: new Date().toISOString() };
      if (correctionId) {
        await base44.entities.NetIncomeCorrection.update(correctionId, payload);
      } else {
        await base44.entities.NetIncomeCorrection.create(payload);
      }
      toast({ title: "Net profit corrected", description: "The informational Net Profit figure now shows the corrected value." });
      onSaved?.();
      onClose();
    } catch (e) {
      toast({ title: "Could not save correction", description: e.message, variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  const handleClear = async () => {
    setSaving(true);
    try {
      if (correctionId) await base44.entities.NetIncomeCorrection.delete(correctionId);
      toast({ title: "Correction cleared", description: "Using the auto-calculated net income again." });
      onSaved?.();
      onClose();
    } catch (e) {
      toast({ title: "Could not clear correction", description: e.message, variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Edit Net Income (Correction)</DialogTitle>
          <DialogDescription>
            Use this only to fix a mistake. The corrected value replaces the auto-calculated net profit shown on the dashboard. This is an informational metric only — it does not affect Total Company Capital or any ledger balance.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-3 py-2">
          <div className="rounded-md bg-muted/50 px-3 py-2 text-sm text-muted-foreground">
            Auto-calculated: <span className="font-medium text-foreground">{formatGHS(autoValue)}</span>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="ni-amount">Corrected Net Income (GHS)</Label>
            <Input id="ni-amount" type="number" step="0.01" value={amount} onChange={(e) => setAmount(sanitizeAmountInput(e.target.value))} />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="ni-note">Reason for correction (optional)</Label>
            <Input id="ni-note" value={note} onChange={(e) => setNote(e.target.value)} placeholder="e.g. missing entry adjusted" />
          </div>
        </div>

        <DialogFooter className="gap-2 sm:gap-2">
          {correctionId && (
            <Button variant="ghost" onClick={handleClear} disabled={saving} className="mr-auto text-destructive">
              Clear correction
            </Button>
          )}
          <Button variant="outline" onClick={onClose} disabled={saving}>Cancel</Button>
          <Button onClick={handleSave} disabled={saving}>{saving ? "Saving…" : "Save correction"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}