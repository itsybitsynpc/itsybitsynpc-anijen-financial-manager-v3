import { useEffect, useState } from "react";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { base44 } from "@/api/base44Client";
import { formatGHS } from "@/lib/format";
import { computeCustomerBalance } from "@/lib/finance";
import { sanitizeAmountInput } from "@/lib/money";
import { useToast } from "@/components/ui/use-toast";

// Lets an admin/owner tweak customer opening (previous) balances directly from
// the Dashboard. Current balance is computed live from previous_balance + the
// customer's transactions; only previous_balance is persisted.
export default function CustomerBalancesEditDialog({ open, onClose, customers, transactions, onSaved }) {
  const [drafts, setDrafts] = useState({}); // { [customerId]: string }
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    if (open) {
      const map = {};
      customers.forEach((c) => { map[c.id] = c.previous_balance != null ? String(c.previous_balance) : ""; });
      setDrafts(map);
    }
  }, [open, customers]);

  const handleChange = (id, value) => setDrafts((d) => ({ ...d, [id]: sanitizeAmountInput(value) }));

  const dirty = customers.filter((c) => {
    const orig = c.previous_balance != null ? String(c.previous_balance) : "";
    return (drafts[c.id] ?? "") !== orig && drafts[c.id] !== undefined;
  });

  const handleSave = async () => {
    const updates = dirty.map((c) => ({ id: c.id, previous_balance: Number(drafts[c.id]) || 0 }));
    if (!updates.length) { onClose?.(); return; }
    setSaving(true);
    try {
      await base44.entities.Customer.bulkUpdate(updates);
      toast({ title: "Customer balances updated", description: `${updates.length} customer${updates.length === 1 ? "" : "s"} saved.` });
      await onSaved?.();
      onClose?.();
    } catch (error) {
      toast({ title: "Failed to save", description: error?.message || "Please try again.", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  const sorted = [...customers].sort((a, b) => a.name?.localeCompare(b.name || "") || 0);

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose?.()}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Edit Customer Balances</DialogTitle>
          <DialogDescription>
            Adjust each customer's opening (previous) balance. Current balance updates live from transactions.
          </DialogDescription>
        </DialogHeader>
        <ScrollArea className="max-h-[60vh] -mx-2 pr-2">
          <div className="divide-y">
            {sorted.length === 0 && (
              <div className="px-2 py-6 text-center text-sm text-muted-foreground">No customers yet.</div>
            )}
            {sorted.map((c) => {
              const current = computeCustomerBalance(c, transactions || []);
              return (
                <div key={c.id} className="grid grid-cols-12 items-center gap-2 px-2 py-2.5 text-sm">
                  <div className="col-span-5 font-medium truncate" title={c.name}>{c.name}</div>
                  <div className="col-span-3 text-right text-xs text-muted-foreground">
                    <span className="block">Current</span>
                    <span className={`font-medium ${current > 0 ? "text-amber-700" : current < 0 ? "text-emerald-700" : "text-foreground"}`}>{formatGHS(current)}</span>
                  </div>
                  <div className="col-span-4">
                    <Input
                      type="number"
                      step="0.01"
                      value={drafts[c.id] ?? ""}
                      onChange={(e) => handleChange(c.id, e.target.value)}
                      placeholder="0.00"
                      className="h-8 text-right"
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </ScrollArea>
        <DialogFooter className="justify-between sm:justify-between">
          <span className="text-xs text-muted-foreground">
            {dirty.length ? `${dirty.length} unsaved change${dirty.length === 1 ? "" : "s"}` : "No changes"}
          </span>
          <div className="flex gap-2">
            <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
            <Button type="button" onClick={handleSave} disabled={saving || dirty.length === 0}>
              {saving ? "Saving…" : "Save changes"}
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}