import { useMemo } from "react";
import { BarChart, Bar, XAxis, YAxis, Cell, ResponsiveContainer, Tooltip, CartesianGrid } from "recharts";
import { Tags } from "lucide-react";
import { formatGHS } from "@/lib/format";

const PALETTE = ["#f43f5e", "#f59e0b", "#0ea5e9", "#10b981", "#8b5cf6", "#ec4899", "#14b8a6", "#6366f1", "#a3a3a3"];

export default function ExpenseCategoryBreakdown({ expenses, periodLabel }) {
  const data = useMemo(() => {
    const map = new Map();
    for (const e of expenses) {
      const cat = (e.category || "").trim() || "Uncategorized";
      map.set(cat, (map.get(cat) || 0) + Number(e.amount || 0));
    }
    return [...map.entries()]
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value)
      // BarChart renders bottom-to-top, so reverse to show largest on top
      .reverse();
  }, [expenses]);

  const total = data.reduce((s, d) => s + d.value, 0);
  const maxVal = data.reduce((m, d) => Math.max(m, d.value), 0);

  return (
    <div className="rounded-xl border bg-card shadow-sm">
      <div className="flex items-center justify-between px-4 py-3 border-b">
        <div className="flex items-center gap-2">
          <Tags className="h-4 w-4 text-muted-foreground" />
          <h2 className="font-heading font-semibold">Expense Breakdown by Category</h2>
        </div>
        <span className="text-xs text-muted-foreground">{periodLabel}</span>
      </div>

      {data.length === 0 ? (
        <div className="px-4 py-10 text-center text-sm text-muted-foreground">No expenses in this period.</div>
      ) : (
        <div className="p-4">
          <p className="mb-3 text-sm text-muted-foreground">
            Total spent: <span className="font-semibold text-foreground">{formatGHS(total)}</span>
          </p>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data} layout="vertical" margin={{ top: 4, right: 16, bottom: 4, left: 8 }}>
                <CartesianGrid horizontal={false} stroke="hsl(var(--border))" strokeDasharray="3 3" />
                <XAxis
                  type="number"
                  tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }}
                  tickFormatter={(v) => formatGHS(v).replace(/\.\d+/, "")}
                  domain={[0, Math.ceil(maxVal * 1.1)]}
                />
                <YAxis
                  type="category"
                  dataKey="name"
                  width={120}
                  tick={{ fontSize: 12, fill: "hsl(var(--foreground))" }}
                  tickLine={false}
                  axisLine={false}
                />
                <Tooltip
                  cursor={{ fill: "hsl(var(--muted))", opacity: 0.4 }}
                  formatter={(v) => [formatGHS(v), "Amount"]}
                  contentStyle={{ borderRadius: 8, border: "1px solid hsl(var(--border))", fontSize: 12 }}
                />
                <Bar dataKey="value" radius={[0, 6, 6, 0]} maxBarSize={36}>
                  {data.map((_, i) => (
                    <Cell key={i} fill={PALETTE[(data.length - 1 - i) % PALETTE.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}
    </div>
  );
}