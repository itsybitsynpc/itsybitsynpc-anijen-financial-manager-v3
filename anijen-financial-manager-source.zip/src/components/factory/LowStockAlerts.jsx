import { AlertTriangle } from "lucide-react";
import { lowStockProducts, availableStock } from "@/lib/finance";

export default function LowStockAlerts({ products }) {
  const low = lowStockProducts(products);
  if (low.length === 0) return null;
  return (
    <div className="rounded-xl border border-rose-200 bg-rose-50 shadow-sm">
      <div className="flex items-center gap-2 px-4 py-3 border-b border-rose-200">
        <AlertTriangle className="h-4 w-4 text-rose-600" />
        <h2 className="font-heading font-semibold text-rose-700">Low Stock Alerts</h2>
        <span className="ml-auto rounded-full bg-rose-600 text-white text-xs font-medium px-2 py-0.5">{low.length}</span>
      </div>
      <div className="divide-y divide-rose-100">
        {low.map((p) => (
          <div key={p.id} className="flex items-center justify-between px-4 py-2.5 text-sm">
            <div>
              <p className="font-medium text-rose-900">{p.name}</p>
              <p className="text-xs text-rose-700">Threshold: {Number(p.low_stock_threshold).toLocaleString()} cartons</p>
            </div>
            <span className="rounded-lg bg-rose-600 text-white px-2.5 py-1 text-xs font-semibold">
              {availableStock(p).toLocaleString()} available
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}