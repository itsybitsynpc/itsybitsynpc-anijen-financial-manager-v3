import { formatGHS } from "@/lib/format";
import { damagedQty } from "@/lib/finance";
import { AlertTriangle } from "lucide-react";

// Shows the cost of damaged stock per product and the total. This total is
// automatically rolled into total expenses (see computeProfitBreakdown), so it
// reduces net profit / capital without a separate expense entry.
export default function DamageExpensesCard({ products = [] }) {
  const rows = (products || [])
    .map((p) => {
      const qty = damagedQty(p);
      const cost = Number(p.default_cost_price || 0);
      return { id: p.id, name: p.name, qty, unitCost: cost, total: qty * cost };
    })
    .filter((r) => r.qty > 0)
    .sort((a, b) => b.total - a.total);
  const total = rows.reduce((s, r) => s + r.total, 0);

  return (
    <div className="rounded-xl border bg-card shadow-sm overflow-hidden">
      <h2 className="font-heading font-semibold px-4 py-3 border-b flex items-center gap-2">
        <AlertTriangle className="h-4 w-4 text-rose-500" />Damage Expenses
        <span className="ml-auto text-xs font-normal text-muted-foreground">auto-added to total expenses</span>
      </h2>
      {rows.length === 0 ? (
        <div className="px-4 py-6 text-center text-sm text-muted-foreground">No damaged products recorded. Set damaged cartons on a product to log a loss.</div>
      ) : (
        <>
          <div className="sticky-header grid grid-cols-12 gap-2 px-4 py-2.5 text-xs font-semibold text-muted-foreground">
            <div className="col-span-5">Product</div>
            <div className="col-span-3 text-right">Damaged (Cartons)</div>
            <div className="col-span-2 text-right">Cost / Unit</div>
            <div className="col-span-2 text-right">Damage Cost</div>
          </div>
          <div className="divide-y">
            {rows.map((r) => (
              <div key={r.id} className="grid grid-cols-12 gap-2 px-4 py-2.5 text-sm items-center">
                <div className="col-span-5 font-medium truncate">{r.name}</div>
                <div className="col-span-3 text-right">{r.qty.toLocaleString()}</div>
                <div className="col-span-2 text-right text-muted-foreground">{formatGHS(r.unitCost).replace("GHS ", "")}</div>
                <div className="col-span-2 text-right font-medium text-rose-600">{formatGHS(r.total)}</div>
              </div>
            ))}
            <div className="flex items-center justify-between px-4 py-3 bg-muted/40">
              <span className="font-heading font-semibold">Total Damage Expenses</span>
              <span className="font-heading font-semibold text-rose-600">{formatGHS(total)}</span>
            </div>
          </div>
        </>
      )}
    </div>
  );
}