import { useState } from "react";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { sanitizeAmountInput } from "@/lib/money";
import { Label } from "@/components/ui/label";
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
} from "@/components/ui/select";
import { base44 } from "@/api/base44Client";
import { useProducts } from "@/hooks/useProducts";
import { formatGHS } from "@/lib/format";

export default function PayableEstimatorDialog({ open, onClose, onRefresh }) {
  const { data: products = [] } = useProducts();
  const [productId, setProductId] = useState("");
  const [qty, setQty] = useState("");
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState("");

  const product = products.find((p) => p.id === productId);
  const costPrice = Number(product?.default_cost_price || 0);
  const transportRate = Number(product?.transport_rate_per_unit || 0);
  const q = Number(qty) || 0;
  const baseCost = q * costPrice;
  const transportCost = q * transportRate;
  const netPayable = Math.max(0, baseCost - transportCost);

  const reset = () => { setProductId(""); setQty(""); setErr(""); };

  const handleLogTransport = async () => {
    if (!product || q <= 0 || transportCost <= 0) return;
    setSaving(true); setErr("");
    try {
      await base44.entities.Expense.create({
        item: `Transport: ${product.name} (${q} cartons)`,
        amount: transportCost,
        category: "Transport",
        payment_method: "",
        notes: `Auto-logged from Factory estimator · ${formatGHS(transportRate).replace("GHS ", "")}/carton`,
        date: new Date().toISOString(),
      });
      reset();
      onRefresh?.();
      onClose?.();
    } catch (error) {
      setErr(error?.message || "Failed to log transport expense");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && (reset(), onClose?.())}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Estimate Factory Payable & Transport</DialogTitle>
          <DialogDescription>Calculate base cost, transport and net payable for an order.</DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label>Product Brand</Label>
            <Select value={productId} onValueChange={setProductId}>
              <SelectTrigger><SelectValue placeholder="Select product" /></SelectTrigger>
              <SelectContent>
                {products.map((p) => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Quantity (Cartons)</Label>
            <Input type="number" min="0" step="0.01" value={qty} onChange={(e) => setQty(sanitizeAmountInput(e.target.value))} />
          </div>
          {product && (
            <div className="rounded-lg border bg-muted/40 p-3 space-y-1.5 text-sm">
              <Row label="Cost / Unit" value={formatGHS(costPrice)} />
              <Row label="Transport Rate / Unit" value={formatGHS(transportRate)} />
              <div className="border-t my-1" />
              <Row label="Base Factory Cost" value={formatGHS(baseCost)} bold />
              <Row label="Total Transport Cost" value={formatGHS(transportCost)} bold />
              <Row label="Net Payable Amount" value={formatGHS(netPayable)} bold highlight />
            </div>
          )}
          {err && <p className="text-sm text-destructive">{err}</p>}
          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>Close</Button>
            <Button type="button" disabled={saving || !product || q <= 0 || transportCost <= 0} onClick={handleLogTransport}>
              {saving ? "Logging…" : "Log Transport to Expenses"}
            </Button>
          </DialogFooter>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function Row({ label, value, bold, highlight }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-muted-foreground">{label}</span>
      <span className={highlight ? "font-heading font-bold text-primary" : bold ? "font-semibold" : ""}>{value}</span>
    </div>
  );
}