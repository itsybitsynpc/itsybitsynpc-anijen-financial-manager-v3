import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Trash2 } from "lucide-react";
import { sanitizeAmountInput } from "@/lib/money";
import ProductPicker from "@/components/ProductPicker";
import { formatGHS } from "@/lib/format";

// One product line inside a batch stock intake.
export default function StockIntakeRow({ row, index, onProductChange, onChange, onRemove, canRemove }) {
  const cartons = Number(row.cartons) || 0;
  const damaged = Number(row.damaged) || 0;
  const cost = Number(row.costPerCarton) || 0;
  const available = Math.max(0, cartons - damaged);

  return (
    <div className="rounded-lg border p-3 space-y-3 bg-muted/20">
      <div className="flex items-start gap-2">
        <div className="flex-1 space-y-1.5">
          <Label className="text-xs text-muted-foreground">Product {index + 1}</Label>
          <ProductPicker value={row.productId} onChange={onProductChange} />
        </div>
        {canRemove && (
          <Button
            type="button"
            variant="ghost"
            size="icon"
            className="mt-5 text-muted-foreground hover:text-destructive"
            onClick={onRemove}
            title="Remove this product"
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        )}
      </div>

      <div className="grid grid-cols-3 gap-3">
        <div className="space-y-1.5">
          <Label className="text-xs text-muted-foreground">Cartons Received</Label>
          <Input
            type="number"
            min="0"
            step="0.01"
            inputMode="decimal"
            value={row.cartons}
            onChange={(e) => onChange({ cartons: sanitizeAmountInput(e.target.value) })}
          />
        </div>
        <div className="space-y-1.5">
          <Label className="text-xs text-muted-foreground">Damaged Cartons</Label>
          <Input
            type="number"
            min="0"
            step="0.01"
            inputMode="decimal"
            value={row.damaged}
            onChange={(e) => onChange({ damaged: sanitizeAmountInput(e.target.value) })}
            className={damaged > 0 ? "border-rose-300 text-rose-700" : ""}
          />
        </div>
        <div className="space-y-1.5">
          <Label className="text-xs text-muted-foreground">Cost / Carton (GHS)</Label>
          <Input
            type="number"
            min="0"
            step="0.01"
            inputMode="decimal"
            value={row.costPerCarton}
            onChange={(e) => onChange({ costPerCarton: sanitizeAmountInput(e.target.value) })}
          />
        </div>
      </div>

      <div className="flex items-center justify-between text-xs text-muted-foreground">
        <span>
          Net stock added:{" "}
          <b className={available > 0 ? "text-emerald-700" : "text-rose-600"}>{available.toLocaleString()} cartons</b>
          {damaged > 0 && <span className="text-rose-600"> ({cartons.toLocaleString()} − {damaged.toLocaleString()} damaged)</span>}
        </span>
        <span>
          Line total: <b className="text-foreground">{formatGHS(cartons * cost)}</b>
        </span>
      </div>
    </div>
  );
}