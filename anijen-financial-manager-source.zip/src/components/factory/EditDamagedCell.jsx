import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { sanitizeAmountInput, nonNegative } from "@/lib/money";
import { damagedQty } from "@/lib/finance";
import { Pencil, Check, X } from "lucide-react";

// Inline editor for a product's damaged quantity (mirrors EditStockCell).
// Damaged cartons are deducted from the stored total stock, so raising this
// figure lowers the total immediately in one write.
export default function EditDamagedCell({ product, onSaved }) {
  const [editing, setEditing] = useState(false);
  const [value, setValue] = useState("");
  const [saving, setSaving] = useState(false);

  const start = () => {
    setValue(String(damagedQty(product)));
    setEditing(true);
  };

  const save = async () => {
    const n = Number(value);
    if (Number.isNaN(n) || n < 0) return;
    // Only the difference comes out of stock, so correcting a mistake adds back.
    const nextStock = Math.max(0, nonNegative(product.factory_stock_cartons) - (n - damagedQty(product)));
    setSaving(true);
    try {
      await base44.entities.Product.update(product.id, {
        damaged_quantity: n,
        factory_stock_cartons: nextStock,
      });
      await onSaved?.();
      setEditing(false);
    } finally {
      setSaving(false);
    }
  };

  if (!editing) {
    const damaged = damagedQty(product);
    return (
      <div className="col-span-2 flex justify-end items-center gap-1">
        <span className={`text-right font-medium ${damaged > 0 ? "text-rose-600" : "text-muted-foreground"}`}>{damaged.toLocaleString()}</span>
        <Button variant="ghost" size="icon" className="h-6 w-6" onClick={start} title="Edit damaged cartons">
          <Pencil className="h-3 w-3" />
        </Button>
      </div>
    );
  }

  return (
    <div className="col-span-2 flex justify-end items-center gap-1">
      <Input
        type="number"
        min="0"
        step="0.01"
        value={value}
        onChange={(e) => setValue(sanitizeAmountInput(e.target.value))}
        className="w-20 h-7 text-right"
        disabled={saving}
        autoFocus
        title={`Total stock after saving: ${Math.max(0, Number(product.factory_stock_cartons || 0) - ((Number(value) || 0) - damagedQty(product))).toLocaleString()} cartons`}
        onKeyDown={(e) => { if (e.key === "Enter") save(); if (e.key === "Escape") setEditing(false); }}
      />
      <Button variant="ghost" size="icon" className="h-6 w-6 text-emerald-600" onClick={save} disabled={saving} title="Save"><Check className="h-3.5 w-3.5" /></Button>
      <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => setEditing(false)} disabled={saving} title="Cancel"><X className="h-3.5 w-3.5" /></Button>
    </div>
  );
}