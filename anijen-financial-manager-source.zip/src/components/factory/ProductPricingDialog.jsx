import { useEffect, useState } from "react";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { sanitizeAmountInput } from "@/lib/money";
import { Label } from "@/components/ui/label";
import { base44 } from "@/api/base44Client";
import { useInvalidateProducts } from "@/hooks/useProducts";
import { formatGHS } from "@/lib/format";

export default function ProductPricingDialog({ open, onClose, product }) {
  const invalidate = useInvalidateProducts();
  const [name, setName] = useState("");
  const [cost, setCost] = useState("");
  const [sell, setSell] = useState("");
  const [transport, setTransport] = useState("");
  const [threshold, setThreshold] = useState("");
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState("");

  useEffect(() => {
    if (open && product) {
      setName(product.name || "");
      setCost(String(product.default_cost_price ?? ""));
      setSell(String(product.default_selling_price ?? ""));
      setTransport(String(product.transport_rate_per_unit ?? ""));
      setThreshold(String(product.low_stock_threshold ?? ""));
      setErr("");
    }
  }, [open, product]);

  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true); setErr("");
    try {
      await base44.entities.Product.update(product.id, {
        name: name.trim(),
        default_cost_price: Number(cost) || 0,
        default_selling_price: Number(sell) || 0,
        transport_rate_per_unit: Number(transport) || 0,
        low_stock_threshold: Number(threshold) || 0,
      });
      await invalidate();
      onClose?.();
    } catch (error) {
      setErr(error?.message || "Failed to update");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose?.()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Edit Product</DialogTitle>
          <DialogDescription>Update product name and factory default pricing.</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSave} className="space-y-4">
          <div className="space-y-2">
            <Label>Product Name</Label>
            <Input value={name} onChange={(e) => setName(e.target.value)} required autoFocus />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>Cost / Unit (GHS)</Label>
              <Input type="number" min="0" step="0.01" value={cost} onChange={(e) => setCost(sanitizeAmountInput(e.target.value))} />
            </div>
            <div className="space-y-2">
              <Label>Sell / Unit (GHS)</Label>
              <Input type="number" min="0" step="0.01" value={sell} onChange={(e) => setSell(sanitizeAmountInput(e.target.value))} />
            </div>
          </div>
          {(() => {
            const c = Number(cost) || 0;
            const s = Number(sell) || 0;
            if (s <= 0) return null;
            const margin = s - c;
            const pct = (margin / s) * 100;
            return (
              <div className="rounded-md bg-muted/50 px-3 py-2 text-xs text-muted-foreground flex flex-wrap items-center justify-between gap-1">
                <span>Projected Margin / Unit (informational):</span>
                <span className={`font-medium ${margin >= 0 ? "text-emerald-700" : "text-rose-700"}`}>
                  {formatGHS(margin)} · {pct.toFixed(1)}%
                </span>
              </div>
            );
          })()}
          <div className="space-y-2">
            <Label>Transport Rate / Unit (GHS)</Label>
            <Input type="number" min="0" step="0.01" value={transport} onChange={(e) => setTransport(sanitizeAmountInput(e.target.value))} placeholder="e.g. 1.57" />
          </div>
          <div className="space-y-2">
            <Label>Low Stock Alert Threshold (Cartons)</Label>
            <Input type="number" min="0" step="1" value={threshold} onChange={(e) => setThreshold(sanitizeAmountInput(e.target.value))} placeholder="e.g. 5" />
            <p className="text-xs text-muted-foreground">Alert when stock falls to or below this level.</p>
          </div>
          {err && <p className="text-sm text-destructive">{err}</p>}
          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
            <Button type="submit" disabled={saving}>{saving ? "Saving…" : "Save"}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}