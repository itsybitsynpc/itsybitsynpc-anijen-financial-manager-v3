import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { sanitizeAmountInput } from "@/lib/money";
import { Pencil, Check, X, AlertTriangle } from "lucide-react";
import { isLowStock } from "@/lib/finance";

export default function EditStockCell({ product, onSaved }) {
  const [editing, setEditing] = useState(false);
  const [value, setValue] = useState("");
  const [saving, setSaving] = useState(false);

  const start = () => {
    setValue(String(product.factory_stock_cartons ?? 0));
    setEditing(true);
  };

  const save = async () => {
    const n = Number(value);
    if (Number.isNaN(n)) return;
    setSaving(true);
    try {
      await base44.entities.Product.update(product.id, { factory_stock_cartons: n });
      await onSaved?.();
      setEditing(false);
    } finally {
      setSaving(false);
    }
  };

  if (!editing) {
    const stock = Number(product.factory_stock_cartons || 0);
    const low = isLowStock(product);
    return (
      <div className="col-span-2 flex justify-end items-center gap-1">
        <span className={`text-right font-medium ${stock < 0 || low ? "text-rose-600" : ""}`}>{stock.toLocaleString()}</span>
        {low && <AlertTriangle className="h-3.5 w-3.5 text-rose-500" title="Low stock" />}
        <Button variant="ghost" size="icon" className="h-6 w-6" onClick={start} title="Edit stock">
          <Pencil className="h-3 w-3" />
        </Button>
      </div>
    );
  }

  return (
    <div className="col-span-2 flex justify-end items-center gap-1">
      <Input
        type="number"
        value={value}
        onChange={(e) => setValue(sanitizeAmountInput(e.target.value))}
        className="w-24 h-7 text-right"
        disabled={saving}
        autoFocus
        onKeyDown={(e) => { if (e.key === "Enter") save(); if (e.key === "Escape") setEditing(false); }}
      />
      <Button variant="ghost" size="icon" className="h-6 w-6 text-emerald-600" onClick={save} disabled={saving} title="Save"><Check className="h-3.5 w-3.5" /></Button>
      <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => setEditing(false)} disabled={saving} title="Cancel"><X className="h-3.5 w-3.5" /></Button>
    </div>
  );
}