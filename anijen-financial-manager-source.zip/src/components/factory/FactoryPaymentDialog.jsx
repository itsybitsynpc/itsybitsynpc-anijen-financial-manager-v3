import { useState } from "react";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { sanitizeAmountInput } from "@/lib/money";
import { Label } from "@/components/ui/label";
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
} from "@/components/ui/select";
import { base44 } from "@/api/base44Client";
import { PAYMENT_METHODS } from "@/lib/format";

export default function FactoryPaymentDialog({ open, onClose, onRefresh }) {
  const [amount, setAmount] = useState("");
  const [method, setMethod] = useState("");
  const [desc, setDesc] = useState("");
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState("");

  const reset = () => { setAmount(""); setMethod(""); setDesc(""); setErr(""); };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true); setErr("");
    try {
      await base44.entities.FactoryPayment.create({
        amount: Number(amount) || 0,
        payment_method: method,
        description: desc,
        date: new Date().toISOString(),
      });
      reset();
      onRefresh?.();
      onClose?.();
    } catch (error) {
      setErr(error?.message || "Failed to record payment");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && (reset(), onClose?.())}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Factory Payment</DialogTitle>
          <DialogDescription>Record a payment / cost deducted from working capital.</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label>Amount (GHS)</Label>
            <Input type="number" min="0" step="0.01" value={amount} onChange={(e) => setAmount(sanitizeAmountInput(e.target.value))} required />
          </div>
          <div className="space-y-2">
            <Label>Payment Method</Label>
            <Select value={method} onValueChange={setMethod}>
              <SelectTrigger><SelectValue placeholder="Select method" /></SelectTrigger>
              <SelectContent>
                {PAYMENT_METHODS.map((m) => <SelectItem key={m} value={m}>{m}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Description (optional)</Label>
            <Input value={desc} onChange={(e) => setDesc(e.target.value)} placeholder="e.g. supplier payment, transport" />
          </div>
          {err && <p className="text-sm text-destructive">{err}</p>}
          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
            <Button type="submit" disabled={saving}>{saving ? "Saving…" : "Record Payment"}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}