import { useRef, useState } from "react";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Plus } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useProducts, useInvalidateProducts } from "@/hooks/useProducts";
import StockIntakeRow from "@/components/factory/StockIntakeRow";
import { formatGHS } from "@/lib/format";

const blankRow = (key) => ({ key, productId: "", cartons: "", damaged: "", costPerCarton: "" });

export default function StockIntakeDialog({ open, onClose, onRefresh }) {
  const { data: products = [] } = useProducts();
  const invalidate = useInvalidateProducts();
  const seq = useRef(1);
  const [rows, setRows] = useState(() => [blankRow(0)]);
  const [desc, setDesc] = useState("");
  const [logTransport, setLogTransport] = useState(false);
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState("");

  const reset = () => {
    seq.current = 1;
    setRows([blankRow(0)]);
    setDesc("");
    setLogTransport(false);
    setErr("");
  };

  const addRow = () => setRows((prev) => [...prev, blankRow(seq.current++)]);
  const removeRow = (key) => setRows((prev) => prev.filter((r) => r.key !== key));

  const updateRow = (key, patch) =>
    setRows((prev) => prev.map((r) => (r.key === key ? { ...r, ...patch } : r)));

  const handleProductChange = (key, productId, product) =>
    setRows((prev) =>
      prev.map((r) =>
        r.key === key
          ? {
              ...r,
              productId,
              costPerCarton:
                product && !Number(r.costPerCarton) ? String(product.default_cost_price ?? "") : r.costPerCarton,
            }
          : r,
      ),
    );

  const filled = rows.filter((r) => r.productId && Number(r.cartons) > 0);
  const total = filled.reduce((s, r) => s + Number(r.cartons) * Number(r.costPerCarton || 0), 0);
  const receivedCartons = filled.reduce((s, r) => s + (Number(r.cartons) || 0), 0);
  const damagedCartons = filled.reduce((s, r) => s + (Number(r.damaged) || 0), 0);
  const transportTotal = filled.reduce((s, r) => {
    const p = products.find((x) => x.id === r.productId);
    return s + Number(r.cartons) * Number(p?.transport_rate_per_unit || 0);
  }, 0);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setErr("");
    if (!filled.length) {
      setErr("Choose at least one product and enter the cartons received.");
      return;
    }
    const ids = filled.map((r) => r.productId);
    if (new Set(ids).size !== ids.length) {
      setErr("Each product can only appear once — remove the duplicate row.");
      return;
    }
    const overDamaged = filled.find((r) => (Number(r.damaged) || 0) > (Number(r.cartons) || 0));
    if (overDamaged) {
      const name = products.find((p) => p.id === overDamaged.productId)?.name || "a product";
      setErr(`Damaged cartons for ${name} cannot be more than the cartons received.`);
      return;
    }
    setSaving(true);
    try {
      await base44.functions.invoke("recordFactoryIntake", {
        items: filled.map((r) => ({
          product_id: r.productId,
          cartons: Number(r.cartons) || 0,
          damaged_cartons: Number(r.damaged) || 0,
          cost_per_carton: Number(r.costPerCarton) || 0,
        })),
        description: desc,
        logTransport: logTransport && transportTotal > 0,
      });
      await invalidate();
      reset();
      onRefresh?.();
      onClose?.();
    } catch (error) {
      setErr(
        error?.response?.data?.error || error?.message || "Failed to record this stock intake.",
      );
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && (reset(), onClose?.())}>
      <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Factory Stock Intake</DialogTitle>
          <DialogDescription>
            Add one or more products in a single batch. Stock is added to inventory for every product at once.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-3">
            {rows.map((row, i) => (
              <StockIntakeRow
                key={row.key}
                row={row}
                index={i}
                canRemove={rows.length > 1}
                onProductChange={(id, p) => handleProductChange(row.key, id, p)}
                onChange={(patch) => updateRow(row.key, patch)}
                onRemove={() => removeRow(row.key)}
              />
            ))}
            <Button type="button" variant="outline" size="sm" className="w-full" onClick={addRow}>
              <Plus className="h-4 w-4" /> Add another product
            </Button>
          </div>

          <div className="space-y-2">
            <Label>Description (optional)</Label>
            <Input value={desc} onChange={(e) => setDesc(e.target.value)} placeholder="e.g. Factory delivery — November" />
          </div>

          {transportTotal > 0 && (
            <div className="flex items-center space-x-2 rounded-md border p-2.5">
              <Checkbox id="log-transport" checked={logTransport} onCheckedChange={(v) => setLogTransport(!!v)} />
              <Label htmlFor="log-transport" className="text-sm font-normal cursor-pointer">
                Log transport to expenses ({formatGHS(transportTotal)})
              </Label>
            </div>
          )}

          <div className="flex items-center justify-between rounded-md bg-muted/40 px-3 py-2 text-sm">
            <span className="text-muted-foreground">
              {filled.length} product{filled.length === 1 ? "" : "s"} · {receivedCartons} cartons
              {damagedCartons > 0 && (
                <> · <span className="text-rose-600">{damagedCartons} damaged</span> · {(receivedCartons - damagedCartons).toLocaleString()} added to stock</>
              )}
            </span>
            <span>Intake cost: <b className="text-foreground">{formatGHS(total)}</b></span>
          </div>

          {err && <p className="text-sm text-destructive">{err}</p>}

          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
            <Button type="submit" disabled={saving || !filled.length}>
              {saving ? "Saving…" : filled.length > 1 ? `Record ${filled.length} Products` : "Record Intake"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}