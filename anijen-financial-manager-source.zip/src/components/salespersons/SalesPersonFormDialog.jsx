import { useEffect, useState } from "react";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { sanitizeAmountInput } from "@/lib/money";
import { Label } from "@/components/ui/label";

export default function SalesPersonFormDialog({ open, onClose, onSave, salesperson }) {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [prev, setPrev] = useState("");
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState("");

  useEffect(() => {
    if (open) {
      setName(salesperson?.name || "");
      setPhone(salesperson?.phone || "");
      setPrev(salesperson?.previous_balance != null ? String(salesperson.previous_balance) : "");
      setErr("");
    }
  }, [open, salesperson]);

  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true); setErr("");
    try {
      await onSave({
        name: name.trim(),
        phone: phone.trim(),
        previous_balance: Number(prev) || 0,
      });
      onClose?.();
    } catch (error) {
      setErr(error?.message || "Failed to save");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose?.()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{salesperson ? "Edit Sales Person" : "Add New Sales Person"}</DialogTitle>
          <DialogDescription>
            {salesperson
              ? "Update details and opening balance."
              : "Register a new sales person with an opening / previous balance."}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSave} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="sname">Sales Person Name</Label>
            <Input id="sname" value={name} onChange={(e) => setName(e.target.value)} required autoFocus />
          </div>
          <div className="space-y-2">
            <Label htmlFor="sphone">Phone (optional)</Label>
            <Input id="sphone" value={phone} onChange={(e) => setPhone(e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="sprev">Previous Balance (GHS)</Label>
            <Input id="sprev" type="number" min="0" step="0.01" value={prev} onChange={(e) => setPrev(sanitizeAmountInput(e.target.value))} placeholder="0.00" />
          </div>
          {err && <p className="text-sm text-destructive">{err}</p>}
          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
            <Button type="submit" disabled={saving || !name.trim()}>{saving ? "Saving…" : "Save"}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}