import { useEffect, useMemo, useState } from "react";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { nonNegative, sanitizeAmountInput } from "@/lib/money";
import { Label } from "@/components/ui/label";
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
} from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Trash2, PackagePlus, Banknote, Receipt, Download } from "lucide-react";
import { downloadCSV } from "@/lib/csv";
import { base44 } from "@/api/base44Client";
import { useProducts, useInvalidateProducts } from "@/hooks/useProducts";
import { adjustStock } from "@/lib/stock";
import { formatGHS, formatDate, PAYMENT_METHODS } from "@/lib/format";
import { transactionItemsLabel, transactionProfit } from "@/lib/finance";
import { usePassphraseGuard } from "@/hooks/useGuard";
import MultiProductSaleForm from "@/components/shared/MultiProductSaleForm";
import ReceiptModal from "@/components/shared/ReceiptModal";
import { nextReferenceNumbers } from "@/lib/reference";
import {
  ensureOutstandingBalance,
  applySaleToOutstanding,
  processDualLedgerPayment,
  reverseTransactionBalance,
} from "@/lib/paymentService";

const PAYMENT_TARGETS = [
  { value: "OUTSTANDING_BALANCE", label: "Pay Current Issued Goods / Invoice" },
  { value: "PREVIOUS_BALANCE", label: "Pay Previous Balance / Arrears" },
];

export default function SalesPersonLedgerDialog({ salesperson, open, onClose, transactions, onRefresh }) {
  const { data: products = [] } = useProducts();
  const invalidate = useInvalidateProducts();
  const { requirePassphrase, modal } = usePassphraseGuard();

  const [live, setLive] = useState(salesperson);
  const [mode, setMode] = useState(null);
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState("");

  const [cashReturned, setCashReturned] = useState("");
  const [settleMethod, setSettleMethod] = useState("");
  const [settleTarget, setSettleTarget] = useState("OUTSTANDING_BALANCE");
  const [settleDesc, setSettleDesc] = useState("");

  const [receipt, setReceipt] = useState(null);

  // Backfill outstanding_balance from history on open (lazy dual-ledger migration).
  useEffect(() => {
    if (!open || !salesperson) return;
    let cancelled = false;
    setLive(salesperson);
    (async () => {
      const e = await ensureOutstandingBalance("SALESPERSON", salesperson, transactions);
      if (!cancelled) setLive(e);
    })();
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, salesperson?.id]);

  const myTx = useMemo(
    () =>
      (transactions || [])
        .filter((t) => t.salesperson_id === salesperson?.id)
        .sort((a, b) => new Date(b.date || b.created_date) - new Date(a.date || b.created_date)),
    [transactions, salesperson]
  );

  const prevBal = Number(live?.previous_balance || 0);
  const outBal = Number(live?.outstanding_balance || 0);
  const totalDebt = prevBal + outBal;
  // Informational only — expected margin on issued goods. Never affects the
  // salesperson's outstanding balance, which stays cost-based.
  const totalProfit = myTx.filter((t) => t.type === "issue").reduce((s, t) => s + transactionProfit(t), 0);

  const resetForms = () => {
    setMode(null);
    setCashReturned(""); setSettleMethod(""); setSettleTarget("OUTSTANDING_BALANCE"); setSettleDesc("");
    setErr("");
  };

  const handleIssue = async (lines, upfront) => {
    setSaving(true); setErr("");
    try {
      const [refNum] = await nextReferenceNumbers(1);
      const total = lines.reduce((s, l) => s + Number(l.quantity_cartons) * Number(l.cost_price_per_unit), 0);
      // Cash paid at issue can never exceed the goods debt it settles.
      const paidUpfront = Math.min(Math.max(0, Number(upfront?.amount) || 0), total);
      const method = paidUpfront > 0 ? (upfront?.method || "") : "";
      const status = paidUpfront <= 0 ? "unpaid" : paidUpfront >= total ? "paid" : "partial";
      const outBefore = Number(live?.outstanding_balance || 0);
      const issue = await base44.entities.SalesPersonTransaction.create({
        salesperson_id: salesperson.id,
        salesperson_name: salesperson.name,
        type: "issue",
        reference_number: refNum,
        amount: total,
        lines: lines.map((l) => ({
          product_id: l.product_id,
          product_name: l.product_name,
          quantity_cartons: l.quantity_cartons,
          cost_price_per_unit: l.cost_price_per_unit,
          selling_price_per_unit: l.selling_price_per_unit,
        })),
        amount_paid_at_purchase: paidUpfront,
        initial_payment_method: method,
        payment_status: status,
        previous_balance_before: prevBal,
        previous_balance_after: prevBal,
        outstanding_balance_before: outBefore,
        outstanding_balance_after: outBefore + total,
        date: new Date().toISOString(),
      });
      for (const l of lines) {
        await adjustStock(l.product_id, -Number(l.quantity_cartons));
      }
      await invalidate();
      let newOut = await applySaleToOutstanding("SALESPERSON", salesperson.id, total);

      // Record the cash paid at issue as its own ledger entry (and income), so
      // the goods balance only carries what is genuinely still owed.
      if (paidUpfront > 0) {
        const snap = await processDualLedgerPayment({
          entityType: "SALESPERSON",
          entityId: salesperson.id,
          amount: paidUpfront,
          paymentTarget: "OUTSTANDING_BALANCE",
        });
        newOut = snap.outstandingBalanceAfter;
        const [payRef] = await nextReferenceNumbers(1);
        await base44.entities.SalesPersonTransaction.create({
          salesperson_id: salesperson.id,
          salesperson_name: salesperson.name,
          type: "settlement",
          reference_number: payRef,
          cash_returned: paidUpfront,
          amount: paidUpfront,
          payment_method: method,
          payment_target: "OUTSTANDING_BALANCE",
          invoice_id: issue?.id || "",
          description: `Payment at time of issue · ${refNum}`,
          previous_balance_before: snap.previousBalanceBefore,
          previous_balance_after: snap.previousBalanceAfter,
          outstanding_balance_before: snap.outstandingBalanceBefore,
          outstanding_balance_after: snap.outstandingBalanceAfter,
          date: new Date().toISOString(),
        });
        await base44.entities.IncomeLog.create({
          source: "salesperson",
          reference_id: salesperson.id,
          reference_name: salesperson.name,
          amount: paidUpfront,
          payment_method: method,
          description: `Payment at time of issue · ${refNum}`,
          date: new Date().toISOString(),
        });
      }

      setLive((p) => ({ ...p, outstanding_balance: newOut }));
      resetForms();
      onRefresh?.();
    } catch (error) {
      setErr(error?.message || "Failed to issue products");
    } finally {
      setSaving(false);
    }
  };

  const handleSettlement = async (e) => {
    e.preventDefault();
    setSaving(true); setErr("");
    try {
      const cash = Number(cashReturned) || 0;
      const snap = await processDualLedgerPayment({
        entityType: "SALESPERSON",
        entityId: salesperson.id,
        amount: cash,
        paymentTarget: settleTarget,
      });
      const [refNum] = await nextReferenceNumbers(1);
      await base44.entities.SalesPersonTransaction.create({
        salesperson_id: salesperson.id,
        salesperson_name: salesperson.name,
        type: "settlement",
        reference_number: refNum,
        cash_returned: cash,
        amount: cash,
        payment_method: settleMethod,
        payment_target: settleTarget,
        description: settleDesc,
        previous_balance_before: snap.previousBalanceBefore,
        previous_balance_after: snap.previousBalanceAfter,
        outstanding_balance_before: snap.outstandingBalanceBefore,
        outstanding_balance_after: snap.outstandingBalanceAfter,
        date: new Date().toISOString(),
      });
      await base44.entities.IncomeLog.create({
        source: "salesperson",
        reference_id: salesperson.id,
        reference_name: salesperson.name,
        amount: cash,
        payment_method: settleMethod,
        description: `Cash returned by ${salesperson.name}`,
        date: new Date().toISOString(),
      });
      setLive((p) => ({
        ...p,
        previous_balance: snap.previousBalanceAfter,
        outstanding_balance: snap.outstandingBalanceAfter,
      }));
      resetForms();
      onRefresh?.();
    } catch (error) {
      setErr(error?.message || "Failed to record settlement");
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = (t) => {
    requirePassphrase(`delete ${t.type} entry for ${salesperson?.name}`, async () => {
      await reverseTransactionBalance("SALESPERSON", salesperson.id, t);
      await base44.entities.SalesPersonTransaction.delete(t.id);
      if (t.type === "issue") {
        const lines = Array.isArray(t.lines) && t.lines.length
          ? t.lines
          : (t.product_id ? [{ product_id: t.product_id, quantity_cartons: t.quantity_cartons }] : []);
        for (const l of lines) {
          if (l.product_id && l.quantity_cartons) await adjustStock(l.product_id, Number(l.quantity_cartons) || 0);
        }
        await invalidate();
      }
      const ent = await base44.entities.SalesPerson.get(salesperson.id);
      setLive(ent);
      onRefresh?.();
    });
  };

  const handleExport = () => {
    downloadCSV(`${salesperson?.name || "salesperson"}-ledger`, [
      { label: "Date", value: (t) => formatDate(t.date || t.created_date) },
      { label: "Reference", value: (t) => t.reference_number || "" },
      { label: "Type", value: (t) => (t.type === "issue" ? "Issue" : "Settlement") },
      { label: "Details", value: (t) => (t.type === "issue" ? transactionItemsLabel(t) : (t.description || "Cash returned")) },
      { label: "Value (GHS)", value: (t) => (t.type === "issue" ? Number(t.amount || 0).toFixed(2) : Number(t.cash_returned || 0).toFixed(2)) },
      { label: "Payment Target", value: (t) => (t.type === "settlement" ? (t.payment_target || "OUTSTANDING_BALANCE") : "") },
      { label: "Prev. Before", value: (t) => (t.previous_balance_before != null ? Number(t.previous_balance_before).toFixed(2) : "") },
      { label: "Prev. After", value: (t) => (t.previous_balance_after != null ? Number(t.previous_balance_after).toFixed(2) : "") },
      { label: "Out. Before", value: (t) => (t.outstanding_balance_before != null ? Number(t.outstanding_balance_before).toFixed(2) : "") },
      { label: "Out. After", value: (t) => (t.outstanding_balance_after != null ? Number(t.outstanding_balance_after).toFixed(2) : "") },
      { label: "Profit (GHS)", value: (t) => (t.type === "issue" ? transactionProfit(t).toFixed(2) : "") },
      { label: "Payment Method", value: (t) => t.payment_method || "" },
      { label: "Description", value: (t) => t.description || "" },
    ], myTx);
  };

  const openReceipt = (t) => {
    const prevBefore = Number(t.previous_balance_before ?? prevBal);
    const outBefore = Number(t.outstanding_balance_before ?? outBal);
    const isIssue = t.type === "issue";
    const amt = isIssue ? Number(t.amount || 0) : Number(t.cash_returned || 0);
    const prevAfter = Number(t.previous_balance_after ?? prevBefore);
    const storedOutAfter = nonNegative(t.outstanding_balance_after ?? (isIssue ? outBefore + amt : Math.max(0, outBefore - amt)));
    // Cash paid at issue is already settled, so it must not show as still owed.
    const paidUpfront = isIssue ? Math.max(0, Number(t.amount_paid_at_purchase || 0)) : 0;
    const outAfter = Math.max(0, storedOutAfter - paidUpfront);
    setReceipt({
      tx: t,
      balances: { previousBefore: prevBefore, previousAfter: prevAfter, outstandingBefore: outBefore, outstandingAfter: outAfter },
    });
  };

  // Live preview of how the settlement splits across the two balances.
  const cash = Number(cashReturned) || 0;
  let appliedPrev = 0, appliedOut = 0, previewPrev = prevBal, previewOut = outBal;
  if (settleTarget === "PREVIOUS_BALANCE") {
    appliedPrev = Math.min(cash, prevBal);
    appliedOut = Math.max(0, cash - prevBal);
    previewPrev = Math.max(0, prevBal - cash);
    previewOut = Math.max(0, outBal - appliedOut);
  } else {
    appliedOut = cash;
    previewOut = Math.max(0, outBal - cash);
  }

  return (
    <Dialog open={open} onOpenChange={(o) => !o && (resetForms(), onClose?.())}>
      <DialogContent className="sm:max-w-3xl">
        <DialogHeader>
          <DialogTitle>Ledger — {salesperson?.name}</DialogTitle>
          <DialogDescription className="flex flex-wrap gap-2">
            <span className="inline-block rounded bg-rose-50 px-2 py-0.5 text-rose-800">Previous Balance: <b>{formatGHS(prevBal)}</b></span>
            <span className="inline-block rounded bg-amber-50 px-2 py-0.5 text-amber-900">Outstanding Balance: <b>{formatGHS(outBal)}</b></span>
            <span className="inline-block rounded bg-slate-100 px-2 py-0.5 text-slate-900">Total Combined Debt: <b>{formatGHS(totalDebt)}</b></span>
            <span className="inline-block rounded bg-emerald-50 px-2 py-0.5 text-emerald-800">Total Profit (info): <b>{formatGHS(totalProfit)}</b></span>
          </DialogDescription>
        </DialogHeader>

        <div className="flex gap-2">
          <Button type="button" size="sm" variant={mode === "issue" ? "default" : "outline"} onClick={() => { setMode(mode === "issue" ? null : "issue"); setErr(""); }}>
            <PackagePlus className="h-4 w-4 mr-1" /> Issue Products
          </Button>
          <Button type="button" size="sm" variant={mode === "settlement" ? "default" : "outline"} onClick={() => { setMode(mode === "settlement" ? null : "settlement"); setErr(""); }}>
            <Banknote className="h-4 w-4 mr-1" /> Record Settlement
          </Button>
          <Button type="button" size="sm" variant="outline" className="ml-auto" onClick={handleExport} disabled={myTx.length === 0}>
            <Download className="h-4 w-4 mr-1" /> Export CSV
          </Button>
        </div>

        {mode === "issue" && (
          <MultiProductSaleForm
            products={products}
            onSubmit={handleIssue}
            onCancel={() => setMode(null)}
            saving={saving}
            submitLabel="Issue Products"
            allowUpfront
            upfrontBasis="cost"
          />
        )}

        {mode === "settlement" && (
          <form onSubmit={handleSettlement} className="grid grid-cols-1 sm:grid-cols-2 gap-3 rounded-lg border p-3 bg-muted/30">
            <div className="space-y-1.5">
              <Label>Cash Returned (GHS)</Label>
              <Input type="number" min="0" step="0.01" value={cashReturned} onChange={(e) => setCashReturned(sanitizeAmountInput(e.target.value))} required />
            </div>
            <div className="space-y-1.5">
              <Label>Payment Method</Label>
              <Select value={settleMethod} onValueChange={setSettleMethod} required>
                <SelectTrigger><SelectValue placeholder="Select method" /></SelectTrigger>
                <SelectContent>
                  {PAYMENT_METHODS.map((m) => <SelectItem key={m} value={m}>{m}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="sm:col-span-2 space-y-1.5">
              <Label>Payment Target</Label>
              <Select value={settleTarget} onValueChange={setSettleTarget} required>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {PAYMENT_TARGETS.map((t) => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="sm:col-span-2 space-y-1.5">
              <Label>Description (optional)</Label>
              <Input value={settleDesc} onChange={(e) => setSettleDesc(e.target.value)} />
            </div>
            {cash > 0 && (
              <div className="sm:col-span-2 rounded-md border bg-background p-2.5 text-sm space-y-1">
                <p className="font-medium">Allocation preview</p>
                {settleTarget === "PREVIOUS_BALANCE" ? (
                  <p className="text-muted-foreground">Applied to Previous: <b className="text-rose-700">{formatGHS(appliedPrev)}</b>{appliedOut > 0 && <> · Overflow to Outstanding: <b className="text-amber-700">{formatGHS(appliedOut)}</b></>}</p>
                ) : (
                  <p className="text-muted-foreground">Applied to Outstanding: <b className="text-amber-700">{formatGHS(appliedOut)}</b></p>
                )}
                <p className="text-muted-foreground">Remaining Previous: <b className="text-rose-700">{formatGHS(previewPrev)}</b> · Remaining Outstanding: <b className="text-amber-700">{formatGHS(previewOut)}</b></p>
                <p className="text-muted-foreground">Total remaining debt: <b className="text-slate-900">{formatGHS(previewPrev + previewOut)}</b></p>
              </div>
            )}
            <div className="sm:col-span-2 flex justify-end gap-2">
              <Button type="button" variant="ghost" onClick={() => setMode(null)}>Cancel</Button>
              <Button type="submit" disabled={saving || !settleMethod}>Record Settlement</Button>
            </div>
          </form>
        )}

        {err && <p className="text-sm text-destructive">{err}</p>}

        <div className="rounded-lg border">
          <div className="sticky-header grid grid-cols-12 gap-2 px-3 py-2 text-xs font-semibold text-muted-foreground">
            <div className="col-span-2">Date</div>
            <div className="col-span-2">Type</div>
            <div className="col-span-3">Details</div>
            <div className="col-span-3 text-right">Value</div>
            <div className="col-span-2 text-right">Actions</div>
          </div>
          <ScrollArea className="max-h-64">
            {myTx.length === 0 && <div className="px-3 py-6 text-center text-sm text-muted-foreground">No activity yet.</div>}
            {myTx.map((t) => (
              <div key={t.id} className="grid grid-cols-12 gap-2 border-b px-3 py-2 text-sm last:border-0 items-center">
                <div className="col-span-2 text-xs text-muted-foreground">{formatDate(t.date || t.created_date)}</div>
                <div className="col-span-2">
                  <span className={`inline-block rounded px-1.5 py-0.5 text-xs font-medium ${t.type === "issue" ? "bg-blue-100 text-blue-700" : "bg-emerald-100 text-emerald-700"}`}>
                    {t.type === "issue" ? "Issue" : "Settlement"}
                  </span>
                  {t.type === "settlement" && t.payment_target && (
                    <span className="ml-1 text-[10px] text-muted-foreground">{t.payment_target === "PREVIOUS_BALANCE" ? "→ Prev" : "→ Curr"}</span>
                  )}
                  {t.payment_method && <span className="ml-1 text-xs text-muted-foreground">{t.payment_method}</span>}
                </div>
                <div className="col-span-3 text-xs">
                  {t.type === "issue" ? transactionItemsLabel(t) : (t.description || "Cash returned")}
                </div>
                <div className={`col-span-3 text-right font-medium ${t.type === "issue" ? "text-amber-600" : "text-emerald-600"}`}>
                  {t.type === "issue" ? `+${formatGHS(t.amount)}` : `−${formatGHS(t.cash_returned)}`}
                  {t.type === "issue" && (
                    <div className="text-[11px] font-medium text-emerald-700">Profit: {formatGHS(transactionProfit(t))}</div>
                  )}
                </div>
                <div className="col-span-2 flex justify-end gap-1">
                  <Button type="button" variant="ghost" size="icon" className="h-7 w-7" onClick={() => openReceipt(t)} title="Print receipt">
                    <Receipt className="h-3.5 w-3.5" />
                  </Button>
                  <Button type="button" variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={() => handleDelete(t)} title="Delete">
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </div>
            ))}
          </ScrollArea>
        </div>

        <ReceiptModal
          open={!!receipt}
          onClose={() => setReceipt(null)}
          party={salesperson}
          partyType="salesperson"
          transaction={receipt?.tx}
          balances={receipt?.balances}
        />
        {modal}
      </DialogContent>
    </Dialog>
  );
}