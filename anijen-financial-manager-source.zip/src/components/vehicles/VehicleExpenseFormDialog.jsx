import { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { sanitizeAmountInput } from "@/lib/money";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const TYPES = ["Fuel", "Maintenance", "Spare Parts", "Driver Allowance", "Insurance/Licensing", "Other"];
const METHODS = ["Mobile Money (MoMo)", "Bank Transfer", "Cheque", "Cash"];

function nowLocalInput() {
  const d = new Date();
  const local = new Date(d.getTime() - d.getTimezoneOffset() * 60000);
  return local.toISOString().slice(0, 16);
}
function toLocalInput(iso) {
  if (!iso) return nowLocalInput();
  const d = new Date(iso);
  const local = new Date(d.getTime() - d.getTimezoneOffset() * 60000);
  return local.toISOString().slice(0, 16);
}

export default function VehicleExpenseFormDialog({ open, onClose, onSaved, vehicle, entry }) {
  const [type, setType] = useState("Fuel");
  const [amount, setAmount] = useState("");
  const [date, setDate] = useState(nowLocalInput());
  const [mileage, setMileage] = useState("");
  const [method, setMethod] = useState("Cash");
  const [desc, setDesc] = useState("");
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState("");

  useEffect(() => {
    if (open) {
      setType(entry?.expense_type || "Fuel");
      setAmount(entry?.amount ? String(entry.amount) : "");
      setDate(toLocalInput(entry?.date));
      setMileage(entry?.mileage ? String(entry.mileage) : "");
      setMethod(entry?.payment_method || "Cash");
      setDesc(entry?.description || "");
      setErr("");
    }
  }, [open, entry]);

  const submit = async () => {
    const amt = Number(amount);
    if (!amt || amt <= 0) { setErr("Enter a valid amount."); return; }
    if (!vehicle?.id) { setErr("Vehicle missing."); return; }
    setSaving(true);
    try {
      const payload = {
        vehicle_id: vehicle.id,
        vehicle_name: vehicle.name,
        expense_type: type,
        amount: amt,
        date: new Date(date).toISOString(),
        mileage: Number(mileage) || 0,
        payment_method: method,
        description: desc.trim(),
      };
      if (entry?.id) await base44.entities.VehicleExpense.update(entry.id, payload);
      else await base44.entities.VehicleExpense.create(payload);
      onSaved?.();
      onClose();
    } catch (e) {
      setErr(e?.message || "Failed to save expense.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{entry?.id ? "Edit Vehicle Expense" : "Log Vehicle Expense"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div><Label>Vehicle</Label><Input value={vehicle?.name || ""} disabled /></div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Expense Type</Label>
              <Select value={type} onValueChange={setType}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{TYPES.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div><Label>Amount (GHS)</Label><Input type="number" value={amount} onChange={(e) => setAmount(sanitizeAmountInput(e.target.value))} /></div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div><Label>Date & Time</Label><Input type="datetime-local" value={date} onChange={(e) => setDate(e.target.value)} /></div>
            <div><Label>Mileage (optional)</Label><Input type="number" value={mileage} onChange={(e) => setMileage(sanitizeAmountInput(e.target.value))} placeholder="Odometer" /></div>
          </div>
          <div>
            <Label>Payment Method</Label>
            <Select value={method} onValueChange={setMethod}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{METHODS.map((m) => <SelectItem key={m} value={m}>{m}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div><Label>Description / Receipt Notes</Label><Textarea value={desc} onChange={(e) => setDesc(e.target.value)} rows={2} /></div>
          {err && <p className="text-xs text-destructive">{err}</p>}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={saving}>Cancel</Button>
          <Button onClick={submit} disabled={saving}>{saving ? "Saving…" : "Save"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}