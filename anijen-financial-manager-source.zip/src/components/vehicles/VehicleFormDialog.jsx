import { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

export default function VehicleFormDialog({ open, onClose, onSaved, vehicle }) {
  const [name, setName] = useState("");
  const [reg, setReg] = useState("");
  const [driver, setDriver] = useState("");
  const [notes, setNotes] = useState("");
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState("");

  useEffect(() => {
    if (open) {
      setName(vehicle?.name || "");
      setReg(vehicle?.registration_number || "");
      setDriver(vehicle?.assigned_driver || "");
      setNotes(vehicle?.notes || "");
      setErr("");
    }
  }, [open, vehicle]);

  const submit = async () => {
    if (!name.trim()) { setErr("Vehicle name is required."); return; }
    setSaving(true);
    try {
      const payload = {
        name: name.trim(),
        registration_number: reg.trim(),
        assigned_driver: driver.trim(),
        notes: notes.trim(),
      };
      if (vehicle?.id) await base44.entities.Vehicle.update(vehicle.id, payload);
      else await base44.entities.Vehicle.create(payload);
      onSaved?.();
      onClose();
    } catch (e) {
      setErr(e?.message || "Failed to save vehicle.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{vehicle?.id ? "Edit Vehicle" : "Add New Vehicle"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div><Label>Vehicle Name / Model</Label><Input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Toyota Hilux" /></div>
          <div><Label>Registration Number</Label><Input value={reg} onChange={(e) => setReg(e.target.value)} placeholder="e.g. GT-1024-26" /></div>
          <div><Label>Assigned Driver / Operations</Label><Input value={driver} onChange={(e) => setDriver(e.target.value)} /></div>
          <div><Label>Notes</Label><Textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={2} /></div>
          {err && <p className="text-xs text-destructive">{err}</p>}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={saving}>Cancel</Button>
          <Button onClick={submit} disabled={saving}>{saving ? "Saving…" : "Save"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}