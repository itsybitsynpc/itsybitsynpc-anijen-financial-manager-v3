import { useEffect, useMemo, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Trash2, Pencil, Plus } from "lucide-react";
import { formatGHS, formatDate } from "@/lib/format";
import { usePassphraseGuard } from "@/hooks/useGuard";
import VehicleExpenseFormDialog from "./VehicleExpenseFormDialog";

export default function VehicleLedgerDialog({ open, onClose, vehicle, onChanged }) {
  const [expenses, setExpenses] = useState([]);
  const [loading, setLoading] = useState(false);
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const { requirePassphrase, modal } = usePassphraseGuard();

  const load = async () => {
    if (!vehicle?.id) return;
    setLoading(true);
    try {
      const all = await base44.entities.VehicleExpense.list("-date", 2000);
      setExpenses(all.filter((e) => e.vehicle_id === vehicle.id));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { if (open) load(); }, [open, vehicle?.id]);

  const total = useMemo(() => expenses.reduce((s, e) => s + Number(e.amount || 0), 0), [expenses]);

  const handleDelete = (e) => {
    requirePassphrase(`delete ${e.expense_type} expense for ${vehicle?.name || "vehicle"}`, async () => {
      await base44.entities.VehicleExpense.delete(e.id);
      await load();
      onChanged?.();
    });
  };

  const onSaved = async () => { await load(); onChanged?.(); };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="sm:max-w-2xl">
        <DialogHeader>
          <div className="flex items-center justify-between gap-3">
            <DialogTitle>{vehicle?.name} · Expense Ledger</DialogTitle>
            <Button size="sm" onClick={() => { setEditing(null); setFormOpen(true); }}><Plus className="h-4 w-4" /> Log Expense</Button>
          </div>
        </DialogHeader>
        <div className="text-sm text-muted-foreground mb-2">
          {vehicle?.registration_number && <span>Reg: {vehicle.registration_number} · </span>}
          {vehicle?.assigned_driver && <span>Driver: {vehicle.assigned_driver} · </span>}
          <span>Total Expenses: <span className="font-semibold text-rose-600">{formatGHS(total)}</span></span>
        </div>
        <div className="max-h-[55vh] overflow-auto rounded-lg border">
          <table className="w-full text-sm">
            <thead className="sticky-header">
              <tr className="text-left text-xs text-muted-foreground">
                <th className="px-3 py-2">Date</th>
                <th className="px-3 py-2">Type</th>
                <th className="px-3 py-2 text-right">Amount</th>
                <th className="px-3 py-2">Method</th>
                <th className="px-3 py-2">Mileage</th>
                <th className="px-3 py-2">Notes</th>
                <th className="px-3 py-2 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {loading && <tr><td colSpan={7} className="px-3 py-6 text-center text-muted-foreground">Loading…</td></tr>}
              {!loading && expenses.length === 0 && (
                <tr><td colSpan={7} className="px-3 py-6 text-center text-muted-foreground">No expenses logged yet.</td></tr>
              )}
              {!loading && expenses.map((e) => (
                <tr key={e.id}>
                  <td className="px-3 py-2 whitespace-nowrap">{formatDate(e.date)}</td>
                  <td className="px-3 py-2">{e.expense_type}</td>
                  <td className="px-3 py-2 text-right font-medium text-rose-600">{formatGHS(e.amount)}</td>
                  <td className="px-3 py-2">{e.payment_method || "—"}</td>
                  <td className="px-3 py-2">{e.mileage ? Number(e.mileage).toLocaleString() : "—"}</td>
                  <td className="px-3 py-2 max-w-[200px] truncate" title={e.description}>{e.description || "—"}</td>
                  <td className="px-3 py-2 text-right">
                    <div className="flex justify-end gap-1">
                      <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => { setEditing(e); setFormOpen(true); }} title="Edit"><Pencil className="h-3.5 w-3.5" /></Button>
                      <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={() => handleDelete(e)} title="Delete"><Trash2 className="h-3.5 w-3.5" /></Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </DialogContent>
      <VehicleExpenseFormDialog open={formOpen} onClose={() => setFormOpen(false)} onSaved={onSaved} vehicle={vehicle} entry={editing} />
      {modal}
    </Dialog>
  );
}