import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import useActiveCompany from "@/hooks/useActiveCompany";
import { setActiveCompanyId } from "@/lib/tenant";
import { queryClientInstance } from "@/lib/query-client";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Building2, ChevronsUpDown, Lock, Plus, Loader2, Check } from "lucide-react";

/**
 * Workspace switcher. Selecting another company calls the switchCompany
 * function, which re-issues the session's active company server-side, then
 * clears the query cache so no component keeps rendering the previous
 * workspace's data.
 */
export default function CompanySwitcher({ compact = false }) {
  const { user, checkUserAuth } = useAuth();
  const navigate = useNavigate();
  const { memberships, activeId, activeName, loading } = useActiveCompany();
  const [pending, setPending] = useState(null);
  const [workspaceKey, setWorkspaceKey] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const label = activeName || (loading ? "Loading…" : "Select workspace");

  const doSwitch = async (membership, key) => {
    setBusy(true);
    setError("");
    try {
      const { data } = await base44.functions.invoke("switchCompany", {
        company_id: membership.company_id,
        ...(key ? { workspace_key: key } : {}),
      });
      setActiveCompanyId(data.active_company_id);
      // Drop every cached query so nothing from the previous tenant survives,
      // then refresh the session user (new active company) and re-render.
      queryClientInstance.clear();
      await checkUserAuth();
      window.location.reload();
    } catch (err) {
      const data = err?.response?.data;
      if (data?.key_required) {
        setPending(membership);
        setError(data.error || "Workspace key required");
      } else {
        setError(data?.error || err?.message || "Could not switch workspace");
      }
      setBusy(false);
    }
  };

  const handlePick = (membership) => {
    if (membership.company_id === activeId) return;
    setError("");
    setWorkspaceKey("");
    if (membership.workspace_key_hash) setPending(membership);
    else doSwitch(membership);
  };

  return (
    <>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <button
            className={`flex w-full items-center gap-2 rounded-lg border bg-card px-3 text-left transition-colors hover:bg-accent ${
              compact ? "h-9 text-xs" : "py-2 text-sm"
            }`}
          >
            <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded bg-primary/10 text-primary">
              <Building2 className="h-3.5 w-3.5" />
            </span>
            <span className="min-w-0 flex-1">
              <span className="block truncate font-medium">{label}</span>
              {!compact && (
                <span className="block truncate text-[11px] text-muted-foreground capitalize">
                  {user?.active_company_id ? "Active workspace" : "No workspace"}
                </span>
              )}
            </span>
            <ChevronsUpDown className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
          </button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="start" className="w-64">
          <DropdownMenuLabel>Your Workspaces</DropdownMenuLabel>
          {memberships.length === 0 && (
            <div className="px-2 py-2 text-xs text-muted-foreground">No workspaces yet.</div>
          )}
          {memberships.map((membership) => (
            <DropdownMenuItem
              key={membership.id}
              onClick={() => handlePick(membership)}
              className="cursor-pointer"
            >
              <span className="flex w-full items-center gap-2">
                <span className="min-w-0 flex-1 truncate">{membership.company_name}</span>
                {membership.workspace_key_hash ? <Lock className="h-3 w-3 text-muted-foreground" /> : null}
                <span className="text-[10px] uppercase text-muted-foreground">{membership.role}</span>
                {membership.company_id === activeId ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : null}
              </span>
            </DropdownMenuItem>
          ))}
          <DropdownMenuSeparator />
          <DropdownMenuItem onClick={() => navigate("/onboarding")} className="cursor-pointer">
            <Plus className="mr-2 h-3.5 w-3.5" />
            New workspace
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      <Dialog open={!!pending} onOpenChange={(open) => !open && setPending(null)}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>Workspace key required</DialogTitle>
            <DialogDescription>
              Enter the access key for {pending?.company_name} to switch into it.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-2">
            <Label htmlFor="switch-key">Workspace key</Label>
            <Input
              id="switch-key"
              type="password"
              autoFocus
              value={workspaceKey}
              onChange={(e) => setWorkspaceKey(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && workspaceKey) doSwitch(pending, workspaceKey);
              }}
            />
            {error && <p className="text-sm text-destructive">{error}</p>}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setPending(null)} disabled={busy}>
              Cancel
            </Button>
            <Button onClick={() => doSwitch(pending, workspaceKey)} disabled={busy || !workspaceKey}>
              {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : "Switch"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}