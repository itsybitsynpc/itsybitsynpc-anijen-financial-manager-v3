import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { sanitizeAmountInput } from "@/lib/money";
import { Label } from "@/components/ui/label";
import { base44 } from "@/api/base44Client";
import { toast } from "@/components/ui/use-toast";

const todayInput = () => new Date().toISOString().slice(0, 10);

// Add or edit a debt entry. Creating debt increases total company debt but
// does NOT touch company capital (value received without paying yet).
export default function SupplierDebtDialog({ open, onClose, onSaved, supplier, initial }) {
  const [amount, setAmount] = useState("");
  const [date, setDate] = useState(todayInput());
  const [description, setDescription] = useState("");
  const [saving, setSaving] = useState(false);
  const isEdit = !!initial;

  useEffect(() => {
    if (!open) return;
    if (initial) {
      setAmount(String(initial.amount ?? ""));
      setDate((initial.date ? new Date(initial.date) : new Date()).toISOString().slice(0, 10));
      setDescription(initial.description || "");
    } else {
      setAmount("");
      setDate(todayInput());
      setDescription("");
    }
  }, [open, initial]);

  const handleSave = async () => {
    const amt = Number(amount);
    if (!Number.isFinite(amt) || amt <= 0) {
      toast({ title: "Enter a valid amount", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      const payload = {
        supplier_id: supplier.id,
        supplier_name: supplier.name,
        type: "debt",
        amount: amt,
        date: new Date(date).toISOString(),
        description,
      };
      if (isEdit) await base44.entities.SupplierTransaction.update(initial.id, payload);
      else await base44.entities.SupplierTransaction.create(payload);
      toast({ title: isEdit ? "Debt updated" : "Debt added", description: "Total company debt updated." });
      onSaved?.();
      onClose();
    } catch (e) {
      toast({ title: "Could not save", description: e.message, variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{isEdit ? "Edit Debt" : `Add Debt — ${supplier?.name || ""}`}</DialogTitle>
          <DialogDescription>Adding debt increases what the company owes and reduces Total Company Capital by the same amount. No cash leaves the company yet.</DialogDescription>
        </DialogHeader>
        <div className="space-y-3 py-2">
          <div className="space-y-1.5"><Label>Amount Owed (GHS)</Label><Input type="number" step="0.01" value={amount} onChange={(e) => setAmount(sanitizeAmountInput(e.target.value))} /></div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5"><Label>Date</Label><Input type="date" value={date} onChange={(e) => setDate(e.target.value)} /></div>
            <div className="space-y-1.5"><Label>Description / Ref</Label><Input value={description} onChange={(e) => setDescription(e.target.value)} placeholder="optional" /></div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={saving}>Cancel</Button>
          <Button onClick={handleSave} disabled={saving}>{saving ? "Saving…" : "Save"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}