import { formatGHS, formatDate } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Plus, ArrowUpFromLine, History } from "lucide-react";
import { supplierOutstanding, supplierTotalDebt, supplierTotalRepaid, supplierLastTxDate } from "@/lib/suppliers";

export default function SupplierTable({ suppliers = [], transactions = [], onAddDebt, onRepay, onHistory }) {
  if (suppliers.length === 0) {
    return <div className="rounded-xl border bg-card p-6 text-center text-sm text-muted-foreground">No suppliers yet. Click "Add Supplier" to begin.</div>;
  }
  return (
    <div className="rounded-xl border bg-card shadow-sm overflow-hidden">
      <div className="sticky-header grid grid-cols-12 gap-2 px-4 py-2.5 text-xs font-semibold text-muted-foreground">
        <div className="col-span-3">Supplier</div>
        <div className="col-span-2 text-right">Total Debt</div>
        <div className="col-span-2 text-right">Repaid</div>
        <div className="col-span-2 text-right">Outstanding</div>
        <div className="col-span-1">Last Tx</div>
        <div className="col-span-2 text-right">Actions</div>
      </div>
      <div className="divide-y">
        {suppliers.map((s) => {
          const outstanding = supplierOutstanding(s, transactions);
          const totalDebt = supplierTotalDebt(s, transactions);
          const repaid = supplierTotalRepaid(s, transactions);
          const last = supplierLastTxDate(s, transactions);
          const paid = outstanding <= 0;
          return (
            <div key={s.id} className="grid grid-cols-12 gap-2 px-4 py-3 text-sm items-center">
              <div className="col-span-3 min-w-0">
                <p className="font-medium truncate">{s.name}</p>
                {s.contact && <p className="text-xs text-muted-foreground truncate">{s.contact}</p>}
              </div>
              <div className="col-span-2 text-right">{formatGHS(totalDebt)}</div>
              <div className="col-span-2 text-right text-emerald-600">{formatGHS(repaid)}</div>
              <div className="col-span-2 text-right">
                <p className={`font-medium ${outstanding > 0 ? "text-rose-600" : "text-muted-foreground"}`}>{formatGHS(Math.max(0, outstanding))}</p>
                <span className={`text-[11px] font-medium ${paid ? "text-emerald-600" : "text-rose-600"}`}>{paid ? "Paid" : "Outstanding"}</span>
              </div>
              <div className="col-span-1 text-xs text-muted-foreground">{last ? formatDate(last) : "—"}</div>
              <div className="col-span-2 flex justify-end gap-0.5">
                <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => onAddDebt(s)} title="Add debt"><Plus className="h-3.5 w-3.5" /></Button>
                <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => onRepay(s)} title="Repay" disabled={outstanding <= 0}><ArrowUpFromLine className="h-3.5 w-3.5" /></Button>
                <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => onHistory(s)} title="History"><History className="h-3.5 w-3.5" /></Button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}