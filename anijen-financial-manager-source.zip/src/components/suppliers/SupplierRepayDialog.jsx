import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { sanitizeAmountInput } from "@/lib/money";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { base44 } from "@/api/base44Client";
import { formatGHS } from "@/lib/format";
import { accountBalance } from "@/lib/capital";
import { supplierOutstanding } from "@/lib/suppliers";
import { toast } from "@/components/ui/use-toast";

const todayInput = () => new Date().toISOString().slice(0, 10);

// Repay supplier debt. Creates an outflow in the shared capital system (which
// deducts the chosen Bank/MoMo/Cash balance and total company capital) AND a
// supplier repayment record linked to that capital transaction. Supports edit
// (rebuilds the capital outflow) with guards against over-repaying or
// overdrawing the selected capital source.
export default function SupplierRepayDialog({ open, onClose, onSaved, supplier, capitalAccounts = [], capitalTransactions = [], supplierTransactions = [], initial }) {
  const [amount, setAmount] = useState("");
  const [date, setDate] = useState(todayInput());
  const [accountId, setAccountId] = useState("");
  const [description, setDescription] = useState("");
  const [saving, setSaving] = useState(false);
  const isEdit = !!initial;

  useEffect(() => {
    if (!open) return;
    if (initial) {
      setAmount(String(initial.amount ?? ""));
      setDate((initial.date ? new Date(initial.date) : new Date()).toISOString().slice(0, 10));
      setAccountId(initial.payment_account_id || "");
      setDescription(initial.description || "");
    } else {
      setAmount("");
      setDate(todayInput());
      setAccountId("");
      setDescription("");
    }
  }, [open, initial]);

  const outstandingNow = supplier ? supplierOutstanding(supplier, supplierTransactions) : 0;
  const outstandingBefore = outstandingNow + (isEdit && initial.type === "repayment" ? Number(initial.amount || 0) : 0);

  // When editing, exclude this repayment's existing capital outflow from the
  // balance check so the freed amount can be re-allocated.
  const capitalTxForBalance = isEdit && initial?.linked_capital_tx_id
    ? capitalTransactions.filter((t) => t.id !== initial.linked_capital_tx_id)
    : capitalTransactions;
  const balOf = (acc) => accountBalance(acc, capitalTxForBalance);
  const selectedAccount = capitalAccounts.find((a) => a.id === accountId);
  const selectedBalance = selectedAccount ? balOf(selectedAccount) : 0;

  const handleSave = async () => {
    const amt = Number(amount);
    if (!Number.isFinite(amt) || amt <= 0) { toast({ title: "Enter a valid amount", variant: "destructive" }); return; }
    if (!accountId) { toast({ title: "Select a capital source", variant: "destructive" }); return; }
    if (amt > outstandingBefore) { toast({ title: "Amount exceeds the supplier's outstanding debt", variant: "destructive" }); return; }
    if (amt > selectedBalance) { toast({ title: `Insufficient balance in ${selectedAccount?.name} (${formatGHS(selectedBalance)})`, variant: "destructive" }); return; }
    setSaving(true);
    try {
      if (isEdit && initial.linked_capital_tx_id) {
        await base44.entities.CapitalTransaction.delete(initial.linked_capital_tx_id);
      }
      const cap = await base44.entities.CapitalTransaction.create({
        amount: amt,
        from_account_id: accountId,
        from_account_name: selectedAccount?.name || "",
        to_account_id: "",
        to_account_name: "",
        direction: "outflow",
        reference: `Supplier repayment: ${supplier?.name || ""}`,
        description: description || `Repayment to ${supplier?.name || "supplier"}`,
        date: new Date(date).toISOString(),
      });
      const payload = {
        supplier_id: supplier.id,
        supplier_name: supplier.name,
        type: "repayment",
        amount: amt,
        date: new Date(date).toISOString(),
        description,
        payment_account_id: accountId,
        payment_account_name: selectedAccount?.name || "",
        linked_capital_tx_id: cap.id,
      };
      if (isEdit) await base44.entities.SupplierTransaction.update(initial.id, payload);
      else await base44.entities.SupplierTransaction.create(payload);
      toast({ title: isEdit ? "Repayment updated" : "Debt repaid", description: "Supplier debt and capital balances updated." });
      onSaved?.();
      onClose();
    } catch (e) {
      toast({ title: "Could not save", description: e.message, variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{isEdit ? "Edit Repayment" : `Repay — ${supplier?.name || ""}`}</DialogTitle>
          <DialogDescription>Repaying reduces the supplier's outstanding balance and deducts the cash from the selected Bank/MoMo/Cash balance. Total Company Capital stays the same — the debt already reduced it when it was added.</DialogDescription>
        </DialogHeader>
        <div className="space-y-3 py-2">
          <div className="rounded-md bg-muted/50 px-3 py-2 text-sm text-muted-foreground flex justify-between">
            <span>Outstanding debt: <span className="font-medium text-foreground">{formatGHS(outstandingNow)}</span></span>
            {isEdit && <span>Before edit: {formatGHS(outstandingBefore)}</span>}
          </div>
          <div className="space-y-1.5">
            <Label>Capital Source</Label>
            <Select value={accountId} onValueChange={setAccountId}>
              <SelectTrigger><SelectValue placeholder="Select bank / MoMo / cash" /></SelectTrigger>
              <SelectContent>
                {capitalAccounts.map((a) => (
                  <SelectItem key={a.id} value={a.id}>{a.name} · {formatGHS(balOf(a))}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            {selectedAccount && <p className="text-xs text-muted-foreground mt-1">Available: {formatGHS(selectedBalance)}</p>}
          </div>
          <div className="space-y-1.5"><Label>Amount (GHS)</Label><Input type="number" step="0.01" value={amount} onChange={(e) => setAmount(sanitizeAmountInput(e.target.value))} /></div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5"><Label>Date</Label><Input type="date" value={date} onChange={(e) => setDate(e.target.value)} /></div>
            <div className="space-y-1.5"><Label>Description / Ref</Label><Input value={description} onChange={(e) => setDescription(e.target.value)} placeholder="optional" /></div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={saving}>Cancel</Button>
          <Button onClick={handleSave} disabled={saving}>{saving ? "Saving…" : "Save Repayment"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}