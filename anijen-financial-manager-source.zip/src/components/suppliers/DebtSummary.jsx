import { formatGHS } from "@/lib/format";
import { HandCoins, Users, CheckCircle2, AlertCircle } from "lucide-react";
import { totalOutstanding, totalDebtAdded, totalRepaid, supplierOutstanding } from "@/lib/suppliers";

export default function DebtSummary({ suppliers = [], transactions = [] }) {
  const outstanding = totalOutstanding(suppliers, transactions);
  const added = totalDebtAdded(transactions);
  const repaid = totalRepaid(transactions);
  const rows = suppliers
    .map((s) => ({ name: s.name, outstanding: supplierOutstanding(s, transactions) }))
    .filter((r) => r.outstanding > 0)
    .sort((a, b) => b.outstanding - a.outstanding);

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <Card label="Total Supplier Debt" value={formatGHS(added)} icon={HandCoins} tone="rose" hint="gross debt incurred" />
        <Card label="Number of Suppliers" value={suppliers.length} icon={Users} tone="sky" />
        <Card label="Total Debt Repaid" value={formatGHS(repaid)} icon={CheckCircle2} tone="emerald" />
        <Card label="Outstanding Supplier Debt" value={formatGHS(outstanding)} icon={AlertCircle} tone="amber" />
      </div>
      <div className="rounded-xl border bg-card shadow-sm overflow-hidden">
        <h3 className="font-heading font-semibold px-4 py-3 border-b">Debt Breakdown by Supplier</h3>
        <div className="divide-y">
          {rows.length === 0 && <div className="px-4 py-4 text-sm text-muted-foreground">No outstanding supplier debt.</div>}
          {rows.map((r) => (
            <div key={r.name} className="flex items-center justify-between px-4 py-2.5 text-sm">
              <span className="font-medium truncate">{r.name}</span>
              <span className="font-medium text-rose-600">{formatGHS(r.outstanding)}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function Card({ label, value, icon: Icon, tone, hint }) {
  const toneMap = {
    rose: "bg-rose-100 text-rose-600",
    sky: "bg-sky-100 text-sky-600",
    emerald: "bg-emerald-100 text-emerald-600",
    amber: "bg-amber-100 text-amber-600",
  };
  return (
    <div className="rounded-xl border bg-card shadow-sm p-4">
      <div className="flex items-center justify-between">
        <p className="text-xs font-medium text-muted-foreground">{label}</p>
        <span className={`flex h-8 w-8 items-center justify-center rounded-lg ${toneMap[tone] || "bg-muted text-muted-foreground"}`}><Icon className="h-4 w-4" /></span>
      </div>
      <p className="mt-2 font-heading text-2xl font-semibold">{value}</p>
      {hint && <p className="text-[11px] text-muted-foreground mt-0.5">{hint}</p>}
    </div>
  );
}