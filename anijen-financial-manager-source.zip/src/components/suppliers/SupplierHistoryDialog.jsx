import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Pencil, Trash2 } from "lucide-react";
import { formatGHS, formatDate } from "@/lib/format";

// Per-supplier transaction history with a running outstanding balance after
// each entry. Edit/delete are routed to the parent (which updates capital too).
export default function SupplierHistoryDialog({ open, onClose, supplier, transactions = [], onEdit, onDelete }) {
  const txns = (transactions.filter((t) => t.supplier_id === supplier?.id))
    .sort((a, b) => new Date(a.date || a.created_date) - new Date(b.date || b.created_date));
  let run = 0;
  const withAfter = txns.map((t) => {
    if (t.type === "debt") run += Number(t.amount || 0);
    else run -= Number(t.amount || 0);
    return { ...t, after: run };
  });
  const list = [...withAfter].reverse();

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>{supplier?.name} — Debt History</DialogTitle>
        </DialogHeader>
        <div className="max-h-[60vh] overflow-auto divide-y">
          {list.length === 0 && <div className="px-1 py-6 text-center text-sm text-muted-foreground">No transactions yet.</div>}
          {list.map((t) => (
            <div key={t.id} className="flex items-center justify-between gap-3 px-1 py-2.5 text-sm">
              <div className="min-w-0">
                <p className="font-medium">{t.type === "debt" ? "Debt Added" : "Debt Repaid"}{t.payment_account_name ? ` · ${t.payment_account_name}` : ""}</p>
                <p className="text-xs text-muted-foreground truncate">{formatDate(t.date || t.created_date)}{t.description ? ` · ${t.description}` : ""}</p>
                <p className="text-xs text-muted-foreground">Outstanding after: {formatGHS(Math.max(0, t.after))}</p>
              </div>
              <div className="flex items-center gap-1.5 shrink-0">
                <span className={`font-medium ${t.type === "debt" ? "text-rose-600" : "text-emerald-600"}`}>{t.type === "debt" ? "+" : "−"}{formatGHS(t.amount)}</span>
                <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => onEdit(t)} title="Edit"><Pencil className="h-3.5 w-3.5" /></Button>
                <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={() => onDelete(t)} title="Delete"><Trash2 className="h-3.5 w-3.5" /></Button>
              </div>
            </div>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
}