import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Lock, ShieldAlert } from "lucide-react";
import { base44 } from "@/api/base44Client";

export default function PassphraseModal({
  open,
  onClose,
  onSuccess,
  context,
}) {
  const [value, setValue] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      const res = await base44.functions.invoke("verifyPassphrase", {
        passphrase: value,
      });
      if (res.data?.valid) {
        onSuccess?.();
        setValue("");
        onClose?.();
      } else {
        setError("Incorrect passphrase. Access denied.");
      }
    } catch (err) {
      setError(err?.message || "Verification failed.");
    } finally {
      setLoading(false);
    }
  };

  const handleClose = () => {
    setValue("");
    setError("");
    onClose?.();
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && handleClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <span className="flex h-9 w-9 items-center justify-center rounded-full bg-amber-100 text-amber-600">
              <Lock className="h-4 w-4" />
            </span>
            Admin Passphrase Required
          </DialogTitle>
          <DialogDescription>
            {context
              ? `Enter the master passphrase to authorize: ${context}.`
              : "Enter the master passphrase to authorize this action."}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="passphrase">Passphrase</Label>
            <Input
              id="passphrase"
              type="password"
              value={value}
              onChange={(e) => setValue(e.target.value)}
              autoFocus
              placeholder="Enter passphrase"
              disabled={loading}
            />
          </div>
          {error && (
            <div className="flex items-start gap-2 rounded-md bg-destructive/10 p-2 text-sm text-destructive">
              <ShieldAlert className="h-4 w-4 mt-0.5 shrink-0" />
              <span>{error}</span>
            </div>
          )}
          <DialogFooter>
            <Button type="button" variant="outline" onClick={handleClose} disabled={loading}>
              Cancel
            </Button>
            <Button type="submit" disabled={loading || !value}>
              {loading ? "Verifying…" : "Authorize"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}