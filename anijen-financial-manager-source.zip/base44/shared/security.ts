// Shared security helpers for passphrase-gated backend functions.
//
// Plain module: exported functions only, no Deno.serve. Both verifyPassphrase
// and deleteCompany import from here so the throttle and the constant-time
// comparison exist in exactly one place.

export const WINDOW_MS = 15 * 60 * 1000; // 15 minutes
export const MAX_ATTEMPTS = 5;

export interface RateState {
  count: number;
  firstAttempt: number;
  lockedUntil: number;
  locked: boolean;
}

// In-memory attempt tracking per caller key (user id + client IP).
// State persists for the lifetime of the isolate.
const attempts = new Map<string, { count: number; firstAttempt: number; lockedUntil: number }>();

export function clientIp(req: Request): string {
  const xff = req.headers.get('x-forwarded-for');
  if (xff) return xff.split(',')[0].trim();
  return req.headers.get('cf-connecting-ip') || req.headers.get('x-real-ip') || 'unknown';
}

export function getRateState(key: string): RateState {
  const now = Date.now();
  const s = attempts.get(key);
  if (s && s.lockedUntil && s.lockedUntil > now) {
    return { count: s.count, firstAttempt: s.firstAttempt, lockedUntil: s.lockedUntil, locked: true };
  }
  if (!s || now - s.firstAttempt > WINDOW_MS) {
    return { count: 0, firstAttempt: now, lockedUntil: 0, locked: false };
  }
  return { count: s.count, firstAttempt: s.firstAttempt, lockedUntil: 0, locked: false };
}

export function recordFailure(key: string, state: RateState): void {
  const count = state.count + 1;
  const lockedUntil = count >= MAX_ATTEMPTS ? Date.now() + WINDOW_MS : 0;
  attempts.set(key, { count, firstAttempt: state.firstAttempt, lockedUntil });
}

export function clearRate(key: string): void {
  attempts.delete(key);
}

function ctEqual(a: Uint8Array, b: Uint8Array): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a[i] ^ b[i];
  return diff === 0;
}

// Constant-time comparison over fixed-length SHA-256 digests, so neither input
// length nor byte position leaks through timing.
export async function timingSafeCompareStr(a: string, b: string): Promise<boolean> {
  const enc = new TextEncoder();
  const [ha, hb] = await Promise.all([
    crypto.subtle.digest('SHA-256', enc.encode(a)),
    crypto.subtle.digest('SHA-256', enc.encode(b)),
  ]);
  const ba = new Uint8Array(ha);
  const bb = new Uint8Array(hb);
  if (typeof crypto.timingSafeEqual === 'function') {
    return crypto.timingSafeEqual(ba, bb);
  }
  return ctEqual(ba, bb);
}

// ---------------------------------------------------------------------------
// Shared request hardening used by every backend function.
//
// The platform terminates TLS, applies CORS and injects the security headers on
// the app shell, and it signs/expires the session token — none of that is
// re-implemented here. What functions own is their own surface: tenant binding,
// payload shape, input sanitising, throttling, log hygiene and error output.
// ---------------------------------------------------------------------------

export const MAX_BODY_BYTES = 64 * 1024;

// Keys that must never arrive from the client to select a tenant.
const TENANT_KEYS = ['company_id', 'companyId', 'tenant_id', 'tenantId', 'workspace_id'];
const TENANT_HEADERS = ['x-company-id', 'x-tenant-id', 'x-workspace-id', 'company-id', 'tenant-id'];

// Returns a description of the offending carrier when a caller tries to smuggle
// a tenant id through the URL or a header, otherwise null.
//
// A tenant is only ever read from the verified session (user.active_company_id).
// Functions that operate on a *target* workspace accept a validated body field
// and prove membership before touching anything, so the body is not a bypass.
export function tenantOverrideFromRequest(req: Request): string | null {
  try {
    const url = new URL(req.url);
    for (const key of TENANT_KEYS) {
      if (url.searchParams.has(key)) return 'query:' + key;
    }
  } catch {
    /* unparseable URL — fall through to headers */
  }
  for (const key of TENANT_HEADERS) {
    if (req.headers.get(key)) return 'header:' + key;
  }
  return null;
}

export function requirePost(req: Request): Response | null {
  if (req.method !== 'POST') {
    return safeJson({ error: 'Method not allowed' }, { status: 405, headers: { Allow: 'POST' } });
  }
  return null;
}

export function bodyTooLarge(req: Request, max = MAX_BODY_BYTES): boolean {
  const declared = Number(req.headers.get('content-length') || 0);
  return Number.isFinite(declared) && declared > max;
}

// Strips control characters, markup and surplus whitespace, then caps length.
// Output-side encoding (React) is still the XSS defence; this keeps stored text
// free of markup so nothing unsafe can ever be re-rendered or echoed.
export function sanitizeText(input: unknown, maxLen = 200): string {
  return String(input ?? '')
    .replace(/[\u0000-\u001F\u007F]/g, ' ')
    .replace(/<[^>]*>/g, '')
    .replace(/[<>]/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, maxLen);
}

// JSON response with no-store / nosniff / no-referrer, so financial payloads
// are never cached by a proxy or interpreted as another content type.
export function safeJson(data: unknown, statusOrInit: any = 200): Response {
  const init = typeof statusOrInit === 'number' ? { status: statusOrInit } : { ...(statusOrInit || {}) };
  const headers = new Headers(init.headers || {});
  headers.set('Cache-Control', 'no-store, max-age=0');
  headers.set('X-Content-Type-Options', 'nosniff');
  headers.set('Referrer-Policy', 'no-referrer');
  return Response.json(data, { ...init, headers });
}

export type ParseResult = { ok: true; data: any } | { ok: false; response: Response };

// Parses and structurally validates a JSON body against a Zod schema.
// `schema` is passed in so this module stays free of a validation dependency.
export async function parseBody(req: Request, schema: any, maxBytes = MAX_BODY_BYTES): Promise<ParseResult> {
  if (bodyTooLarge(req, maxBytes)) {
    return { ok: false, response: safeJson({ error: 'Payload too large' }, 413) };
  }
  const raw = await req.json().catch(() => null);
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) {
    return { ok: false, response: safeJson({ error: 'Invalid request body' }, 400) };
  }
  const parsed = schema.safeParse(raw);
  if (!parsed.success) {
    // Field names and codes only — never echo submitted values back.
    const issues = (parsed.error.issues || []).slice(0, 20).map((i: any) => ({
      path: i.path,
      code: i.code,
    }));
    return { ok: false, response: safeJson({ error: 'Invalid input', issues }, 400) };
  }
  return { ok: true, data: parsed.data };
}

// Structured security log for privileged operations. Single line, no secrets,
// no passphrases, no full payloads.
export function logSecurityEvent(event: string, details: Record<string, unknown> = {}): void {
  try {
    console.error(JSON.stringify({ type: 'security', event, at: new Date().toISOString(), ...details }));
  } catch {
    console.error('security:' + event);
  }
}

// Centralised error output: the real message goes to the app logs only, so no
// stack trace, file path or database detail can reach the client.
export function serverError(error: unknown, publicMessage = 'Request failed'): Response {
  const message = String((error as any)?.message || error || 'unknown error');
  logSecurityEvent('unhandled_error', { message });
  return safeJson({ error: publicMessage }, 500);
}

// Fixed-window counter for route-level denial-of-service protection.
const hits = new Map<string, { count: number; windowStart: number }>();

export function takeToken(key: string, max: number, windowMs: number): boolean {
  const now = Date.now();
  const current = hits.get(key);
  if (!current || now - current.windowStart > windowMs) {
    if (hits.size > 5000) hits.clear();
    hits.set(key, { count: 1, windowStart: now });
    return true;
  }
  if (current.count >= max) return false;
  current.count += 1;
  return true;
}