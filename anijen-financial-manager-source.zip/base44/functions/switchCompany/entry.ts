import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';
import { z } from 'npm:zod@4.6.7';
import {
  clientIp,
  logSecurityEvent,
  parseBody,
  requirePost,
  safeJson,
  serverError,
  takeToken,
  tenantOverrideFromRequest,
  timingSafeCompareStr,
} from '../../shared/security.ts';

// Switches the caller's active company. This is the server-side "token
// refresh": the active company lives on the user record and can only be
// changed here, after membership is verified against the database — never
// from a client-supplied value. Workspaces that carry an access key require
// that key, so holding an account is not enough to enter them.

const PayloadSchema = z.object({
  company_id: z.string().trim().min(1).max(64),
  workspace_key: z.string().trim().min(1).max(128).optional(),
});

const MIN_SWITCH_INTERVAL_MS = 750;
const lastSwitchByUser = new Map();

async function hashKey(raw) {
  const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(raw));
  return Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, '0')).join('');
}

export default async function (req) {
  try {
    const methodBlock = requirePost(req);
    if (methodBlock) return methodBlock;

    const override = tenantOverrideFromRequest(req);
    if (override) {
      logSecurityEvent('tenant_override_attempt', { route: 'switchCompany', carrier: override });
      return safeJson({ error: 'Invalid request' }, { status: 400 });
    }

    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me().catch((e) => (e.status === 401 ? null : Promise.reject(e)));
    if (!user) return safeJson({ error: 'Unauthorized' }, { status: 401 });

    // Switching is a credential check when the workspace carries a key, so it
    // is throttled per account and per client address.
    if (!takeToken(`switch:${user.id}:${clientIp(req)}`, 20, 60 * 1000)) {
      logSecurityEvent('switch_rate_limited', { user_id: user.id });
      return safeJson({ error: 'Too many attempts. Try again shortly.' }, { status: 429 });
    }

    const parsed = await parseBody(req, PayloadSchema);
    if (!parsed.ok) return parsed.response;
    const { company_id, workspace_key } = parsed.data;

    // Basic per-user throttle on the switching endpoint.
    const now = Date.now();
    const last = lastSwitchByUser.get(user.id) || 0;
    if (now - last < MIN_SWITCH_INTERVAL_MS) {
      return safeJson({ error: 'Too many switches, slow down' }, { status: 429 });
    }
    lastSwitchByUser.set(user.id, now);

    const db = base44.asServiceRole.entities;
    const memberships = await db.CompanyMembership.filter({ user_id: user.id, company_id });
    const membership = memberships?.[0];
    if (!membership) {
      return safeJson({ error: 'Not a member of this workspace' }, { status: 403 });
    }

    const company = await db.Company.get(company_id).catch((e) => (e.status === 404 ? null : Promise.reject(e)));
    if (!company) return safeJson({ error: 'Workspace not found' }, { status: 404 });
    if (company.status !== 'active') {
      return safeJson({ error: 'This workspace is suspended' }, { status: 403 });
    }

    if (membership.workspace_key_hash) {
      if (!workspace_key) {
        return safeJson({ error: 'Workspace key required', key_required: true }, { status: 401 });
      }
      const candidate = await hashKey(workspace_key);
      if (!(await timingSafeCompareStr(candidate, membership.workspace_key_hash))) {
        logSecurityEvent('workspace_key_denied', { user_id: user.id, company_id });
        return safeJson({ error: 'Incorrect workspace key', key_required: true }, { status: 401 });
      }
    }

    await db.User.update(user.id, { active_company_id: company.id });
    await db.CompanyMembership.update(membership.id, { last_used_at: new Date().toISOString() });
    logSecurityEvent('workspace_switched', { user_id: user.id, company_id: company.id });

    return safeJson({
      active_company_id: company.id,
      company_name: company.name,
      role: membership.role,
    });
  } catch (error) {
    return serverError(error, 'Could not switch workspace');
  }
}