import { createClientFromRequest } from "npm:@base44/sdk@0.8.54";
import { secrets } from "base44:runtime";
import { z } from "npm:zod@4.6.7";
import {
  clearRate,
  clientIp,
  getRateState,
  logSecurityEvent,
  parseBody,
  recordFailure,
  requirePost,
  safeJson,
  tenantOverrideFromRequest,
  timingSafeCompareStr,
} from "../../shared/security.ts";

const PayloadSchema = z.object({
  passphrase: z.string().min(1).max(200),
});

export default async function (req: Request): Promise<Response> {
  try {
    const methodBlock = requirePost(req);
    if (methodBlock) return methodBlock;

    const override = tenantOverrideFromRequest(req);
    if (override) {
      logSecurityEvent("tenant_override_attempt", { route: "verifyPassphrase", carrier: override });
      return safeJson({ valid: false }, { status: 400 });
    }

    // 1. Require an authenticated caller session.
    const base44 = createClientFromRequest(req);
    let user;
    try {
      user = await base44.auth.me();
    } catch {
      user = null;
    }
    if (!user) {
      return safeJson({ valid: false }, { status: 401 });
    }

    const stored = String(secrets.get("ADMIN_PASSPHRASE") || "");
    const rateKey = `${user.id}:${clientIp(req)}`;
    const state = getRateState(rateKey);

    // 2. Enforce brute-force lockout before evaluating any payload.
    if (state.locked) {
      return safeJson({ valid: false }, { status: 429 });
    }

    if (!stored) {
      return safeJson({ valid: false }, { status: 500 });
    }

    // Structural validation with a small body cap: an oversized or malformed
    // payload can never reach the comparison.
    const parsed = await parseBody(req, PayloadSchema, 4096);
    if (!parsed.ok) {
      recordFailure(rateKey, state);
      return safeJson({ valid: false }, { status: 400 });
    }
    const submitted = parsed.data.passphrase;

    // 3. Timing-safe comparison + generic response.
    const valid = await timingSafeCompareStr(submitted, stored);
    if (valid) {
      clearRate(rateKey);
      return safeJson({ valid: true });
    }
    recordFailure(rateKey, state);
    logSecurityEvent("passphrase_denied", { user_id: user.id });
    return safeJson({ valid: false });
  } catch (error) {
    logSecurityEvent("unhandled_error", {
      route: "verifyPassphrase",
      message: String((error as any)?.message || error),
    });
    return safeJson({ valid: false }, { status: 500 });
  }
}