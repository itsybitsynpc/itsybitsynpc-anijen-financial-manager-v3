import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';
import { z } from 'npm:zod@4.6.7';
import {
  logSecurityEvent,
  parseBody,
  requirePost,
  safeJson,
  sanitizeText,
  serverError,
  takeToken,
  tenantOverrideFromRequest,
} from '../../shared/security.ts';

// Batch factory stock intake.
//
// Records one FactoryIntake row per product in the batch and adds the received
// cartons to each product's factory stock, so a single submission can never
// leave inventory half-updated (intakes are written first, then each product's
// stock is incremented atomically with $inc).
//
// The company is taken ONLY from the verified session (user.active_company_id)
// and every product is re-checked against that company before it is touched, so
// a caller can never post stock into another tenant's inventory.

const LineSchema = z.object({
  product_id: z.string().trim().min(1).max(120),
  cartons: z.number().finite().nonnegative().max(1_000_000),
  damaged_cartons: z.number().finite().nonnegative().max(1_000_000).optional().default(0),
  cost_per_carton: z.number().finite().nonnegative().max(10_000_000_000),
});

const PayloadSchema = z.object({
  items: z.array(LineSchema).min(1).max(50),
  description: z.string().trim().max(300).optional().default(''),
  logTransport: z.boolean().optional().default(false),
});

export default async function (req: Request): Promise<Response> {
  try {
    const methodError = requirePost(req);
    if (methodError) return methodError;

    const override = tenantOverrideFromRequest(req);
    if (override) {
      logSecurityEvent('tenant_override_blocked', { route: 'recordFactoryIntake', carrier: override });
      return safeJson({ error: 'Tenant may not be selected by the caller' }, { status: 400 });
    }

    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me().catch((e) => (e.status === 401 ? null : Promise.reject(e)));
    if (!user) return safeJson({ error: 'Unauthorized' }, { status: 401 });

    if (!takeToken(`intake:${user.id}`, 40, 60_000)) {
      return safeJson({ error: 'Too many submissions. Please wait a moment and try again.' }, { status: 429 });
    }

    const parsed = await parseBody(req, PayloadSchema);
    if (!parsed.ok) return parsed.response;

    const companyId = String(
      (user as any)?.active_company_id || (user as any)?.data?.active_company_id || ''
    ).trim();
    if (!companyId) {
      return safeJson(
        { error: 'No active company is selected. Open Workspace settings and choose a company first.' },
        { status: 400 },
      );
    }

    const seen = new Set<string>();
    for (const line of parsed.data.items) {
      if (line.cartons <= 0) {
        return safeJson({ error: 'Every product row needs a carton quantity above zero.' }, { status: 400 });
      }
      if (line.damaged_cartons > line.cartons) {
        return safeJson(
          { error: 'Damaged cartons cannot be more than the cartons received on that row.' },
          { status: 400 },
        );
      }
      if (seen.has(line.product_id)) {
        return safeJson(
          { error: 'Each product can only appear once in a batch. Remove the duplicate row.' },
          { status: 400 },
        );
      }
      seen.add(line.product_id);
    }

    const ids = Array.from(seen);
    // One company-scoped read (ids are not queryable with $in), then every
    // selected product is verified to belong to this company.
    const page: any = await base44.entities.Product.filter({ company_id: companyId }, { limit: 500 });
    const products: any[] = page?.items || [];
    const byId = new Map(
      products.filter((p: any) => seen.has(p.id)).map((p: any) => [p.id, p]),
    );
    if (byId.size !== ids.length) {
      return safeJson({ error: 'One or more selected products no longer exist in this company.' }, { status: 400 });
    }

    const now = new Date().toISOString();
    const description = sanitizeText(parsed.data.description, 300);

    const intakeRows = parsed.data.items.map((line) => {
      const product: any = byId.get(line.product_id);
      return {
        company_id: companyId,
        product_id: line.product_id,
        product_name: product?.name || '',
        cartons: line.cartons,
        damaged_cartons: line.damaged_cartons,
        cost_per_carton: line.cost_per_carton,
        total_cost: Number((line.cartons * line.cost_per_carton).toFixed(2)),
        description,
        date: now,
      };
    });

    const created: any[] = await base44.entities.FactoryIntake.bulkCreate(intakeRows);

    // Atomic, per-product increments — no read-modify-write race, and each
    // update is scoped to this company by the RLS rule. Damaged cartons are
    // never added to stock: only the net figure (received − damaged) is stored,
    // and the damaged count is kept separately for reporting/damage costs.
    const updates = await Promise.allSettled(
      intakeRows.map((row) =>
        base44.entities.Product.updateMany(
          { id: row.product_id, company_id: companyId },
          {
            $inc: {
              factory_stock_cartons: row.cartons - row.damaged_cartons,
              ...(row.damaged_cartons > 0 ? { damaged_quantity: row.damaged_cartons } : {}),
            },
          },
        ),
      ),
    );
    const failed = updates.filter(
      (r: any) => r.status === 'rejected' || Number(r.value?.updated || 0) < 1,
    );
    if (failed.length) {
      logSecurityEvent('intake_stock_update_failed', {
        route: 'recordFactoryIntake',
        user_id: user.id,
        company_id: companyId,
        failed: failed.length,
      });
      return safeJson(
        {
          error:
            'The intake entries were saved but stock could not be added for every product. Check the factory stock figures and adjust any that are short.',
          recorded: created.length,
        },
        { status: 500 },
      );
    }

    if (parsed.data.logTransport) {
      const expenseRows = intakeRows
        .map((row) => {
          const product: any = byId.get(row.product_id);
          const rate = Number(product?.transport_rate_per_unit || 0);
          if (!(rate > 0)) return null;
          return {
            company_id: companyId,
            item: `Transport: ${product?.name || 'Product'} (${row.cartons} cartons)`,
            amount: Number((row.cartons * rate).toFixed(2)),
            category: 'Transport',
            payment_method: '',
            notes: 'Auto-logged from stock intake',
            date: now,
          };
        })
        .filter(Boolean);
      if (expenseRows.length) {
        await base44.entities.Expense.bulkCreate(expenseRows);
      }
    }

    const totalCartons = intakeRows.reduce((s, r) => s + r.cartons, 0);
    const totalCost = intakeRows.reduce((s, r) => s + r.total_cost, 0);

    return safeJson({
      recorded: created.length,
      total_cartons: totalCartons,
      total_cost: Number(totalCost.toFixed(2)),
      products: intakeRows.map((r) => ({ product_id: r.product_id, name: r.product_name, cartons: r.cartons })),
    });
  } catch (error) {
    return serverError(error, 'The stock intake could not be recorded.');
  }
}