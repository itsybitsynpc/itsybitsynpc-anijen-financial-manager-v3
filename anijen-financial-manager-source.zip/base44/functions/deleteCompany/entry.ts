import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';
import { secrets } from 'base44:runtime';
import { z } from 'npm:zod@4.6.7';
import {
  clearRate,
  clientIp,
  getRateState,
  logSecurityEvent,
  parseBody,
  recordFailure,
  requirePost,
  safeJson,
  serverError,
  takeToken,
  tenantOverrideFromRequest,
  timingSafeCompareStr,
} from '../../shared/security.ts';

// Permanently removes a company workspace and every record that belongs to it.
//
// Guards, in order:
//   1. authenticated session
//   2. per-user + per-IP rate limit (brute-force protection on the passphrase)
//   3. a typed confirmation phrase
//   4. the master admin passphrase, held only in backend secrets and compared
//      in constant time
//   5. workspace admin membership, re-read from the database
//
// The company id is taken from the request but is only ever used AFTER the
// membership check proves the caller administers that exact company, so it can
// never address a tenant the caller does not control.

const CONFIRMATION_PHRASE = 'DELETE MY COMPANY';

const PayloadSchema = z.object({
  company_id: z.string().trim().min(1).max(64),
  confirmation: z.string().trim().max(64),
  passphrase: z.string().min(1).max(200),
});

// Purge order: dependent records before the records they point at.
const TENANT_ENTITIES = [
  'CustomerTransaction',
  'SalesPersonTransaction',
  'FactoryIntake',
  'FactoryPayment',
  'SupplierTransaction',
  'CapitalTransaction',
  'VehicleExpense',
  'IncomeLog',
  'Expense',
  'ExpenseCategory',
  'NetIncomeCorrection',
  'Customer',
  'SalesPerson',
  'Product',
  'Supplier',
  'CapitalAccount',
  'Vehicle',
];

async function purgeTenant(db, companyId) {
  const purged = {};
  for (const name of TENANT_ENTITIES) {
    let removed = 0;
    for (let pass = 0; pass < 25; pass++) {
      const remaining = await db[name].count({ company_id: companyId }).catch(() => 0);
      if (!remaining) break;
      await db[name].deleteMany({ company_id: companyId });
      removed += remaining;
    }
    purged[name] = removed;
  }
  return purged;
}

export default async function (req) {
  try {
    const methodBlock = requirePost(req);
    if (methodBlock) return methodBlock;

    // A tenant id may never arrive through the URL or a header.
    const override = tenantOverrideFromRequest(req);
    if (override) {
      logSecurityEvent('tenant_override_attempt', { route: 'deleteCompany', carrier: override });
      return safeJson({ error: 'Invalid request' }, { status: 400 });
    }

    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me().catch((e) => (e.status === 401 ? null : Promise.reject(e)));
    if (!user) return safeJson({ error: 'Unauthorized' }, { status: 401 });

    const rateKey = `${user.id}:${clientIp(req)}`;
    const state = getRateState(rateKey);
    if (state.locked) {
      return safeJson({ error: 'Too many attempts. Try again later.' }, { status: 429 });
    }

    // Structural validation before any privileged work, with a body-size cap.
    const parsed = await parseBody(req, PayloadSchema);
    if (!parsed.ok) return parsed.response;
    const { company_id, confirmation, passphrase } = parsed.data;

    // Typed confirmation first — cheap check, and it never reveals whether the
    // passphrase was right.
    if (confirmation !== CONFIRMATION_PHRASE) {
      recordFailure(rateKey, state);
      return safeJson(
        { error: `Type "${CONFIRMATION_PHRASE}" exactly to confirm.` },
        { status: 400 }
      );
    }

    const stored = String(secrets.get('ADMIN_PASSPHRASE') || '');
    if (!stored) return safeJson({ error: 'Deletion is not configured' }, { status: 500 });

    const passOk = await timingSafeCompareStr(passphrase, stored);
    if (!passOk) {
      recordFailure(rateKey, state);
      logSecurityEvent('company_delete_denied', { user_id: user.id, reason: 'bad_passphrase' });
      return safeJson({ error: 'Incorrect admin passphrase.' }, { status: 401 });
    }

    const db = base44.asServiceRole.entities;

    // Authorization: the caller must administer this specific workspace.
    const memberships = await db.CompanyMembership.filter({ user_id: user.id, company_id });
    const membership = memberships?.[0];
    const isAdmin =
      membership?.role === 'admin' && (user.admin_company_ids || []).includes(company_id);
    if (!isAdmin) {
      recordFailure(rateKey, state);
      return safeJson(
        { error: 'Only a workspace admin can delete this workspace.' },
        { status: 403 }
      );
    }

    const company = await db.Company.get(company_id).catch((e) => (e.status === 404 ? null : Promise.reject(e)));
    if (!company) return safeJson({ error: 'Workspace not found' }, { status: 404 });

    const purged = await purgeTenant(db, company_id);

    // Membership rows for every user, captured before they are removed so each
    // user's pointers can be repaired below.
    const members = await db.CompanyMembership.filter({ company_id });
    await db.CompanyMembership.deleteMany({ company_id });
    await db.Company.delete(company_id);

    let callerActive = '';
    const allUsers = await db.User.list();
    for (const u of allUsers) {
      const ids = (u.company_ids || []).filter((id) => id !== company_id);
      const adminIds = (u.admin_company_ids || []).filter((id) => id !== company_id);
      const belongsHere =
        members.some((m) => m.user_id === u.id) ||
        (u.company_ids || []).includes(company_id) ||
        u.active_company_id === company_id;
      if (!belongsHere) continue;

      const nextActive =
        u.active_company_id === company_id ? ids[0] || '' : u.active_company_id || '';
      await db.User.update(u.id, {
        company_ids: ids,
        admin_company_ids: adminIds,
        active_company_id: nextActive,
      });
      if (u.id === user.id) callerActive = nextActive;
    }

    clearRate(rateKey);
    logSecurityEvent('company_deleted', {
      user_id: user.id,
      company_id,
      company_name: company.name,
      purged_records: Object.values(purged).reduce((s, n: any) => s + Number(n || 0), 0),
    });

    return safeJson({
      deleted: true,
      company_id,
      company_name: company.name,
      purged,
      active_company_id: callerActive,
      remaining_companies: (user.company_ids || []).filter((id) => id !== company_id),
    });
  } catch (error) {
    return serverError(error, 'Workspace deletion failed');
  }
}