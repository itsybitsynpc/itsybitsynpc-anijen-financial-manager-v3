import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';
import { z } from 'npm:zod@4.6.7';
import {
  logSecurityEvent,
  parseBody,
  requirePost,
  safeJson,
  sanitizeText,
  serverError,
  takeToken,
  tenantOverrideFromRequest,
} from '../../shared/security.ts';

// Provisions a brand-new company workspace and binds the caller as its owner,
// then points the caller's session at it. Also used to (re)set the optional
// per-workspace access key on a workspace the caller administers.
//
// The company id is never taken from a request for scoping purposes: this is
// the only place a tenant is created, and membership is written here.

const MAX_WORKSPACES_PER_USER = 10;

const PayloadSchema = z.object({
  name: z.string().trim().min(2).max(80).optional(),
  workspace_key: z.string().trim().min(4).max(128).optional(),
  company_id: z.string().trim().min(1).max(64).optional(),
});

async function hashKey(raw) {
  const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(raw));
  return Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, '0')).join('');
}

export default async function (req) {
  try {
    const methodBlock = requirePost(req);
    if (methodBlock) return methodBlock;

    const override = tenantOverrideFromRequest(req);
    if (override) {
      logSecurityEvent('tenant_override_attempt', { route: 'provisionCompany', carrier: override });
      return safeJson({ error: 'Invalid request' }, { status: 400 });
    }

    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me().catch((e) => (e.status === 401 ? null : Promise.reject(e)));
    if (!user) return safeJson({ error: 'Unauthorized' }, { status: 401 });

    if (!takeToken(`provision:${user.id}`, 20, 60 * 1000)) {
      return safeJson({ error: 'Too many requests, slow down' }, { status: 429 });
    }

    const parsed = await parseBody(req, PayloadSchema);
    if (!parsed.ok) return parsed.response;
    const { workspace_key, company_id } = parsed.data;
    // Workspace names are stored as plain text — markup and control characters
    // are stripped before the value reaches the database.
    const name = parsed.data.name === undefined ? undefined : sanitizeText(parsed.data.name, 80);
    if (name !== undefined && name.length < 2) {
      return safeJson({ error: 'Invalid input' }, { status: 400 });
    }

    const db = base44.asServiceRole.entities;
    const keyHash = workspace_key ? await hashKey(workspace_key) : '';

    // Mode 1: set / clear the access key of an existing workspace.
    if (company_id) {
      const memberships = await db.CompanyMembership.filter({
        user_id: user.id,
        company_id,
      });
      const membership = memberships?.[0];
      if (!membership) return safeJson({ error: 'Not a member of this workspace' }, { status: 403 });
      if (membership.role !== 'admin') {
        return safeJson({ error: 'Only a workspace admin can change its key' }, { status: 403 });
      }
      const updated = await db.CompanyMembership.update(membership.id, { workspace_key_hash: keyHash });
      logSecurityEvent('workspace_key_updated', { user_id: user.id, company_id });
      return safeJson({ membership: updated, active_company_id: user.active_company_id || '' });
    }

    // Mode 2: create a new company workspace.
    if (!name) return safeJson({ error: 'Company name is required' }, { status: 400 });

    const existing = await db.CompanyMembership.filter({ user_id: user.id });
    if ((existing?.length || 0) >= MAX_WORKSPACES_PER_USER) {
      return safeJson({ error: 'Workspace limit reached' }, { status: 429 });
    }

    const company = await db.Company.create({
      name,
      owner_id: user.id,
      owner_email: user.email || '',
      members: [user.id],
      admin_members: [user.id],
      status: 'active',
    });

    const membership = await db.CompanyMembership.create({
      user_id: user.id,
      user_email: user.email || '',
      company_id: company.id,
      company_name: company.name,
      role: 'admin',
      workspace_key_hash: keyHash,
    });

    const companyIds = Array.from(new Set([...(user.company_ids || []), company.id]));
    const adminIds = Array.from(new Set([...(user.admin_company_ids || []), company.id]));

    await db.User.update(user.id, {
      company_ids: companyIds,
      admin_company_ids: adminIds,
      active_company_id: company.id,
    });

    logSecurityEvent('workspace_created', { user_id: user.id, company_id: company.id });

    return safeJson({
      company,
      membership,
      active_company_id: company.id,
    });
  } catch (error) {
    return serverError(error, 'Could not create workspace');
  }
}