import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';
import {
  logSecurityEvent,
  requirePost,
  safeJson,
  serverError,
  takeToken,
  tenantOverrideFromRequest,
} from '../../shared/security.ts';

// Aggregates every entity list the Dashboard needs into a single response.
//
// TENANCY: reads use the service role, which bypasses RLS, so this function
// scopes every query itself with the caller's active company. That company is
// taken from the server-side user record and re-checked against the caller's
// membership list — never from the request body, query params or headers.
export default async function(req) {
  try {
    const methodBlock = requirePost(req);
    if (methodBlock) return methodBlock;

    // This endpoint takes no tenant input at all: any attempt to supply one is
    // rejected rather than silently ignored.
    const override = tenantOverrideFromRequest(req);
    if (override) {
      logSecurityEvent('tenant_override_attempt', { route: 'loadDashboardData', carrier: override });
      return safeJson({ error: 'Invalid request' }, { status: 400 });
    }

    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me().catch((e) => (e.status === 401 ? null : Promise.reject(e)));
    if (!user) return safeJson({ error: 'Unauthorized' }, { status: 401 });

    const companyId = user.active_company_id || '';
    const memberships = Array.isArray(user.company_ids) ? user.company_ids : [];

    if (!companyId) {
      return safeJson({ error: 'No active company', code: 'NO_ACTIVE_COMPANY' }, { status: 400 });
    }
    if (!memberships.includes(companyId)) {
      return safeJson({ error: 'Not a member of this workspace' }, { status: 403 });
    }

    // One call fans out to 13 queries, so it is capped per account. The cap is
    // far above normal live-dashboard refetch rates — it only stops abuse.
    if (!takeToken(`dashboard:${user.id}`, 240, 60 * 1000)) {
      return safeJson({ error: 'Too many requests, slow down' }, { status: 429 });
    }

    const db = base44.asServiceRole.entities;
    const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
    const tenant = { company_id: companyId };

    const isTransient = (e) => {
      const msg = String((e && (e.message || e.statusText || e)) || '').toLowerCase();
      const status = e && (e.status || e.statusCode);
      return /rate|429|too many|throttl|quota|econnreset|etimedout|timeout|socket hang up|network|503/.test(msg)
        || status === 429 || status === 503;
    };

    async function safeList(fn) {
      for (let attempt = 0; attempt < 5; attempt++) {
        try {
          return await fn();
        } catch (e) {
          if (!isTransient(e) || attempt === 4) throw e;
          await sleep(800 * (attempt + 1));
        }
      }
    }

    const page = async (entityName, sort, limit) => {
      const result = await safeList(() => db[entityName].filter(tenant, { sort, limit }));
      return result?.items || [];
    };

    const customers = await page('Customer', 'name', 500);
    await sleep(250);
    const salesPersons = await page('SalesPerson', 'name', 200);
    await sleep(250);
    const customerTransactions = await page('CustomerTransaction', '-created_date', 2000);
    await sleep(250);
    const salesPersonTransactions = await page('SalesPersonTransaction', '-created_date', 2000);
    await sleep(250);
    const incomeLogs = await page('IncomeLog', '-created_date', 500);
    await sleep(250);
    const factoryPayments = await page('FactoryPayment', '-created_date', 500);
    await sleep(250);
    const expenses = await page('Expense', '-created_date', 500);
    await sleep(250);
    const vehicleExpenses = await page('VehicleExpense', '-date', 5000);
    await sleep(250);
    const corrections = await page('NetIncomeCorrection', '-date', 5);
    await sleep(250);
    const capitalAccounts = await page('CapitalAccount', 'sort_order', 200);
    await sleep(250);
    const capitalTransactions = await page('CapitalTransaction', '-date', 2000);
    await sleep(250);
    const suppliers = await page('Supplier', 'name', 200);
    await sleep(250);
    const supplierTransactions = await page('SupplierTransaction', '-date', 2000);

    return safeJson({
      company_id: companyId,
      customers,
      salesPersons,
      customerTransactions,
      salesPersonTransactions,
      incomeLogs,
      factoryPayments,
      expenses,
      vehicleExpenses,
      corrections,
      capitalAccounts,
      capitalTransactions,
      suppliers,
      supplierTransactions,
    });
  } catch (error) {
    return serverError(error, 'Could not load dashboard data');
  }
}