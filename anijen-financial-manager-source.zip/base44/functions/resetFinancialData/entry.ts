import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';
import { secrets } from 'base44:runtime';
import { z } from 'npm:zod@4.6.7';
import {
  clearRate,
  clientIp,
  getRateState,
  logSecurityEvent,
  parseBody,
  recordFailure,
  requirePost,
  safeJson,
  serverError,
  takeToken,
  tenantOverrideFromRequest,
  timingSafeCompareStr,
} from '../../shared/security.ts';

// Clears every stored financial balance for the caller's active company and
// resets it cleanly to 0.00 — never into a negative figure.
//
// Guards, in order:
//   1. authenticated session
//   2. request throttling
//   3. typed confirmation phrase
//   4. master admin passphrase (backend secret, constant-time compare)
//   5. workspace admin membership, re-read from the database
//
// The company is taken ONLY from the verified session (user.data
// .active_company_id), so a caller can never reset another tenant's data.
// Transaction history is preserved; only balances and payment amounts are
// zeroed. Capital movements are deleted only when explicitly requested.

const CONFIRMATION_PHRASE = 'RESET BALANCES';
const MAX_PASSES = 25;

const PayloadSchema = z.object({
  passphrase: z.string().min(1).max(200),
  confirmation: z.string().trim().max(64),
  includeCapitalLedger: z.boolean().optional().default(false),
  // Optional: the company the caller is resetting. Always re-validated against
  // server-side admin membership below, so it can never widen scope.
  companyId: z.string().trim().max(120).optional().default(''),
});

// Repeats a bulk update until nothing matches, so a large company (more than
// one 500-record batch) is reset fully. Because the query excludes rows that
// are already zero, the same rows stop matching and the loop terminates.
async function zeroUntilClear(db: any, entity: string, companyId: string, match: any, set: any) {
  for (let pass = 0; pass < MAX_PASSES; pass++) {
    const remaining = await db[entity]
      .count({ company_id: companyId, ...match })
      .catch(() => 0);
    if (!remaining) return;
    await db[entity].updateMany({ company_id: companyId, ...match }, { $set: set });
  }
}

async function purgeUntilClear(db: any, entity: string, companyId: string) {
  for (let pass = 0; pass < MAX_PASSES; pass++) {
    const remaining = await db[entity].count({ company_id: companyId }).catch(() => 0);
    if (!remaining) return;
    await db[entity].deleteMany({ company_id: companyId });
  }
}

export default async function (req: Request): Promise<Response> {
  try {
    const methodBlock = requirePost(req);
    if (methodBlock) return methodBlock;

    const override = tenantOverrideFromRequest(req);
    if (override) {
      logSecurityEvent('tenant_override_attempt', { route: 'resetFinancialData', carrier: override });
      return safeJson({ error: 'Invalid request' }, { status: 400 });
    }

    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me().catch((e) => (e.status === 401 ? null : Promise.reject(e)));
    if (!user) return safeJson({ error: 'Unauthorized' }, { status: 401 });

    if (!takeToken(`reset:${user.id}`, 5, 60_000)) {
      return safeJson({ error: 'Too many reset attempts. Try again in a minute.' }, { status: 429 });
    }

    const stored = String(secrets.get('ADMIN_PASSPHRASE') || '');
    if (!stored) return safeJson({ error: 'Reset is not configured' }, { status: 500 });

    const rateKey = `reset:${user.id}:${clientIp(req)}`;
    const state = getRateState(rateKey);
    if (state.locked) {
      return safeJson({ error: 'Too many attempts. Try again later.' }, { status: 429 });
    }

    const parsed = await parseBody(req, PayloadSchema, 4096);
    if (!parsed.ok) return parsed.response;

    if (parsed.data.confirmation.trim().toUpperCase() !== CONFIRMATION_PHRASE) {
      return safeJson({ error: 'Confirmation phrase does not match' }, { status: 400 });
    }

    const valid = await timingSafeCompareStr(parsed.data.passphrase, stored);
    if (!valid) {
      recordFailure(rateKey, state);
      logSecurityEvent('passphrase_denied', { route: 'resetFinancialData', user_id: user.id });
      return safeJson({ error: 'Invalid passphrase' }, { status: 403 });
    }
    clearRate(rateKey);

    const db = base44.asServiceRole.entities;

    // --- Company resolution -------------------------------------------------
    // Priority: payload -> session user record -> membership fallback. Every
    // candidate is verified against admin membership before anything is reset.
    const requested = String(parsed.data.companyId || '').trim();
    const sessionCompanyId = String(
      (user as any)?.active_company_id || (user as any)?.data?.active_company_id || ''
    ).trim();

    let companyId = requested || sessionCompanyId;

    if (!companyId) {
      const memberships: any[] = await db.CompanyMembership
        .filter({ user_id: user.id }, { limit: 50 })
        .then((page: any) => page?.items || [])
        .catch(() => []);
      const adminOf = memberships.filter((m: any) => m?.company_id && m.role === 'admin');
      const pool = adminOf.length ? adminOf : memberships.filter((m: any) => m?.company_id);
      if (pool.length === 1) {
        companyId = String(pool[0].company_id);
      } else if (pool.length > 1) {
        return safeJson(
          {
            error:
              'No active company is set on your account. Open Workspace settings, select the company to reset, then try again.',
          },
          { status: 400 },
        );
      }
    }

    if (!companyId) {
      return safeJson(
        {
          error:
            'No company could be resolved for your account. Create or join a workspace first, then try again.',
        },
        { status: 400 },
      );
    }

    const company = await db.Company.get(companyId).catch((e: any) =>
      e.status === 404 ? null : Promise.reject(e)
    );
    if (!company) {
      return safeJson({ error: 'That company no longer exists.' }, { status: 404 });
    }

    const admins = Array.isArray((company as any)?.admin_members) ? (company as any).admin_members : [];
    let isAdmin = (company as any)?.owner_id === user.id || admins.includes(user.id);
    if (!isAdmin) {
      const membership: any = await db.CompanyMembership
        .filter({ user_id: user.id, company_id: companyId }, { limit: 5 })
        .then((page: any) => (page?.items || [])[0] || null)
        .catch(() => null);
      isAdmin = membership?.role === 'admin';
    }
    if (!isAdmin) {
      logSecurityEvent('reset_denied', { route: 'resetFinancialData', user_id: user.id, company_id: companyId });
      return safeJson({ error: 'Forbidden' }, { status: 403 });
    }

    const scope = { company_id: companyId };

    const [customers, salespersons, invoices, accounts, capitalTransactions] = await Promise.all([
      db.Customer.count(scope).catch(() => 0),
      db.SalesPerson.count(scope).catch(() => 0),
      db.CustomerTransaction.count({ ...scope, type: 'sale' }).catch(() => 0),
      db.CapitalAccount.count(scope).catch(() => 0),
      parsed.data.includeCapitalLedger
        ? db.CapitalTransaction.count(scope).catch(() => 0)
        : Promise.resolve(0),
    ]);

    // 1. Customer & sales person ledgers -> 0.00.
    await zeroUntilClear(
      db,
      'Customer',
      companyId,
      { $or: [{ previous_balance: { $ne: 0 } }, { outstanding_balance: { $ne: 0 } }] },
      { previous_balance: 0, outstanding_balance: 0 },
    );
    await zeroUntilClear(
      db,
      'SalesPerson',
      companyId,
      { $or: [{ previous_balance: { $ne: 0 } }, { outstanding_balance: { $ne: 0 } }] },
      { previous_balance: 0, outstanding_balance: 0 },
    );

    // 2. Invoices: wipe upfront payments, reset statuses to Unpaid.
    await zeroUntilClear(
      db,
      'CustomerTransaction',
      companyId,
      {
        type: 'sale',
        $or: [{ amount_paid_at_purchase: { $ne: 0 } }, { payment_status: { $ne: 'unpaid' } }],
      },
      { amount_paid_at_purchase: 0, payment_status: 'unpaid' },
    );

    // 3. Capital accounts: opening balances -> 0.00.
    await zeroUntilClear(
      db,
      'CapitalAccount',
      companyId,
      { opening_balance: { $ne: 0 } },
      { opening_balance: 0 },
    );

    // 4. Optionally wipe the capital movement ledger so account totals are 0.00.
    if (parsed.data.includeCapitalLedger) {
      await purgeUntilClear(db, 'CapitalTransaction', companyId);
    }

    logSecurityEvent('balances_reset', {
      user_id: user.id,
      company_id: companyId,
      include_capital_ledger: parsed.data.includeCapitalLedger,
    });

    return safeJson({
      ok: true,
      cleared: {
        customers: customers || 0,
        salespersons: salespersons || 0,
        invoices: invoices || 0,
        accounts: accounts || 0,
        capitalTransactions: capitalTransactions || 0,
      },
    });
  } catch (error) {
    return serverError(error, 'Could not reset balances');
  }
}