import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';
import { z } from 'npm:zod@4.6.7';
import {
  logSecurityEvent,
  parseBody,
  requirePost,
  safeJson,
  serverError,
  takeToken,
  tenantOverrideFromRequest,
} from '../../shared/security.ts';

const RECEIPTS_FOLDER_NAME = 'Anijen Receipts';
const MAX_BYTES = 5 * 1024 * 1024;
const PDF_MAGIC = [0x25, 0x50, 0x44, 0x46, 0x2d]; // "%PDF-"

// Only the shapes a receipt needs; size is bounded here and again on the
// decoded bytes below.
const PayloadSchema = z.object({
  pdfBase64: z.string().min(1).max(Math.ceil(MAX_BYTES * 1.4)),
  customerName: z.string().max(200).optional(),
  reference: z.string().max(200).optional(),
});

function sanitizeNamePart(s) {
  return String(s || '')
    .replace(/[^a-zA-Z0-9 _-]/g, '')
    .trim()
    .replace(/\s+/g, '_')
    .slice(0, 40);
}

function shortId() {
  const arr = new Uint8Array(4);
  crypto.getRandomValues(arr);
  return Array.from(arr).map((b) => b.toString(16).padStart(2, '0')).join('').toUpperCase();
}

// Locate the dedicated receipts folder, creating it once if missing.
// Only folder ids are inspected — never receipt file metadata.
async function getOrCreateReceiptsFolder(authHeader) {
  const q = `mimeType = 'application/vnd.google-apps.folder' and name = '${RECEIPTS_FOLDER_NAME.replace(/'/g, "\\'")}' and trashed = false`;
  const listUrl = `https://www.googleapis.com/drive/v3/files?q=${encodeURIComponent(q)}&fields=files(id)&spaces=drive`;
  const listRes = await fetch(listUrl, { headers: authHeader, signal: AbortSignal.timeout(15000) });
  if (listRes.ok) {
    const data = await listRes.json();
    if (data.files && data.files.length > 0) return data.files[0].id;
  }
  const createRes = await fetch('https://www.googleapis.com/drive/v3/files', {
    method: 'POST',
    headers: { ...authHeader, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      name: RECEIPTS_FOLDER_NAME,
      mimeType: 'application/vnd.google-apps.folder',
    }),
    signal: AbortSignal.timeout(15000),
  });
  if (!createRes.ok) {
    const t = await createRes.text();
    throw new Error('Could not create receipts folder: ' + t);
  }
  return (await createRes.json()).id;
}

export default async function(req) {
  try {
    const methodBlock = requirePost(req);
    if (methodBlock) return methodBlock;

    const override = tenantOverrideFromRequest(req);
    if (override) {
      logSecurityEvent('tenant_override_attempt', { route: 'uploadReceiptToDrive', carrier: override });
      return safeJson({ error: 'Invalid request' }, { status: 400 });
    }

    // 1. Caller authentication — reject unauthenticated sessions immediately.
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me().catch((e) => (e.status === 401 ? null : Promise.reject(e)));
    if (!user) return safeJson({ error: 'Unauthorized' }, { status: 401 });

    if (!takeToken(`receipt:${user.id}`, 30, 60 * 1000)) {
      return safeJson({ error: 'Too many uploads, slow down' }, { status: 429 });
    }

    const parsed = await parseBody(req, PayloadSchema, Math.ceil(MAX_BYTES * 1.4) + 8192);
    if (!parsed.ok) return parsed.response;
    const { pdfBase64, customerName, reference } = parsed.data;

    // 2. Size guard (base64 is ~4/3 the binary size).
    if (pdfBase64.length > Math.ceil(MAX_BYTES * 1.4)) {
      return safeJson({ error: 'File too large (max 5MB)' }, { status: 413 });
    }

    // Decode base64 -> bytes.
    const byteStr = atob(pdfBase64);
    const bytes = new Uint8Array(byteStr.length);
    for (let i = 0; i < byteStr.length; i++) bytes[i] = byteStr.charCodeAt(i);

    if (bytes.length > MAX_BYTES) {
      return safeJson({ error: 'File too large (max 5MB)' }, { status: 413 });
    }

    // Strict format enforcement: only real PDFs (magic-byte check), no MIME spoofing.
    const isPdf = bytes.length >= PDF_MAGIC.length && PDF_MAGIC.every((b, i) => bytes[i] === b);
    if (!isPdf) {
      return safeJson({ error: 'Invalid file format; only PDF receipts are allowed' }, { status: 415 });
    }

    // Secure, server-generated filename — caller cannot control the stored name
    // (no path traversal / enumeration). Customer name + reference are sanitized.
    const nameParts = [sanitizeNamePart(customerName), sanitizeNamePart(reference)].filter(Boolean);
    const base = nameParts.length > 0 ? nameParts.join('_') : 'Receipt';
    const filename = `${base}_${shortId()}.pdf`;

    const { accessToken } = await base44.asServiceRole.connectors.getConnection('googledrive');
    const authHeader = { Authorization: `Bearer ${accessToken}` };

    // 3. Scope uploads to an isolated receipts folder.
    const folderId = await getOrCreateReceiptsFolder(authHeader);

    const metadata = { name: filename, mimeType: 'application/pdf', parents: [folderId] };
    const boundary = 'anijen_' + Math.random().toString(36).slice(2);
    const head =
      `--${boundary}\r\n` +
      `Content-Type: application/json; charset=UTF-8\r\n\r\n` +
      `${JSON.stringify(metadata)}\r\n` +
      `--${boundary}\r\n` +
      `Content-Type: application/pdf\r\n\r\n`;
    const tail = `\r\n--${boundary}--`;

    const headBytes = new TextEncoder().encode(head);
    const tailBytes = new TextEncoder().encode(tail);
    const payload = new Uint8Array(headBytes.length + bytes.length + tailBytes.length);
    payload.set(headBytes, 0);
    payload.set(bytes, headBytes.length);
    payload.set(tailBytes, headBytes.length + bytes.length);

    const uploadRes = await fetch(
      'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,webViewLink',
      {
        method: 'POST',
        headers: {
          ...authHeader,
          'Content-Type': `multipart/related; boundary=${boundary}`,
        },
        body: payload,
        signal: AbortSignal.timeout(20000),
      }
    );
    if (!uploadRes.ok) {
      // Provider text goes to the logs only — never to the client.
      logSecurityEvent('drive_upload_failed', { user_id: user.id, status: uploadRes.status });
      return safeJson({ error: 'Receipt storage is unavailable right now' }, { status: 502 });
    }
    const upData = await uploadRes.json();

    // Return only the link to the file this session just created — never
    // metadata for arbitrary files found by name.
    return safeJson({ status: 'uploaded', webViewLink: upData.webViewLink });
  } catch (error) {
    return serverError(error, 'Could not store the receipt');
  }
}